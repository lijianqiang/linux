$(function(){
    //删除操作事件初始化
    var initDeleteEvent = function(data){
        $("#user-list").on("click",".user-delete",function(){
            var rowData = data[$(this).parents("tr").attr("data-index")];
            msg.confirm("确定要删除\""+rowData['username']+"\"吗",function(index){
                layer.close(index);
                msg.load();
                $.getJSON("/rbac/user/delete.do?id="+rowData['id'],function(jsonData){
                    msg.load(true);
                    if(jsonData.code != 0){
                        msg.warn(jsonData.message);
                    }else{
                        $("#user-list").bootstrapTable("refresh");
                    }
                });
            });
        });
    };
    $("#user-list").bootstrapTable({
        "striped" : "true",
        "responseHandler" : function(response){
            return response.data;
        },
        "queryParams" : function(params){
            return params;
        },
        "columns" : [{
            "field" : "realname"
        },{
            "field" : "username"
        },{
        	"field" : "email"
        },{
            "formatter" : function(cellValue,record){
                var html = [];
                html.push("<a class='user-edit' href='/rbac/page/user/update.do?id="+record.id+"'>编辑</a>");
                html.push("<a class='user-delete' href='#'>删除</a>");
                return html.join(" ");
            }
        }],
        "onLoadSuccess": function(data){
            initDeleteEvent(data);
        }
    });
    
    
    $("#user-list").bootstrapTable("refresh",{"url":"/rbac/user/list.do"});
    $("#add-user-btn").click(function(){
        location.href="/rbac/page/user/save.do";
    });
});