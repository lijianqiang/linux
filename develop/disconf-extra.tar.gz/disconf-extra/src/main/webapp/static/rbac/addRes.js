$(function(){
    var fieldError = function($el,msg){
        $el.parents(".form-group").addClass("has-error").find(".error-msg").text(msg);
    }
    var fieldSuss = function($el) {
    	$el.parents(".form-group").removeClass("has-error").find(".error-msg").text("");
    }
    var isNull = function(selector){
        var $el = $(selector);
        if(!$el.val()){
        	fieldError($el,"不可为空"); 
            return true;
        } else {
        	return false;
        }
    }
    $("#res-left-href, #res-res-type-id" ).focusout(function() {
   	 	if(isNull(this)) { return;}
   	 	else {
   	 		fieldSuss($(this));
   	 	}
    });
    var titleExisted = false;
    $("#res-title").focusout(function() {
    	 if(isNull(this)) {return;}
    	 var $this = this;
    	 var params = {
         		title : $($this).val(),
         		resId : $("#res-id").val()
         }
    	 $.getJSON("/rbac/res/checktitle.do",params,function(data){
             if(data.code!=0){
            	 fieldError($($this),data.message);
            	 titleExisted = true;
             }
             else {
            	 titleExisted = false;
            	 fieldSuss($($this));
             }
         });
    });
    
    var mainHrefExisted = false;
    $("#res-main-href").focusout(function() {
    	 if(isNull(this)) { return;}
    	 var $this = this;
    	 var params = {
         		 mainHref : $($this).val(),
                 resId : $("#res-id").val()
         }
    	 $.getJSON("/rbac/res/checkmainhref.do",params,function(data){
             if(data.code!=0){
            	 fieldError($($this),data.message);
            	 mainHrefExisted = true;
             }
             else {
            	 mainHrefExisted = false;
            	 fieldSuss($($this));
             }
         });
    });
    
    $("#save-res-btn").click(function(){
        if(isNull("#res-title") || titleExisted) return;
        if(isNull("#res-main-href") || mainHrefExisted) return;
        if(isNull("#res-res-type-id")) return;
        var id_flag = !$("#res-id").val();
        var params = {
                title : $("#res-title").val(),
                mainHref : $("#res-main-href").val(),
                resTypeId : $("#res-res-type-id").val(),
        }
        var url = "";
        var successMsg = "";
        if(id_flag) {
        	url = "/rbac/res/save.do";
        	successMsg = "添加操作资源成功";
        }
        else {
        	url = "/rbac/res/update.do";
        	successMsg = "编辑操作资源成功";	
        	params.id=$("#res-id").val();
        }
        $.getJSON(url,params,function(data){
            if(data.code==0){
                msg.alert(successMsg);
            }else{
                msg.error(data.message || "操作失败");
            }
        });
    });

    $("#back-btn").click(function(){
        window.location.href=document.referrer;
    });
    
});