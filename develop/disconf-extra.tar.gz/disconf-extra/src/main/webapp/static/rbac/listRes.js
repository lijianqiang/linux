$(function(){
    //删除操作事件初始化
    var initDeleteEvent = function(data){
        $("#res-list").on("click",".res-delete",function(){
            var rowData = data[$(this).parents("tr").attr("data-index")];
            msg.confirm("确定要删除\""+rowData['title']+"\"吗",function(index){
                layer.close(index);
                msg.load();
                $.getJSON("/rbac/res/delete.do?id="+rowData['id'],function(jsonData){
                    msg.load(true);
                    if(jsonData.code != 0){
                        msg.warn(jsonData.message);
                    }else{
                        $("#res-list").bootstrapTable("refresh");
                    }
                });
            });
        });
    };
    
    $("#res-list").bootstrapTable({
        "striped" : "true",
        "responseHandler" : function(response){
            return response.data;
        },
        "queryParams" : function(params){
            return params;
        },
        "columns" : [{
            "field" : "title"
        },{
            "field" : "mainHref"
        },{
            "field" : "resType"
        },{
            "formatter" : function(cellValue,record){
                var html = [];
                html.push("<a class='res-edit' href='/rbac/page/res/update.do?id="+record.id+"'>编辑</a>");
                html.push("<a class='res-delete' href='#'>删除</a>");
                return html.join(" ");
            }
        }],
        "onLoadSuccess": function(data){
            initDeleteEvent(data);
        }
    });
    
    
    $("#res-list").bootstrapTable("refresh",{"url":"/rbac/res/list.do"});
    $("#add-res-btn").click(function(){
        location.href="/rbac/page/res/save.do";
    });
});