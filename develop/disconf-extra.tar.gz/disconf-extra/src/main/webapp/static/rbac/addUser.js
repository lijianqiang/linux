$(function(){
    var fieldError = function($el,msg){
        $el.parents(".form-group").addClass("has-error").find(".error-msg").text(msg);
    }
    var fieldSuss = function($el) {
    	$el.parents(".form-group").removeClass("has-error").find(".error-msg").text("");
    }
    var isNull = function(selector){
        var $el = $(selector);
        if(!$el.val()){
        	fieldError($el,"不可为空"); 
            return true;
        } else {
        	return false;
        }
    }
    var novalidEmail = function(selector){
        var $el = $(selector);
        if(!$el.val() || !$el.val().match(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/)) {
        	fieldError($el,"电子邮箱不合法"); 
            return true;
        } else {
        	return false;
        }
    }
    
    var usernameExisted = false;
    $("#user-email" ).focusout(function() {
   	 	if(isNull(this)) { return;}
   	 	else if(novalidEmail(this)) {return ;}
   	 	else {
   	 		fieldSuss($(this));
   	 	}
    });
    
    $("#user-realname" ).focusout(function() {
   	 	if(isNull(this)) { return;}
   	 	else {
   	 		fieldSuss($(this));
   	 	}
    });
    $("#user-username").focusout(function() {
    	 if(isNull(this)) { return;}
    	 var $username = this;
    	 var params = {
         		 username : $("#user-username").val(),
                 userId : $("#user-id").val()
         }
    	 $.getJSON("/rbac/user/checkname.do",params,function(data){
             if(data.code!=0){
            	 fieldError($($username),data.message);
            	 usernameExisted = true;
             }
             else {
            	 usernameExisted = false;
            	 fieldSuss($($username));
             }
         });
    });
    
    $("#save-user-btn").click(function(){
        if(isNull("#user-username") || usernameExisted) return;
        if(isNull("#user-realname")) return;
        if(isNull("#user-email")) return;
        if(novalidEmail("#user-email")) return;
        var id_flag = !$("#user-id").val();
        var params = {
        		username : $("#user-username").val(),
                realname : $("#user-realname").val(),
                email : $("#user-email").val()
        }
        var roleIds = new Array();
        $("input[name='roleId']:checked").each(function(){
	        	roleIds.push($(this).val());
        });
        params.roleIds = roleIds.join(",");
        
        var envIds = new Array();
        $("input[id='env-type']:checked").each(function(){
        	envIds.push($(this).val());
        });
        params.envIds = envIds.join(",");
        
        var url = "";
        var successMsg = "";
        if(id_flag) {
        	url = "/rbac/user/save.do";
        	successMsg = "添加管理员成功";
        }
        else {
        	url = "/rbac/user/update.do";
        	successMsg = "编辑管理员成功";	
        	params.id=$("#user-id").val();
        }
        $.getJSON(url,params,function(data){
            if(data.code==0){
            	msg.alert(successMsg);
                setTimeout("window.location.href=document.referrer",1000);
            }else{
                msg.error(data.message || "操作失败");
            }
        });
    });

    $("#back-btn").click(function(){
        window.location.href=document.referrer;
    });
    
    $("#role-list").bootstrapTable({
        "striped" : "true",
        "responseHandler" : function(response){
            return response.data;
        },
        "queryParams" : function(params){
            return params;
        },
        "columns" : [{
            "formatter" : function(cellValue,record){
            	var userRoleIds = [];
            	if($("#user-role-ids").val()) {
            		userRoleIds = JSON.parse($("#user-role-ids").val());
            	}
                var html = [];
                html.push("<label>");
                if($.inArray(record.id, userRoleIds)!==-1) {
                	html.push("<input type='checkbox' checked='checked' name='roleId' value='"+record.id+"' data-model='"+record.name+"'>");
                }else {
                	html.push("<input type='checkbox'  name='roleId' value='"+record.id+"' data-model='"+record.name+"'>");
                }
                html.push(record.name);
                html.push("</label>");
                return html.join("");
            }
        },{
            "field" : "description"
        }]
    });
    
    $("#role-list").bootstrapTable("refresh",{"url":"/rbac/role/list.do"});
    
});