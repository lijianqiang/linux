$(function(){
    var fieldError = function($el,msg){
        $el.parents(".form-group").addClass("has-error").find(".error-msg").text(msg);
    }
    
    var $tableMenu = $('#table-menu'),
    	menuSelections = [];
    var $tableRes = $('#table-res'),
		resSelections = [];
    
    var isNull = function(selector, flag){
        var $el = $(selector);
        if(!$el.val()){
            fieldError($el,"不可为空");
            flag = false;
        }
        return flag;
    }
    
    function getMenuSelections() {
        return $.map($tableMenu.bootstrapTable('getSelections'), function (row) {
            return row.id
        });
    }
    function getResSelections() {
        return $.map($tableRes.bootstrapTable('getSelections'), function (row) {
            return row.id
        });
    }
    function getRecordIds() {
    	 return $.map($("input[name='resRecordIds']"), function (row) {
             return $(row).val();
         });
    }
    
    $("#save-permit-btn").click(function(){
    	menuSelections = getMenuSelections();
    	resSelections = getResSelections();
        $("form .form-group").removeClass("has-error").find(".error-msg").text("");
        var id_flag = !$("#role-id").val();
        var params = {
                roleId : $("#role-id").val(),
                menuIds: menuSelections.join(","),
                resIds : resSelections.join(","),
                resRecordIds : getRecordIds().join(";")
        }
        var url = "";
        var successMsg = "";
        if(id_flag) {
        	 msg.error("角色不存在");
        }
        else {
        	url = "/rbac/permit/update.do";
        	successMsg = "编辑权限成功";	
        }
        $.post(url,params,function(data){
        	var result = JSON.parse(data);
            if(result.code==0){
                msg.alert(successMsg);
            }else{
                msg.error(result.message || "操作失败");
            }
        });
    });

    $("#back-btn").click(function(){
        window.location.href=document.referrer;
    });
});