$(function(){
    var fieldError = function($el,msg){
        $el.parents(".form-group").addClass("has-error").find(".error-msg").text(msg);
    }
    var fieldSuss = function($el) {
    	$el.parents(".form-group").removeClass("has-error").find(".error-msg").text("");
    }
    var isNull = function(selector){
        var $el = $(selector);
        if(!$el.val()){
        	fieldError($el,"不可为空"); 
            return true;
        } else {
        	return false;
        }
    }
    
    var nameExisted = false;
    
    $("#role-name").focusout(function() {
    	 if(isNull(this)) { return;}
    	 var $name = this;
    	 var params = {
         		 name : $("#role-name").val(),
                 roleId : $("#role-id").val()
         }
    	 $.getJSON("/rbac/role/checkname.do",params,function(data){
             if(data.code!=0){
            	 fieldError($($name),data.message);
            	 nameExisted = true;
             }
             else {
            	 nameExisted = false;
            	 fieldSuss($($name));
             }
         });
    });
   
    $("#save-role-btn").click(function(){
    	 if(isNull("#role-name") || nameExisted) return;
         var id_flag = !$("#role-id").val();
        var params = {
                name : $("#role-name").val(),
                description : $("#role-desc").val(),
        }
        var url = "";
        var successMsg = "";
        if(id_flag) {
        	url = "/rbac/role/save.do";
        	successMsg = "添加角色成功";
        }
        else {
        	url = "/rbac/role/update.do";
        	successMsg = "编辑角色成功";	
        	params.id=$("#role-id").val();
        }
        $.getJSON(url,params,function(data){
            if(data.code==0){
                msg.alert(successMsg);
                setTimeout("window.location.href=document.referrer",1000);
            }else{
                msg.error(data.message || "操作失败");
            }
        });
    });

    $("#back-btn").click(function(){
        window.location.href=document.referrer;
    });
    
});