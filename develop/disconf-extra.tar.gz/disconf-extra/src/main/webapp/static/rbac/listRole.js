$(function(){
    //删除操作事件初始化
    var initDeleteEvent = function(data){
        $("#role-list").on("click",".role-delete",function(){
            var rowData = data[$(this).parents("tr").attr("data-index")];
            msg.confirm("确定要删除\""+rowData['name']+"\"吗",function(index){
                layer.close(index);
                msg.load();
                $.getJSON("/rbac/role/delete.do?id="+rowData['id'],function(jsonData){
                    msg.load(true);
                    if(jsonData.code != 0){
                        msg.warn(jsonData.message);
                    }else{
                        $("#role-list").bootstrapTable("refresh");
                    }
                });
            });
        });
    };
    
    $("#role-list").bootstrapTable({
        "striped" : "true",
        "responseHandler" : function(response){
            return response.data;
        },
        "queryParams" : function(params){
            return params;
        },
        "columns" : [{
            "field" : "name"
        },{
            "field" : "description"
        },{
            "formatter" : function(cellValue,record){
                var html = [];
                html.push("<a class='permit-add' href='/rbac/page/role/permit.do?id="+record.id+"'>权限分配</a>");
                html.push("<a class='role-edit' href='/rbac/page/role/update.do?id="+record.id+"'>编辑</a>");
                html.push("<a class='role-delete' href='#'>删除</a>");
                return html.join(" ");
            }
        }],
        "onLoadSuccess": function(data){
            initDeleteEvent(data);
        }
    });
    
    
    $("#role-list").bootstrapTable("refresh",{"url":"/rbac/role/list.do"});
    $("#add-role-btn").click(function(){
        location.href="/rbac/page/role/save.do";
    });
});