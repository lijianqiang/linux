$(function(){
    var fieldError = function($el,msg){
        $el.parents(".form-group").addClass("has-error").find(".error-msg").text(msg);
    }
    var fieldSuss = function($el) {
    	$el.parents(".form-group").removeClass("has-error").find(".error-msg").text("");
    }
    var isNull = function(selector){
        var $el = $(selector);
        if(!$el.val()){
        	fieldError($el,"不可为空"); 
            return true;
        } else {
        	return false;
        }
    }
   
    var titleExisted = false;
    $("#menu-title").focusout(function() {
    	 if(isNull(this)) {return;}
    	 var $this = this;
    	 var params = {
         		 title : $($this).val(),
                 menuId : $("#menu-id").val()
         }
    	 $.getJSON("/rbac/menu/checktitle.do",params,function(data){
             if(data.code!=0){
            	 fieldError($($this),data.message);
            	 titleExisted = true;
             }
             else {
            	 titleExisted = false;
            	 fieldSuss($($this));
             }
         });
    });
    
    var mainHrefExisted = false;
    $("#menu-main-href").focusout(function() {
    	 if(isNull(this)) { return;}
    	 var $this = this;
    	 var params = {
         		 mainHref : $($this).val(),
                 menuId : $("#menu-id").val()
         }
    	 $.getJSON("/rbac/menu/checkmainhref.do",params,function(data){
             if(data.code!=0){
            	 fieldError($($this),data.message);
            	 mainHrefExisted = true;
             }
             else {
            	 mainHrefExisted = false;
            	 fieldSuss($($this));
             }
         });
    });
    
    $("#save-menu-btn").click(function(){
        if(isNull("#menu-title") || titleExisted) return;
        if(isNull("#menu-main-href") || mainHrefExisted) return;
        var id_flag = !$("#menu-id").val();
        var params = {
                title : $("#menu-title").val(),
                mainHref : $("#menu-main-href").val(),
                leftHref : $("#menu-left-href").val(),
        }
        var url = "";
        var successMsg = "";
        if(id_flag) {
        	url = "/rbac/menu/save.do";
        	successMsg = "添加菜单成功";
        }
        else {
        	url = "/rbac/menu/update.do";
        	successMsg = "编辑菜单成功";	
        	params.id=$("#menu-id").val();
        }
        $.getJSON(url,params,function(data){
            if(data.code==0){
                msg.alert(successMsg);
            }else{
                msg.error(data.message || "操作失败");
            }
        });
    });

    $("#back-btn").click(function(){
        window.location.href=document.referrer;
    });
    
});