var msg = {
        alert : function(msg) {
            layer.msg(msg, {
                icon : 6,
                time : 2000
            })
        },
        warn : function(msg) {
            layer.msg(msg, {
                icon : 7,
                time : 2000
            })
        },
        error : function(msg) {
            layer.msg(msg, {
                icon : 5,
                time : 2000
            })
        },
        load : function(closeLoad) {
            if (closeLoad) {
                layer.closeAll('loading');
            } else {
                layer.load();
            }
        },
        tips : function(msg, target) {
            return layer.tips(msg, target, {
                time : 60000,
                tips : [ 2, '#ddd' ]
            })
        },
        confirm : function(msg,callback){
            return layer.confirm(msg,{icon:3,title:"确认信息"},callback);
        }
};

//验证模块
var Valid = {
        isNotNull : function(selector, flag){
            var $el = $(selector);
            if(!$el.val()){
                $el.parents(".form-group").addClass("has-error").find(".error-msg").text("不可为空");
                flag = false;
            }
            return flag;
        },
        error : function(selector, msg){
            $(selector).parents(".form-group").addClass("has-error").find(".error-msg").text(msg);
        }
}
