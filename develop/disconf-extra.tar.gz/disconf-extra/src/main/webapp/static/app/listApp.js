$(function(){
    layer.config({
        extend: 'extend/layer.ext.js'
    });
    
    var permit = $("#operate-permit").val();
    
    var canDelete = permit == 'permit';
    
    var initDeleteEvent = function(data){
        $(".delete-app").click(function(){
        	if (canDelete == false) {
        		msg.warn("您没有该权限，若需执行当前操作请联系管理员");
        		return;
        	}
        	
            var rowData = data.rows[$(this).parents("tr").attr("data-index")];
            msg.confirm("删除应用:\""+rowData['name']+"\"后将同时删除该应用下的所有配置信息，确定要继续吗?",function(index){
                layer.close(index);
                msg.load();
                $.getJSON("/extra/app/delete.do?id="+rowData['id'],function(jsonData){
                    msg.load(true);
                    if(jsonData.code != 0){
                        msg.warn(jsonData.message);
                    }else{
                        $("#app-list").bootstrapTable("refresh");
                    }
                });
            });
        });
    };
    var initEditEvent = function(data){
        $(".edit-app").click(function(){
            var rowData = data.rows[$(this).parents("tr").attr("data-index")];
            layer.prompt({
                formType: 0,
                value: rowData['name'],
                title: '修改应用名称'
            }, function(value, index, elem){
                if(!value.trim()){
                    msg.warn("不可为空");
                    return;
                }
                layer.close(index);
                msg.load();
                $.getJSON("/extra/app/update.do?id="+rowData['id']+"&name="+value,function(jsonData){
                    msg.load(true);
                    if(jsonData.code != 0){
                        msg.warn(jsonData.message);
                    }else{
                        $("#app-list").bootstrapTable("refresh");
                    }
                });
            });
        });
    };
    
    $("#add-app").click(function(){
    	location.href="/page/app/create.do";
    });
    
    $("#app-list").bootstrapTable({
    	"striped" : "true",
        "pagination" : "true",
        "sidePagination" : "server",
        "pageSize" : "20",
        "pageList" : "[20]",
        "responseHandler" : function(response){
            return response.data;
        },
        "queryParams" : function(params){
            return params;
        },
        "columns" : [{
            "field" : "name"
        },{
        	"field" : "desc"
        },{
        	"field" : "createTime"
        },{
            "formatter" : function(cellValue,record){
                var html = [];
                html.push("<ul class='operation'>");
                html.push("<li><a href='#' class='edit-app'>编辑</a></li>");
                if (canDelete) {
                	html.push("<li><a href='#' class='delete-app'>删除</a></li>");
                }
                html.push("</ul>");
                return html.join("");
            }
        }],
        "onLoadSuccess": function(data){
            initDeleteEvent(data);
            initEditEvent(data);
        }
    });
    $("#app-list").bootstrapTable("refresh",{"url":"/extra/app/listpage.do"});
    
});