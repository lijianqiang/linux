$(function(){
    layer.config({
        extend: 'extend/layer.ext.js'
    });
    
    var initDeleteEvent = function(data){
        $(".delete-env").click(function(){
            var rowData = data.rows[$(this).parents("tr").attr("data-index")];
            msg.confirm("删除环境:\""+rowData['name']+"\"后将同时删除该环境下的所有应用配置，确定要继续吗?",function(index){
                layer.close(index);
                msg.load();
                $.getJSON("/extra/env/delete.do?id="+rowData['id'],function(jsonData){
                    msg.load(true);
                    if(jsonData.code != 0){
                        msg.warn(jsonData.message);
                    }else{
                        $("#env-list").bootstrapTable("refresh");
                    }
                });
            });
        });
    };
    var initEditEvent = function(data){
        $(".edit-env").click(function(){
            var rowData = data.rows[$(this).parents("tr").attr("data-index")];
            layer.prompt({
                formType: 0,
                value: rowData['name'],
                title: '修改环境名称'
            }, function(value, index, elem){
                if(!value.trim()){
                    msg.warn("不可为空");
                    return;
                }
                layer.close(index);
                msg.load();
                $.getJSON("/extra/env/edit.do?id="+rowData['id']+"&name="+value,function(jsonData){
                    msg.load(true);
                    if(jsonData.code != 0){
                        msg.warn(jsonData.message);
                    }else{
                        $("#env-list").bootstrapTable("refresh");
                    }
                });
            });
        });
    };
    
    $("#add-env").click(function(){
        layer.prompt({
            formType: 0,
            value: '',
            title: '新增环境'
        }, function(value, index, elem){
            if(!value.trim()){
                msg.warn("不可为空");
                return;
            }
            layer.close(index);
            msg.load();
            $.getJSON("/extra/env/edit.do?name="+value,function(jsonData){
                msg.load(true);
                if(jsonData.code != 0){
                    msg.warn(jsonData.message);
                }else{
                    $("#env-list").bootstrapTable("refresh");
                }
            });
        });
    });
    
    $("#env-list").bootstrapTable({
        "striped" : "true",
        "sidePagination" : "server",
        "responseHandler" : function(response){
            return {"rows" : response.data};
        },
        "queryParams" : function(params){
            return params;
        },
        "columns" : [{
            "field" : "name"
        },{
            "formatter" : function(cellValue,record){
                var html = [];
                html.push("<ul class='operation'>");
                html.push("<li><a href='#' class='edit-env'>编辑</a></li>");
                html.push("<li><a href='#' class='delete-env'>删除</a></li>");
                html.push("</ul>");
                return html.join("");
            }
        }],
        "onLoadSuccess": function(data){
            initDeleteEvent(data);
            initEditEvent(data);
        }
    });
    $("#env-list").bootstrapTable("refresh",{"url":"/extra/env/listall.do"});
    
});