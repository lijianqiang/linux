$(function(){
    var fieldError = function($el,msg){
        $el.parents(".form-group").addClass("has-error").find(".error-msg").text(msg);
    }

    var isNull = function(selector, flag){
        var $el = $(selector);
        if(!$el.val()){
            fieldError($el,"不可为空");
            flag = false;
        }
        return flag;
    }

    $("#save-app-btn").click(function(){
        $("form .form-group").removeClass("has-error").find(".error-msg").text("");
        var flag = true;
        flag = isNull("#confirmPassword",flag);
        flag = isNull("#oldPassword",flag);
        flag = isNull("#newPassword",flag);
        if(!flag)return;
        var frm = $('form:eq(0)'), opv = frm[0].oldPassword.value, npv = frm[0].newPassword.value, cpv = frm[0].confirmPassword.value;
       
        if (!npv.match(/^[\x00-\xff]{5,16}$/)) {
        	fieldError($('#newPassword'), '新密码不合法,必须为5-16个字节');
		} else if (!cpv.match(/^[\x00-\xff]{5,16}$/)) {
			fieldError($('#confirmPassword'), '确认密码不合法,必须为5-16个字节');
		} else if ($.trim(npv) != $.trim(cpv)) {
			fieldError($('#confirmPassword'), '确认密码不一致');
		} else {
        $.post('/workspace/savePassword.do', frm.serialize(),
                function(r) {
        		var obj = JSON.parse(r);
        			if(obj.code==999){
                    	msg.error(obj.message);
                    } else if(obj.code==0) {
                    	msg.alert('密码修改成功，请重新登录！');
                    }
                    else {
                    	msg.error(obj.message);
                    }
                });
		}
    });

    $("#back-btn").click(function(){
    	history.back();
    });
});