package cn.nubia.rbac.model;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

public class DynamicRes  implements Serializable {

	private static final long serialVersionUID = 8193973912110968596L;
	protected Integer id;
	protected String title;
	protected String mainHref;
	protected Integer resTypeId = 0;
	private String resType = StringUtils.EMPTY;
	private String resRecordIds = StringUtils.EMPTY;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getMainHref() {
		return mainHref;
	}
	public void setMainHref(String mainHref) {
		this.mainHref = mainHref;
	}
	public Integer getResTypeId() {
		return resTypeId;
	}
	public void setResTypeId(Integer resTypeId) {
		this.resTypeId = resTypeId;
	}
	public String getResType() {
		return resType;
	}
	public void setResType(String resType) {
		this.resType = resType;
	}
	public String getResRecordIds() {
		return resRecordIds;
	}
	public void setResRecordIds(String resRecordIds) {
		this.resRecordIds = resRecordIds;
	}
	@Override
	public String toString() {
		return "DynamicRes [id=" + id + ", title=" + title + ", mainHref="
				+ mainHref + ", resTypeId=" + resTypeId + ", resType="
				+ resType + ", resRecordIds=" + resRecordIds + "]";
	}
	
	
	
}