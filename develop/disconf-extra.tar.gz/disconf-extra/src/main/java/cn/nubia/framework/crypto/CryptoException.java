package cn.nubia.framework.crypto;

import cn.nubia.framework.exception.NestableRuntimeException;


/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-16 17:18:23 by Jxva
 */
public class CryptoException extends NestableRuntimeException {

	private static final long serialVersionUID = -5356341184035030569L;

	public CryptoException() {
		super();
	}

	public CryptoException(Throwable root) {
		super(root);
	}

	public CryptoException(String string, Throwable root) {
		super(string, root);
	}

	public CryptoException(String s) {
		super(s);
	}
}
