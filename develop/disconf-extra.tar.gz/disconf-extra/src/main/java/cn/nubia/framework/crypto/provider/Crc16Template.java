package cn.nubia.framework.crypto.provider;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 29, 2015 2:31:27 PM by jxva
 */
public abstract class Crc16Template {
	
	public abstract void reset();
	
	public abstract void update(byte b);
	
	public abstract int value();
	
	public final void update(byte[] data) {
		for (byte b : data) {
			update(b);
		}
	}
	
	public final String checksum(byte[] data) {
		reset();
		update(data);
		// String v = Integer.toHexString(value);
		return String.format("%04x", value());
	}
}
