package cn.nubia.admin.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.baidu.disconf.web.service.app.bo.App;

import cn.nubia.admin.common.PagerBean;
import cn.nubia.admin.service.AppExtraService;
import cn.nubia.framework.util.StringUtil;

@Service("appExtraService")
public class AppExtraServiceImpl implements AppExtraService {

	@Resource(name = "onedbJdbcTemplate")
	protected JdbcTemplate jdbcTemplate;

	private static final String COLUMN_SQL = "app_id as id, name, description as 'desc', emails, create_time, update_time";

	@Override
	public PagerBean<App> getListByPage(int adminId, PagerBean<App> pager) {
		// 先查这个管理员能有多少role，再查这个role能看多少apk
		String roleIdsSql = "select group_concat(role_id) from tbl_user_role where user_id = ?";
		String roleIds = jdbcTemplate.queryForObject(roleIdsSql, new Object[] { adminId }, String.class);

		String apkIdsSql = "select group_concat(res_record_ids) from tbl_role_dynamic_res where role_id in(" + roleIds
				+ ") and dynamic_res_id = 1";
		String apkIds = jdbcTemplate.queryForObject(apkIdsSql, new Object[] {}, String.class);

		// apkIds为0是能查所有apk，为空时没有apk
		String whereIn = "0".equals(apkIds) ? ""
				: StringUtil.isEmpty(apkIds) ? " AND app_id < 0 " : " AND app_id in (" + apkIds + ") ";

		// 再用apk去查出来
		String rowsSql = "SELECT " + COLUMN_SQL + " FROM app WHERE 1 = 1 " + whereIn + " order by id asc limit ?,?";
		List<App> rows = jdbcTemplate.query(rowsSql, new Object[] { pager.getOffset(), pager.getLimit() },
				new BeanPropertyRowMapper<App>(App.class));
		pager.setRows(rows);

		String totalSql = "SELECT count(1) FROM app WHERE 1 = 1 " + whereIn + "";
		int total = jdbcTemplate.queryForObject(totalSql, new Object[] {}, Integer.class);
		pager.setTotal(total);
		return pager;
	}

	@Override
	public App getById(Long id) {
		String sql = "SELECT " + COLUMN_SQL + " from app where app_id=?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, new BeanPropertyRowMapper<App>(App.class));
	}

	@Override
	public List<App> getByAdminId(int adminId) {
		// 先查这个管理员能有多少role，再查这个role能看多少apk
		String roleIdsSql = "select group_concat(role_id) from tbl_user_role where user_id = ?";
		String roleIds = jdbcTemplate.queryForObject(roleIdsSql, new Object[] { adminId }, String.class);

		String apkIdsSql = "select group_concat(res_record_ids) from tbl_role_dynamic_res where role_id in(" + roleIds
				+ ") and dynamic_res_id = 1";
		String apkIds = jdbcTemplate.queryForObject(apkIdsSql, new Object[] {}, String.class);

		// apkIds为0是能查所有apk，为空时没有apk
		String whereIn = "0".equals(apkIds) ? ""
				: StringUtil.isEmpty(apkIds) ? " AND app_id < 0 " : " AND app_id in (" + apkIds + ") ";

		// 再用apk去查出来
		String rowsSql = "SELECT " + COLUMN_SQL + " FROM app WHERE 1 = 1 " + whereIn + " order by id asc";
		List<App> rows = jdbcTemplate.query(rowsSql, new Object[] {}, new BeanPropertyRowMapper<App>(App.class));
		return rows;
	}

	@Override
	public List<App> getAll() {
		String sql = "SELECT " + COLUMN_SQL + " from app";
		return jdbcTemplate.query(sql, new Object[] {}, new BeanPropertyRowMapper<App>(App.class));
	}

	@Override
	public void delete(Long id) {
		String sql = "delete from app where app_id = ?";
		jdbcTemplate.update(sql, id);

		String other = "delete from config where app_id = ?";
		jdbcTemplate.update(other, id);
	}

	@Override
	public void updateNameById(Long id, String name) {
		String sql = "update app set name = ? where app_id = ?";
		jdbcTemplate.update(sql, name, id);

	}

}
