package cn.nubia.rbac.model;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

public class RoleDynamicRes  implements Serializable {
	
	private static final long serialVersionUID = -1120501151225284954L;
	private Integer id;
	private DynamicRes dynamicRes;
	private Integer dynamicResId;
	private Role role;
	private String resRecordIds = StringUtils.EMPTY;//不符合第一方式，格式是",1,1,1,1"
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public DynamicRes getDynamicRes() {
		return dynamicRes;
	}
	public void setDynamicRes(DynamicRes dynamicRes) {
		this.dynamicRes = dynamicRes;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getResRecordIds() {
		return resRecordIds;
	}
	public void setResRecordIds(String resRecordIds) {
		this.resRecordIds = resRecordIds;
	}
	public Integer getDynamicResId() {
		return dynamicResId;
	}
	public void setDynamicResId(Integer dynamicResId) {
		this.dynamicResId = dynamicResId;
	}
	
}
