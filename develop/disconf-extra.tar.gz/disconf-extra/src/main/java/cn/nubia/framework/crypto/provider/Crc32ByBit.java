package cn.nubia.framework.crypto.provider;

/**
 * 
 * Using direct calculation by bit
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 28, 2015 5:20:39 PM by jxva
 */
public class Crc32ByBit extends Crc32Template {

	private static final int REVERSE_POLYNOMIAL = 0xEDB88320;

	private int value;

	public Crc32ByBit() {
		value = 0xFFFFFFFF;
	}

	public void update(byte b) {
		int temp = (value ^ b) & 0xff;

		// read 8 bits one at a time
		for (int i = 0; i < 8; i++) {
			if ((temp & 1) == 1) {
				temp = (temp >>> 1) ^ REVERSE_POLYNOMIAL;

			} else {
				temp = (temp >>> 1);
			}
		}
		value = (value >>> 8) ^ temp;
		
		//value = (value >>> 8) ^ CRC32_RESVERSED_TABLE[(value ^ b) & 0xff];
	}

	public int value() {
		return value ^ 0xFFFFFFFF;
	}


	public void reset() {
		value = 0xFFFFFFFF;
	}
}
