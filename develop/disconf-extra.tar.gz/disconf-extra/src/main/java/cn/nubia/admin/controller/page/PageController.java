package cn.nubia.admin.controller.page;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cn.nubia.admin.ExtraConstant;

/**
 * 后台管理页面controller
 * 
 * @author lijianqiang
 * @version 2016-10-18
 *
 */
@Controller
@RequestMapping(ExtraConstant.WEB_PREFIX)
public class PageController {

	/**
	 * 对应原 main.html
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/main")
	public ModelAndView toMainPage(HttpServletRequest request) {
		return new ModelAndView("disconf/main");
	}

	/**
	 * 对应原 newconfig.html
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/config/create")
	public ModelAndView toNewConfigPage(HttpServletRequest request) {
		return new ModelAndView("disconf/newconfig");
	}

	/**
	 * 对应原 newconfig_file.html
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/config/file/create")
	public ModelAndView toNewConfigFilePage(HttpServletRequest request) {
		return new ModelAndView("disconf/newconfig_file");
	}

	/**
	 * 对应原 newconfig_item.html
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/config/item/create")
	public ModelAndView toNewConfigItemPage(HttpServletRequest request) {
		return new ModelAndView("disconf/newconfig_item");
	}

	/**
	 * 对应原 modifyFile.html
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/config/file/update")
	public ModelAndView toModifyFilePage(HttpServletRequest request) {
		return new ModelAndView("disconf/modifyFile");
	}

	/**
	 * 对应原 modifItem.html
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/config/item/update")
	public ModelAndView toModifyItemPage(HttpServletRequest request) {
		return new ModelAndView("disconf/modifyItem");
	}

	/**
	 * 新增的app列表界面
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/app/list")
	public ModelAndView toAppListPage(HttpServletRequest request) {
		return new ModelAndView("app/listApp");
	}
	
	/**
	 * 对应原 newapp.html
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/app/create")
	public ModelAndView toNewAppPage(HttpServletRequest request) {
		return new ModelAndView("disconf/newapp");
	}
	
	/**
	 * 新增的evn列表界面
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/env/list")
	public ModelAndView toEnvListPage(HttpServletRequest request) {
		return new ModelAndView("env/listEnv");
	}
}
