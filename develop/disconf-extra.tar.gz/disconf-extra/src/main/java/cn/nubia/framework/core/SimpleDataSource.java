package cn.nubia.framework.core;

import java.io.PrintWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.Semaphore;
import java.util.logging.Logger;

import javax.sql.DataSource;

/**
 * Simple implements of the database connection pool 
 * (Do not use in a production environment, non thread safe!)
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2008-11-26 17:14:21 PM by jxva
 *
 */
public class SimpleDataSource implements DataSource{

	private String driverClass;
	private String url;
	private String username;
	private String password;
	private int minSize;
	private int maxSize;

	private static final ConcurrentMap<Connection, Date> pool = new ConcurrentHashMap<Connection, Date>();
	private Semaphore semaphore;
	
	public SimpleDataSource() {
		minSize = 1;
		maxSize = 5;
		System.out.println("Database Connection Pool initializing...");
	}

	public void close(Connection conn) throws SQLException {
		try{
			synchronized (this) {				
				if (pool.size() < maxSize) {
					pool.put(conn,new Date());
					return;
				}
			}
			conn.close();
		}finally{
			semaphore.release();
		}
	}

	public void close() throws SQLException {
		for (Connection conn : pool.keySet()) {
			conn.close();
		}
		pool.clear();
	}

	public Connection getConnection() throws SQLException {
		try {
			semaphore.acquire();
		} catch (InterruptedException e1) {
			//ignore
		}
		synchronized (this) {
			if (!pool.isEmpty()) {
				Connection conn = pool.keySet().iterator().next();// fetch last connection for ever
				 //Connection conn=(Connection)pool.keySet().toArray()[RandomUtil.getRandomNum(pool.size())]; //random fetch one connection
				pool.remove(conn);
				try {
					conn.setAutoCommit(true);
				} catch (SQLException e) {
					pool.clear();
					conn = getConnection();
				}
				return getProxyConnection(conn);
			}
		}
		return getProxyConnection(DriverManager.getConnection(url, username, password));
	}

	private Connection getProxyConnection(Connection connection) {
		final Connection conn = connection;
		InvocationHandler handler = new InvocationHandler() {
			public Object invoke(Object proxy, Method method, Object[] params) throws Exception {
				Object ret = null;
				if ("close".equals(method.getName())) {
					close(conn);
				} else {
					ret = method.invoke(conn, params);
				}
				return ret;
			}
		};
		return (Connection) Proxy.newProxyInstance(Connection.class.getClassLoader(), new Class[] { Connection.class }, handler);
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getMinSize() {
		return minSize;
	}

	public void setMinSize(int minSize) {
		semaphore=new Semaphore(maxSize,false);
		this.minSize = minSize;
	}

	public int getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	public String getDriverClass() {
		return driverClass;
	}

	public void setDriverClass(String driverClass) {
		try {
			Class.forName(driverClass);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(driverClass+" not exists.",e);
		}
		this.driverClass = driverClass;
	}

	@Override
	public PrintWriter getLogWriter() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setLogWriter(PrintWriter out) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setLoginTimeout(int seconds) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getLoginTimeout() throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Logger getParentLogger() throws SQLFeatureNotSupportedException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T unwrap(Class<T> iface) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Connection getConnection(String username, String password)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static void main() throws SQLException{
		SimpleDataSource dataSource=new SimpleDataSource();
		dataSource.setDriverClass("com.mysql.jdbc.Driver");
		dataSource.setUsername("ztemt");
		dataSource.setPassword("ztemt");
		dataSource.setUrl("jdbc:mysql://10.204.79.230/library?zeroDateTimeBehavior=convertToNull&useUnicode=true&characterEncoding=utf-8");
		dataSource.setMinSize(1);
		dataSource.setMaxSize(10);
		
		
		Connection connection=dataSource.getConnection();
		
		//TODO
		
		connection.close();
	}
}