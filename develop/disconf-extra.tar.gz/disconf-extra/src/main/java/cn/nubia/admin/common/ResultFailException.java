package cn.nubia.admin.common;

public class ResultFailException extends RuntimeException{

	private static final long serialVersionUID = -8570599850401130847L;

	public ResultFailException(String message){
		super(message);
	}
}
