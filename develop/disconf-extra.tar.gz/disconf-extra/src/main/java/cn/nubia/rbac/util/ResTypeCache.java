package cn.nubia.rbac.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import cn.nubia.rbac.model.DynamicResType;

public class ResTypeCache {

	public static  Map<Integer, String> RES_TYPE_MAP = new ConcurrentHashMap<Integer, String>();
	public static  List<DynamicResType> RES_TYPE_LIST = new ArrayList<DynamicResType>();
}
