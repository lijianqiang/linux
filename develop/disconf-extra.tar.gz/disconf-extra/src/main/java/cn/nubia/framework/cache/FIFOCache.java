package cn.nubia.framework.cache;

import java.util.Iterator;
import java.util.LinkedHashMap;

/**
 * First In First Out
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class FIFOCache extends AbstractCache {
	
	public FIFOCache(String name){
		this(name,DEFAULT_MAX_SIZE);
	}
	
	public FIFOCache(String name,int maxSize){
		this.name=name;
		this.maxSize=maxSize;
		this.map=new LinkedHashMap<Object,Element>();
	}
	
    protected final void doPut(Element element) throws CacheException {
        if (isFull()) {
            removeFirstElement();
        }
    }

    Element getFirstElement() {
        if (map.size() == 0) {
            return null;
        }
        Iterator<Object> itr = map.keySet().iterator();
        if (itr.hasNext()) {
            return map.get(itr.next());
        }
        return null;
    }
    
    private void removeFirstElement() throws CacheException {
        remove(getFirstElement().getKey());
    }
}
