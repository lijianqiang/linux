package cn.nubia.rbac.util;

import cn.nubia.framework.crypto.Des;
import cn.nubia.framework.crypto.PaddingMode;

public class RbacDes {
	private static String key="ausp_des";
	private static String iv="ausp_ivs";
	private static final Des des=new Des(64, PaddingMode.SpacePadding);
	
	public static String decrypt(String value){
		return des.cbc_decrypt(key, iv, value);
	}
	public static String encrypt(String value){
		return des.cbc_encrypt(key, iv, value);
	}
}
