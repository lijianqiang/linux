package cn.nubia.framework.crypto;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import cn.nubia.framework.crypto.provider.Md4Provider;
import cn.nubia.framework.crypto.provider.MessageDigestProvider;
import cn.nubia.framework.entity.Hex;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 27, 2015 7:06:42 PM by jxva
 */
public class Hash {

	public static final Algorithm NONE = new Algorithm("none", "none", Integer.MIN_VALUE);

	public static final Algorithm MD2 = new Algorithm("MD2", "HmacMD2", 0);

	public static final Algorithm MD5 = new Algorithm("MD5", "HmacMD5", 1);

	public static final Algorithm SHA1 = new Algorithm("SHA1", "HmacSHA1", 2);

	public static final Algorithm SHA224 = new Algorithm("SHA-224", "HmacSHA224", 3);

	public static final Algorithm SHA256 = new Algorithm("SHA-256", "HmacSHA256", 4);

	public static final Algorithm SHA384 = new Algorithm("SHA-384", "HmacSHA384", 5);

	public static final Algorithm SHA512 = new Algorithm("SHA-512", "HmacSHA512", 6);

	public static final Algorithm MD4 = new Algorithm("MD4", "HmacMD4", 101);

	public static byte[] encrypt(Algorithm algo, byte[] data) {
		if (algo.value() == MD4.value()) {
			return Md4Provider.encrypt(data);
		} else {
			return MessageDigestProvider.encrypt(algo.name(), data);
		}
	}
	
	public static String encrypt(Algorithm algo, String data) {
		return Hex.bin2hex(encrypt(algo,data.getBytes()));
	}

	public static byte[] hmac(Algorithm algo, byte[] data, byte[] key) {
		if (algo.value() == MD4.value()) {
			return Md4Provider.hmac(data, key);
		} else {
			return MessageDigestProvider.hmac(algo.hmac(), data, key);
		}
	}
	
	public static String hmac(Algorithm algo, String data, String key) {
		return Hex.bin2hex(hmac(algo,data.getBytes(),key.getBytes()));
	}

	public static byte[] checksum(Algorithm algo, File file) {
		if (algo.value() == MD4.value()) {
			return Md4Provider.checksum(file);
		} else {
			return MessageDigestProvider.checksum(algo.name(), file);
		}
	}
}

class Algorithm {

	private static List<Algorithm> known = new ArrayList<Algorithm>();

	private final String name;
	private final String hmac;
	private final int value;

	protected Algorithm(String name, String hmac, int value) {
		this.name = name;
		this.hmac = hmac;
		this.value = value;
		known.add(this);
	}

	public static Algorithm parse(String name) {
		try {
			for (int i = 0; i < known.size(); i++) {
				Algorithm l = known.get(i);
				if (name.equalsIgnoreCase(l.name.trim())) {
					return l;
				}
			}
		} catch (Exception e) {
		}
		return Hash.NONE;
	}

	public String name() {
		return name;
	}

	public String hmac() {
		return hmac;
	}

	public final int value() {
		return value;
	}

	@Override
	public final String toString() {
		return name;
	}

	@Override
	public boolean equals(Object ox) {
		try {
			Algorithm lx = (Algorithm) ox;
			return (lx.value == this.value);
		} catch (Exception ex) {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return this.value;
	}
}