package cn.nubia.rbac.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.nubia.framework.core.ActionContext;
import cn.nubia.framework.core.HttpCookie;
import cn.nubia.framework.entity.Encoding;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.util.Define;
import cn.nubia.rbac.util.RbacCache;
import cn.nubia.rbac.util.RbacDes;

/**
 * @author xjxue
 * 过滤器
 */
public class RbacFilter implements Filter{
	private String encoding;
	private static final List<String> UNFILTER_URLS;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	static{
		UNFILTER_URLS=new ArrayList<String>();
//		UNFILTER_URLS.add("/pages/index.jsp");
//		UNFILTER_URLS.add("/pages/404.html");
		UNFILTER_URLS.add("/login/check.do");
		UNFILTER_URLS.add("/api/zoo/hosts.do"); 
		UNFILTER_URLS.add("/api/zoo/prefix.do");
		UNFILTER_URLS.add("/api/config/item.do");
		UNFILTER_URLS.add("/api/config/file.do");
		UNFILTER_URLS.add("/api/config/list.do");
		UNFILTER_URLS.add("/api/config/simple/list.do"); 
		// 以下都是测试用的，免密
	}
	
	/**
	 * destroy
	 */
	public void destroy(){
		this.encoding = null;
	}

	/**
	 * @param filterConfig f
	 * @throws ServletException s
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		encoding = filterConfig.getInitParameter("encoding");
		if (encoding == null) {
			encoding = Encoding.UTF_8.toString();
		}
	}
		
	
	/**
	 * @param req r
	 * @param resp r
	 * @param chain c
	 * @throws IOException i
	 * @throws ServletException s
	 */
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		req.setCharacterEncoding(encoding);
		try {
			HttpServletRequest request = (HttpServletRequest) req;
			HttpServletResponse response = (HttpServletResponse) resp;
			ActionContext.setContext(request, response);

			if (needPrivilegeUrl(request)) {// 权限判断
				SysUser employee = (SysUser) request.getSession().getAttribute(
						Define.SESSION_IN_USER);
				if (employee == null) {// 未登录
					HttpCookie cookie = new HttpCookie(request, response);
					String workId = cookie.getValue(Define.COOKIE_IN_USERID);
					if (workId == null) {
						noPrivilege(request, resp);
						return;
					} else {
						String dec=RbacDes.decrypt(workId);
						employee = RbacCache.get(dec);
						if (employee == null) {
							noPrivilege(request, resp);
							return;
						} else {
							request.getSession().setAttribute(
									Define.SESSION_IN_USER, employee);
							cookie.setValue(Define.COOKIE_IN_USERID,
									RbacDes.encrypt(workId));
						}
					}
				}
			}
			chain.doFilter(req, resp);
			return;
		} finally {
			ActionContext.removeContext();
		}
	}
	
	/**
	 * @param request r 
	 * @param resp r
	 * @throws IOException i
	 */
	private void noPrivilege(HttpServletRequest request,ServletResponse resp) throws IOException{
		resp.setCharacterEncoding(Encoding.UTF_8.toString());
		resp.setContentType("text/html;charset=UTF-8");
 		PrintWriter out=resp.getWriter();
 		out.print("<meta charset=\"utf-8\"/>");
 		out.print("权限不够或登录超时，请重新<a href='"+request.getContextPath()+"/' target='_top'>登录</a> ！");
		out.close();
		out.flush();
	}
	
    /**
     * @param request r
     * @return r
     */
    private boolean needPrivilegeUrl(HttpServletRequest request){
    	log.info("[check url]" + request.getServletPath());
    	if(request.getRequestURI().indexOf('.')==-1){
    		return false;
    	}
	 	return !UNFILTER_URLS.contains(request.getServletPath());
    }
}