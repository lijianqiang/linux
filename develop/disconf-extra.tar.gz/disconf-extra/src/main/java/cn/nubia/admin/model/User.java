package cn.nubia.admin.model;

import java.io.Serializable;
import java.sql.Timestamp;


public class User implements Serializable {

	private static final long serialVersionUID = -2915353663966274419L;

	private Integer userId;

	private String username;

	private String password;
	
	private Timestamp addTime;
	

	public User() {
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Timestamp getAddTime() {
		return addTime;
	}
	
	public void setAddTime(Timestamp addTime) {
		this.addTime=addTime;
	}
}
