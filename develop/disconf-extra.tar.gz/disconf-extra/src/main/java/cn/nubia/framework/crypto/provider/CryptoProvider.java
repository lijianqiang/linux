package cn.nubia.framework.crypto.provider;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import cn.nubia.framework.crypto.CipherMode;
import cn.nubia.framework.crypto.CryptoException;
import cn.nubia.framework.crypto.CryptoMode;
import cn.nubia.framework.crypto.Padding;
import cn.nubia.framework.crypto.PaddingMode;
import cn.nubia.framework.entity.Hex;

/**
 * 
 * http://docs.oracle.com/javase/6/docs/technotes/guides/security/SunProviders.html
 * http://docs.oracle.com/javase/7/docs/technotes/guides/security/SunProviders.html
 * http://docs.oracle.com/javase/8/docs/technotes/guides/security/SunProviders.html
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Dec 30, 2014 11:15:42 AM by jxva
 */
public abstract class CryptoProvider {

	protected final int blockSize;
	protected final PaddingMode padding;

	public CryptoProvider(int blockSize, PaddingMode padding) {
		if (blockSize % 64 != 0) {
			throw new CryptoException("The block size must be a multiple of 64.");
		}
		this.blockSize = blockSize;
		this.padding = padding;
	}

	private Cipher create(CryptoMode cryptoMode, CipherMode cipherMode) {
		String paddingName = padding != PaddingMode.PKCS5Padding ? PaddingMode.NoPadding.name() : padding.name();
		String algorithm = cryptoMode.name() + '/' + cipherMode.name() + '/'+ paddingName;
		//System.out.println(algorithm);
		try {
			return Cipher.getInstance(algorithm);
		} catch (NoSuchAlgorithmException e) {
			throw new CryptoException(e);
		} catch (NoSuchPaddingException e) {
			throw new CryptoException(e);
		}
	}

	protected byte[] cbc_encrypt(CryptoMode cryptoMode, byte[] key, byte[] iv, byte[] data) {
		try {
			SecretKeySpec sks = new SecretKeySpec(key, cryptoMode.name());
			IvParameterSpec ips = new IvParameterSpec(iv);
			Cipher cipher = create(cryptoMode, CipherMode.CBC);
			cipher.init(Cipher.ENCRYPT_MODE, sks, ips);
			
			//if (this.padding == PaddingMode.PKCS5Padding) {
			//	byte[] result = Padding.pkcs5Padding(blockSize, data);
			//	return cipher.doFinal(result);
			//} else
			if (this.padding == PaddingMode.SpacePadding) {
				byte[] result = Padding.spacePadding(blockSize, data);
				return cipher.doFinal(result);
			} else {
				//supported PKCS5Padding(default), NoPadding
				return cipher.doFinal(data);
			}
		} catch (InvalidKeyException e) {
			throw new CryptoException(e);
		} catch (InvalidAlgorithmParameterException e) {
			throw new CryptoException(e);
		} catch (IllegalBlockSizeException e) {
			throw new CryptoException(e);
		} catch (BadPaddingException e) {
			throw new CryptoException(e);
		}
	}

	protected byte[] cbc_decrypt(CryptoMode cryptoMode, byte[] key, byte[] iv, byte[] data) {
		try {
			SecretKeySpec sks = new SecretKeySpec(key, cryptoMode.name());
			IvParameterSpec ips = new IvParameterSpec(iv);
			Cipher cipher = create(cryptoMode, CipherMode.CBC);
			cipher.init(Cipher.DECRYPT_MODE, sks, ips);
			return cipher.doFinal(data);
		} catch (InvalidKeyException e) {
			throw new CryptoException(e);
		} catch (InvalidAlgorithmParameterException e) {
			throw new CryptoException(e);
		} catch (IllegalBlockSizeException e) {
			throw new CryptoException(e);
		} catch (BadPaddingException e) {
			throw new CryptoException(e);
		}
	}
	
	public abstract byte[] cbc_encrypt(byte[] key, byte[] iv, byte[] data);
	
	public abstract byte[] cbc_decrypt(byte[] key, byte[] iv, byte data[]);
	
	public String cbc_encrypt(String key, String iv, String data) {
		return Hex.bin2hex(cbc_encrypt(key.getBytes(),iv.getBytes(),data.getBytes()));
	}
	
	public String cbc_decrypt(String key, String iv, String data) {
		return new String(cbc_decrypt(key.getBytes(),iv.getBytes(), Hex.hex2bin(data)));
	}
}
