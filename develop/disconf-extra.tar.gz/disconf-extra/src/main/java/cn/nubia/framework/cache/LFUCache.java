package cn.nubia.framework.cache;

import java.util.HashMap;
import java.util.Iterator;


/**
 * Least Frequently Used/Most Frequently Used
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class LFUCache extends AbstractCache  {

	public LFUCache(String name){
		this(name,DEFAULT_MAX_SIZE);
	}
	
	public LFUCache(String name,int maxSize){
		this.name=name;
		this.maxSize=maxSize;
		this.map=new HashMap<Object,Element>();
	}


    public final synchronized void doPut(Element elementJustAdded) {
        if (isFull()) {
            removeLfuElement(elementJustAdded);
        }
    }

    private void removeLfuElement(Element elementJustAdded) {
        // First element of the sorted list is the candidate for the removal
       Element element = findRelativelyUnused(elementJustAdded);
        remove(element.getKey());
    }

    /**
     * Find a "relatively" unused element, but not the element just added.
     */
    final Element findRelativelyUnused(Element elementJustAdded) {
        LFUPolicy.Metadata[] elements = sampleElements(map.size());
        LFUPolicy.Metadata metadata = LFUPolicy.leastHit(elements, new ElementMetadata(elementJustAdded));
        return map.get(metadata.getKey());
    }

    /**
     * Uses random numbers to sample the entire map.
     * @return an array of sampled elements
     */
     LFUPolicy.Metadata[] sampleElements(int size) {
        int[] offsets = LFUPolicy.generateRandomSample(size);
        ElementMetadata[] elements = new ElementMetadata[offsets.length];
        Iterator<Element> iterator = map.values().iterator();
        for (int i = 0; i < offsets.length; i++) {
            for (int j = 0; j < offsets[i]; j++) {
                iterator.next();
            }
            elements[i] = new ElementMetadata(iterator.next());
        }
        return elements;
    }


    /**
     * A Metadata wrapper for Element
     */
    private class ElementMetadata implements LFUPolicy.Metadata {
        private Element element;
        public ElementMetadata(Element element) {
            this.element = element;
        }
        public Object getKey() {
            return element.getKey();
        }
        public long getHitCount() {
            return element.getHitCount();
        }
        public int hashCode() {
            if (element != null) {
                return element.getKey().hashCode();
            } else {
                return 0;
            }
        }
        public boolean equals(Object object) {
            if (object != null && object instanceof LFUPolicy.Metadata) {
                LFUPolicy.Metadata metadata = (LFUPolicy.Metadata) object;
                return this.getKey().equals(metadata.getKey());
            } else {
                return false;
            }
        }
    }
}
