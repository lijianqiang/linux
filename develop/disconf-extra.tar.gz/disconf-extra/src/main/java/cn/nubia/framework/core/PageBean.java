package cn.nubia.framework.core;


/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2009-01-03 21:09:38 by Jxva
 */
public abstract class PageBean {
	
	public static final int DEFAULT_PAGESIZE = 20;
	protected int pagesize=20;
	protected int pageno;
	protected long totalCount;
	protected long totalPage;
	
	public PageBean(int pageno,int pagesize) {
		this.pageno=pageno<1?1:pageno;
		this.pagesize=pagesize<1?DEFAULT_PAGESIZE:pagesize;
	}
	
	public PageBean(int pageno) {
		this.pageno=pageno<1?1:pageno;
	}
	

	public int getPageno() {
		return pageno;
	}
		
	public int getPagesize() {
		return pagesize;
	}

	public long getTotalPage() {			
		return totalPage;
	}
	
	public int getNextPage() {
		if (hasNextPage()) {
			return pageno + 1;
		}
		return pageno;
	}
	
	public int getPrevPage(){
		if(hasPrevPage()){
			return pageno-1;
		}
		return pageno;
	}

	public boolean hasPrevPage(){
		return pageno>1;
	}

	public boolean hasNextPage() {
		return pageno < totalPage;
	}

	
	public long getTotalCount(){
		return totalCount;
	}
	
	public void setTotalCount(long totalCount){
		if(totalCount%this.pagesize==0) {
			this.totalPage=totalCount/this.pagesize;
		}else{
			this.totalPage=(totalCount-totalCount%this.pagesize)/this.pagesize+1;
		}
		this.totalCount=totalCount;
	}
	
	public int getStartIndex(){
		return pagesize*(pageno-1);
	}
	
	public int getEndIndex(){
		return pageno*pagesize;
	}
	
	public abstract void setPageNum(String url);
	public abstract String getPageNum();
}
