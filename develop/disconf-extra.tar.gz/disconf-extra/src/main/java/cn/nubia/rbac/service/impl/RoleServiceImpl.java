package cn.nubia.rbac.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.nubia.admin.common.ResultFailException;
import cn.nubia.rbac.model.Role;
import cn.nubia.rbac.service.RoleService;

//TODO:检查数据一致性，检查ele是否在数据库中，否则使用外键
@Service("roleService")
public class RoleServiceImpl implements RoleService {
	@Resource
	protected JdbcTemplate template;
	private static final Log log = LogFactory.getLog(RoleServiceImpl.class);
	private static final Integer NOT_EXISTED_ID = -1;
	@Override
	public void save(Role role) {
		if(role == null) {
			log.error("[rbac role] save role method, the param role is null");
			throw new NullArgumentException("save role method, the param role is null");
		}
		
		checkExistName(role);
		String sql = "insert into tbl_role(name,description) values(?,?)";
        this.template.update(sql,new Object[]{role.getName(),role.getDescription()
        		});
	}
	
	private void checkExistName(Role role) {
		if(this.existedNameWithOther(role.getName(), role.getId())) {
			log.error("[rbac role] checkExistName method, the name is existed");
			throw new ResultFailException("角色名称已经存在，操作失败");
		}
	}
	@Override
	public void delete(Integer id) {
		if(id == null) {
			log.error("[rbac role] delete role method, the param id is null");
			throw new NullArgumentException("delete role method, the param id is null");
		}
		String sql = "delete from tbl_role where id=?";
		this.template.update(sql, id);
		//与此角色相关有关联的中间表要删除
		//1、menu与角色中间表
		this.deleteMenu(id);
		//2、dynamicRes 与角色中间表
		this.deleteDynamicRes(id);
	}

	@Override
	public void update(Role role) {
		if(role == null) {
			log.error("[rbac role] update role method, the param role is null");
			throw new NullArgumentException("update role method, the param role is null");
		}
		if(role.getId() == null) {
			log.error("[rbac role] update role method, the param id is null");
			throw new NullArgumentException("update role method, the param id is null");
		}
		checkExistName(role);
		String sql = "update tbl_role set name=?, description=?  where id=?";
		this.template.update(sql, new Object[]{role.getName(), role.getDescription(),role.getId()});
	}

	@Override
	public List<Role> fetchAll() {
		String sql = "select * from tbl_role";
		return this.template.query(sql, new RoleRowMapper());
	}

	private void saveMenu(Integer roleId, List<Integer> menuId) {
		
		assert roleId != null;
		assert (menuId!=null && !menuId.isEmpty());
		
		String sql = "insert tbl_role_menu (role_id, menu_id) value (?,?)";
		List<Object[]> params = new ArrayList<Object[]>();
		for(Integer ele : menuId) {
			params.add(new Object[]{roleId, ele});
		}
		this.template.batchUpdate(sql, params);
	}

	private void updateMenu(Integer roleId, List<Integer> newMenuId) {
		
		this.deleteMenu(roleId);
		
		if(null == newMenuId || newMenuId.isEmpty()) {
			log.info("[rbac role] update menu-role method, the param menuId is null or empty");
			return ;
		}
		
		this.saveMenu(roleId, newMenuId);
		
	}
	
	private void deleteMenu(Integer roleId) {
		assert roleId != null;
		String sql = "delete from tbl_role_menu where role_id=?";
		this.template.update(sql, roleId);
	}

	private void saveDynamicRes(Integer roleId, List<Integer> resId, Map<Integer, String> resRecordIds) {
		
		assert (resId != null && !resId.isEmpty());
		
		String sql = "insert tbl_role_dynamic_res (role_id, dynamic_res_id, res_record_ids) value (?,?,?)";
		List<Object[]> params = new ArrayList<Object[]>();
		
		for(Integer ele : resId) {
			params.add(new Object[]{roleId, ele,resRecordIds.get(ele)==null?StringUtils.EMPTY:resRecordIds.get(ele)});
		}
		this.template.batchUpdate(sql, params);
		
	}

	private void updateDynamicRes(Integer roleId, List<Integer> newResId, Map<Integer, String> resRecordIds) {
		
		this.deleteDynamicRes(roleId);
		
		if(null == newResId || newResId.isEmpty()) {
			log.info("[rbac role] update DynamicRes method, the param roleId is null or empty");
			return ;
		}
		
		this.saveDynamicRes(roleId, newResId,resRecordIds);
	}

	private void deleteDynamicRes(Integer roleId) {
		assert roleId!=null;
		String sql = "delete from tbl_role_dynamic_res where role_id=?";
		this.template.update(sql, roleId);
	}

	@Override
	public Role getById(Integer id) {
		if(id == null) {
			log.error("[rbac role] getById method, the param id is null");
			return null;
		}
		String sql = "select id,name, description from tbl_role where id=? ";
		try {
			Role obj = this.template.queryForObject(sql, new Object[]{id}, new RoleRowMapper());
			return obj;
		} catch(EmptyResultDataAccessException ex) {
			return null;
		}
	}

	@Override
	public void updatePemit(Integer roleId, List<Integer> menuIdInts,
			 List<Integer> resIds, Map<Integer, String> resRecordIds) {
		if(roleId == null) {
			log.error("[rbac role] updatePemit method, the param roleId is null");
			throw new NullArgumentException("updatePemit method, the param roleId is null");
		}
		
		if(menuIdInts == null) {
			this.updateMenu(roleId, new ArrayList<Integer>());
		}
		else {
			this.updateMenu(roleId, menuIdInts);
		}
		
		if(resIds == null) {
			this.updateDynamicRes(roleId, new ArrayList<Integer>(),resRecordIds);
		}
		else {
			this.updateDynamicRes(roleId, resIds,resRecordIds);
		}
		
	}
	
	@Override
	public boolean existedByMenuId(Integer id) {
		if (id == null) {
			log.error("[rbac user] existedByMenuId method, the param id is null");
			throw new NullArgumentException(
					"existed role ByMenuId method, the param id is null");
		}
		String sql = "select role_id from tbl_role_menu where menu_id=?";
		List<Integer> result = this.template.queryForList(sql, Integer.class,
				id);
		if (result == null || result.isEmpty()) {
			return false;
		}
		return true;
	}
	@Override
	public boolean existedByDynamicResId(Integer id) {
		if (id == null) {
			log.error("[rbac user] existed role DynamicRes method, the param id is null");
			throw new NullArgumentException(
					"existed role DynamicRes method, the param id is null");
		}
		String sql = "select role_id from tbl_role_dynamic_res where dynamic_res_id=?";
		List<Integer> result = this.template.queryForList(sql, Integer.class,
				id);
		if (result == null || result.isEmpty()) {
			return false;
		}
		return true;
	}

	/**
	 * @param name
	 * @param id
	 * @return
	 * @author gsd
	 */
	@Override
	public boolean existedNameWithOther(String name, Integer id) {
		if(StringUtils.isBlank(name)) {
			log.error("[rabc role] existedNameWithOther, the param name is blank");
			return true;
		}
		
		String sql = "select id from tbl_role where name=? and id <> ?";
		if(id == null) {
			id = NOT_EXISTED_ID;
		}
		List<Integer> result = this.template.queryForList(sql, Integer.class, new Object[]{name, id});
		if(result == null || result.isEmpty()) {
			return false;
		}
		
		return true;
	}
	

}
class RoleRowMapper implements RowMapper<Role> {
	public Role mapRow(ResultSet rs, int index) throws SQLException {
		Role role = new Role();
		role.setId(rs.getInt("id"));
		role.setName(rs.getString("name"));
		role.setDescription(rs.getString("description"));
		return role;
	}
}
