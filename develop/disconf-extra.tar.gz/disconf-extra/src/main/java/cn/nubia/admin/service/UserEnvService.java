package cn.nubia.admin.service;

import java.util.List;

import cn.nubia.admin.model.UserEnv;

public interface UserEnvService {
	
	UserEnv getById(int id);
	
	void save(int userId, List<Integer> envIds);
	
	List<UserEnv> getByUserId(int userId);
	
	void deleteByUserId(int userId);
	
	List<UserEnv> buildUserEnvList(int userId);
	
	void deleteByEnvId(long envId);

}
