package cn.nubia.framework.crypto;

import cn.nubia.framework.crypto.provider.CryptoProvider;


/**
 * 
 * DES( Data Encryption Standard)算法，于1977年得到美国政府的正式许可
 * 是一种用56位密钥来加密64位数据的方法
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Dec 17, 2014 10:29:36 AM by jxva
 */
public class Des extends CryptoProvider {

	public Des(int blockSize, PaddingMode padding) {
		super(blockSize,padding);
	}

	@Override
	public byte[] cbc_encrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_encrypt(CryptoMode.DES,key,iv,data);
	}

	@Override
	public byte[] cbc_decrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_decrypt(CryptoMode.DES,key,iv,data);
	}
	
}
