package cn.nubia.framework.cache;

import cn.nubia.framework.util.RandomUtil;


/**
 * Contains common LFU policy code for use between the LFUWeakCache, which also
 * uses an LFUPolicy for evictions.
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public final class LFUPolicy {

    private static final int DEFAULT_SAMPLE_SIZE = 30;
    private LFUPolicy() {
    }

    /**
     * sampleSize how many samples to take
     * @return the smaller of the map size and the default sample size of 30
     */
    private static int calculateSampleSize(int populationSize) {
        if (populationSize < DEFAULT_SAMPLE_SIZE) {
            return populationSize;
        } else {
            return DEFAULT_SAMPLE_SIZE;
        }

    }


    /**
     * Finds the least hit of the sampled elements provided
     * @param sampledElements this should be a random subset of the population
     * @param justAdded we never want to select the element just added. May be null.
     * @return the least hit
     */
    public static LFUPolicy.Metadata leastHit(LFUPolicy.Metadata[] sampledElements, LFUPolicy.Metadata justAdded) {
        //edge condition when Memory Store configured to size 0
        if (sampledElements.length == 1 && justAdded != null) {
            return justAdded;
        }
        LFUPolicy.Metadata lowestElement = null;
        for (int i = 0; i < sampledElements.length; i++) {
            LFUPolicy.Metadata element = sampledElements[i];
            if (lowestElement == null) {
                if (!element.equals(justAdded)) {
                    lowestElement = element;
                }
            } else {
                if (element.getHitCount() < lowestElement.getHitCount() && !element.equals(justAdded)) {
                    lowestElement = element;
                }
            }
        }
        return lowestElement;
    }

    /**
     * Generates a random sample from a population
     * @param populationSize the size to draw from
     */
    public static int[] generateRandomSample(int populationSize) {
        int sampleSize = LFUPolicy.calculateSampleSize(populationSize);
        int[] offsets = new int[sampleSize];
        int maxOffset = populationSize / sampleSize;
        for (int i = 0; i < sampleSize; i++) {
            offsets[i] = RandomUtil.RANDOM.nextInt(maxOffset);
        }
        return offsets;
    }

    public static interface Metadata {
    	
        Object getKey();

        long getHitCount();

    }
}
