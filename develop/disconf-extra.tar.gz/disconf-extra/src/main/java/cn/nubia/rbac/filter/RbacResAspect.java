package cn.nubia.rbac.filter;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.jdbc.core.JdbcTemplate;

import cn.nubia.framework.core.ActionContext;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.util.Define;

/**
 * 在角色的数据资源进行做拦截
 * @author gsd
 *
 */
public class RbacResAspect {
	@Resource
	protected JdbcTemplate template;
	private final static Log logger = LogFactory.getLog(RbacResAspect.class);
	private final static String WHERE_STR = "where";
	
	public Object resAspect(ProceedingJoinPoint joinpoint) throws Throwable {
		logger.debug("[res aspect] res aspect start...@" + joinpoint.getSignature().getName());
		try {
				querySqlForResPermit(joinpoint);
		} catch(RuntimeException ex) {
			logger.error("resAspect error", ex);
		}
		
		Object obj = joinpoint.proceed(joinpoint.getArgs());
		return obj;
	}
	
	private void querySqlForResPermit(ProceedingJoinPoint joinpoint) {
		if(joinpoint == null 
				|| ActionContext.getRequest() == null 
				|| ActionContext.getSession() == null) {
			return;
		}
		
		Object[] args = joinpoint.getArgs();
		if(args == null) return;
		
		String querySql = StringUtils.EMPTY; 
		if(args.length > 0 && args[0] instanceof String) {
			querySql = (String)args[0];
		} else return;
		
		StringBuilder sb = new StringBuilder(100);
		//简单的语法分析（目前关于apkinfo查询语句可以满足，如果有扩展 则需要重新解释语法）
		if(querySql.startsWith("select") && querySql.replaceAll("\\s", "").contains("fromtbl_apk_info")) {
			String allowIds = "";
			SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
			if(sysUser == null) return;
			if(ActionContext.getRequest().getRequestURI().contains("app/save.do")
					|| ActionContext.getRequest().getRequestURI().contains("res/app/list")) {
				return;
			}
			if(sysUser.getRes() != null && 
					sysUser.getRes().get("app/list") != null) {
				allowIds = sysUser.getRes().get("app/list").getResRecordIds();
			}
			if(StringUtils.isNotBlank(allowIds) && allowIds.equals("0")) {
				return;
			}
			if(StringUtils.isBlank(allowIds)) {
				allowIds = "-1";
			}
			filterResSql(args, querySql, sb, allowIds);
		}
	}

	private void filterResSql(Object[] args, String querySql, StringBuilder sb,
			String allowIds) {
		
		if(querySql.contains(WHERE_STR)) {
			int whereIndex = querySql.lastIndexOf(WHERE_STR);
			sb.append(querySql.substring(0, whereIndex));
			sb.append("where tbl_apk_info.id in (");
			sb.append(allowIds).append(") and ");
			sb.append(querySql.substring(whereIndex + WHERE_STR.length()));
			args[0] = sb.toString();
		}
		else {
			querySql = querySql.replaceAll("\\s", " ");
			int fromIndex = querySql.lastIndexOf("from tbl_apk_info");
			if(fromIndex == -1) return;
			
			sb.append(querySql.substring(0, fromIndex+ "from tbl_apk_info".length()));
			String lastSql = querySql.substring(fromIndex+ "from tbl_apk_info".length());
			sb.append(" where tbl_apk_info.id in (");
			sb.append(allowIds).append(") ");
			sb.append(lastSql);
			args[0] = sb.toString();
		}
	}
}
