package cn.nubia.rbac.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import cn.nubia.admin.common.PagerBean;
import cn.nubia.admin.model.AdminLog;
import cn.nubia.framework.util.DateUtil;
import cn.nubia.rbac.service.AdminLogService;

@Service(value = "adminLogService")
public class AdminLogServiceImpl implements AdminLogService {
	@Resource
	protected JdbcTemplate template;
	
	private final static int MAX_SIZE = 1000000;

	@Override
	public PagerBean<AdminLog> listByPage(AdminLog log,
			PagerBean<AdminLog> pager) {

		String rowsSql = "select username,ip,params,url, add_time,action_type from tbl_admin_log order by add_time desc limit ?,?";
		List<AdminLog> rows = this.template.query(rowsSql,
				new Object[] { pager.getOffset(), pager.getLimit() },
				new AdminLogMapper());
		pager.setRows(rows);

		String totalSql = "select count(1) from tbl_admin_log";
		int total = this.template.queryForObject(totalSql, Integer.class);
		pager.setTotal(total);
		return pager;
	}
	
	@Scheduled(cron="0 0 1 * * ?")
	public void cronDelAdminLog() {
		String totalSql = "select count(1) from tbl_admin_log";
		int total = this.template.queryForObject(totalSql, Integer.class);
		if(total > MAX_SIZE) {
			String delSql = "delete from tbl_admin_log order by add_time  limit " + (total-MAX_SIZE);
			this.template.update(delSql);
		}
	}
}
class AdminLogMapper implements RowMapper<AdminLog> {
	public AdminLog mapRow(ResultSet rs, int index) throws SQLException {
		AdminLog log = new AdminLog();
		log.setUsername(rs.getString("username"));
		log.setIp(rs.getString("ip"));
		log.setUrl(rs.getString("url"));
		log.setActionType(rs.getString("action_type"));
		log.setTimeStr(DateUtil.DATETIME_YMDHMS.format(rs.getTimestamp("add_time")));
		log.setParamsJson(rs.getString("params"));
		return log;
	}
}
