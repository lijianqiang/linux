package cn.nubia.rbac.service;

import cn.nubia.admin.common.PagerBean;
import cn.nubia.admin.model.AdminLog;


public interface AdminLogService {
    PagerBean<AdminLog> listByPage(AdminLog log, PagerBean<AdminLog> pager);
}
