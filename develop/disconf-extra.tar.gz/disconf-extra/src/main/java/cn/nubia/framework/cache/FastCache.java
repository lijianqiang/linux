package cn.nubia.framework.cache;

import java.util.concurrent.ConcurrentHashMap;


/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class FastCache extends AbstractCache {	

	public FastCache(String name){
		this(name,DEFAULT_MAX_SIZE);
	}
	
	public FastCache(String name,int maxSize){
		this.name=name;
		this.maxSize=maxSize;
		this.map=new ConcurrentHashMap<Object,Element>();
	}
}
