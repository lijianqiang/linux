package cn.nubia.framework.cache;

import java.io.Serializable;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public final class Element implements Serializable, Cloneable{
	
	
	private long createTime;
	private long lastAccessTime;
	private long lastUpdateTime;
	private int hitCount;
	//private int missCount;
	
	private final Object key;
	private final Object value;
	
	public Element(Object key,Object value){
		long now=System.currentTimeMillis();
		this.key=key;
		this.value=value;
		this.createTime=now;
		this.lastUpdateTime=now;
		this.hitCount=0;
	}
	
	public final Object getKey(){
		return this.key;
	}
	
	public final Object getValue(){
		return this.value;
	}
	
	public final int getHitCount(){
		return this.hitCount;
	}
	
	//public final int getMissCount(){
	//	return this.missCount;
	//}
	
	public final long getCreateTime(){
		return this.createTime;
	}
	
	public final long getLastAccessTime(){
		return this.lastAccessTime;
	}
	
	public final long getLastUpdateTime(){
		return this.lastUpdateTime;
	}
	
	public final long getIdle(){
		return this.createTime-this.lastAccessTime;
	}
	
    public final void resetAccessStatistics() {
        lastAccessTime = 0;
        hitCount = 0;
    }
	
	public final void updateHitStatistics() {
        lastAccessTime = System.currentTimeMillis();
        hitCount++;
    }
	
	//public final void updateMissStatistics() {
    //    lastAccessTime = System.currentTimeMillis();
    //    missCount++;
    //}
	
    public final void updateUpdateStatistics() {
        lastUpdateTime = System.currentTimeMillis();
    }
    
    public final boolean equals(Object object) {
        if (object == null || !(object instanceof Element)) {
            return false;
        }
        Element element = (Element) object;
        if (key == null || element.getKey() == null) {
            return false;
        }
        return key.equals(element.getKey());
    }
    
    public final int hashCode() {
        return key.hashCode();
    }
    
    public final String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("[ key = ").append(key)
                .append(", value=").append(value)
                .append(", hitCount=").append(hitCount)
                .append(", createTime = ").append(createTime)
                .append(", lastAccessTime = ").append(lastAccessTime)
                .append(", lastUpdateTime = ").append(lastUpdateTime)
                .append(" ]");

        return sb.toString();
    }
}
