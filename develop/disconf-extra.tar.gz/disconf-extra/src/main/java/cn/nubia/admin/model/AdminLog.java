package cn.nubia.admin.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class AdminLog implements Serializable {

	private static final long serialVersionUID = 1L;
	private String username;
	private String ip;
	private Timestamp addTime;
	private String timeStr;
	private String res;//资源名称（可以进行配置）
	private String url;
	private String actionType;
	private Map<String, String> currentData = new ConcurrentHashMap<String, String>();
	private Map<String, String> orginData = new ConcurrentHashMap<String, String>();
	private Map<String, String> params = new ConcurrentHashMap<String, String>();
	private String paramsJson;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public Timestamp getAddTime() {
		return addTime;
	}

	public void setAddTime(Timestamp addTime) {
		this.addTime = addTime;
	}

	public String getRes() {
		return res;
	}

	public void setRes(String res) {
		this.res = res;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}


	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public Map<String, String> getCurrentData() {
		return currentData;
	}

	public void setCurrentData(Map<String, String> currentData) {
		this.currentData = currentData;
	}

	public Map<String, String> getOrginData() {
		return orginData;
	}

	public void setOrginData(Map<String, String> orginData) {
		this.orginData = orginData;
	}

	public Map<String, String> getParams() {
		return params;
	}

	public void setParams(Map<String, String> params) {
		this.params = params;
	}

	public String getParamsJson() {
		return paramsJson;
	}

	public void setParamsJson(String paramsJson) {
		this.paramsJson = paramsJson;
	}

	public String getTimeStr() {
		return timeStr;
	}

	public void setTimeStr(String timeStr) {
		this.timeStr = timeStr;
	}

}
