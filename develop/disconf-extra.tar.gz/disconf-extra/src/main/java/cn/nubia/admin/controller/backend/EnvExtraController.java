package cn.nubia.admin.controller.backend;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baidu.disconf.web.service.env.bo.Env;
import com.baidu.disconf.web.service.env.service.EnvMgr;
import com.baidu.disconf.web.service.env.vo.EnvListVo;
import com.baidu.dsp.common.controller.BaseController;
import com.baidu.dsp.common.vo.JsonObjectBase;

import cn.nubia.admin.ExtraConstant;
import cn.nubia.admin.common.Result;
import cn.nubia.admin.model.UserEnv;
import cn.nubia.admin.service.EnvExtraService;
import cn.nubia.admin.service.UserEnvService;
import cn.nubia.framework.core.ActionContext;
import cn.nubia.framework.util.StringUtil;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.util.Define;

/**
 * @author lijianqiang
 * @version 2016-10-18
 */
@Controller
@RequestMapping(ExtraConstant.API_PREFIX + "/env")
public class EnvExtraController extends BaseController {

    protected static final Logger LOG = LoggerFactory.getLogger(EnvExtraController.class);

    @Autowired
    private EnvMgr envMgr;
    
    @Autowired
    private EnvExtraService envExtraService;
    
    @Autowired
    private UserEnvService userEnvService;

    /**
     * list with permit ，改造原来的，加权限返回
     *
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ResponseBody
    public JsonObjectBase list() {

        //List<EnvListVo> envListVos = envMgr.getVoList();
    	SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
    	List<EnvListVo> envListVos = buildList(sysUser);

        return buildListSuccess(envListVos, envListVos.size());
    }
    
    
    private List<EnvListVo> buildList(SysUser sysUser) {
    	ArrayList<EnvListVo> result = new ArrayList<EnvListVo>();
    	if (sysUser == null) {
			return result;
    	}
    	
    	List<UserEnv> envList = userEnvService.buildUserEnvList(sysUser.getId());
    	if (envList == null || envList.isEmpty()) {
    		return result;
    	}
    	
    	for (UserEnv ue : envList) {
    		if (ue.getUserId() == sysUser.getId()) {
    			EnvListVo obj = new EnvListVo();
    			obj.setId(ue.getEnvId());
    			obj.setName(ue.getEnvName());
				result.add(obj);
    		}
    	}
		return result;
	}


	/**
     * list all， 新增
     *
     * @return
     */
    @RequestMapping(value = "/listall", method = RequestMethod.GET)
    @ResponseBody
    public String listAll() {

        List<EnvListVo> envListVos = envMgr.getVoList();

        return Result.returnDataResult(envListVos);
    }
    
    /**
     * 添加或修改页面， 新增
     */
    @ResponseBody
    @RequestMapping("/edit")
    public String edit(Env env){
    	if (env == null || StringUtil.isEmpty(env.getName())) {
    		return Result.returnFailResult("name is null");
    	}
        if(env.getId() == null){
        	envExtraService.add(env);
        }else{
        	envExtraService.update(env);
        }
        return Result.returnSuccResult();
    }
    
    /**
     * 删除， 新增
     */
    @ResponseBody
    @RequestMapping("/delete")
    public String delete(Long id){
    	envExtraService.delete(id);
    	userEnvService.deleteByEnvId(id);
        return Result.returnSuccResult();
    }

}
