package cn.nubia.framework.crypto.provider;

/**
 * 
 * CRC16-CCITT
 * 0x1021
 * x^16 + x^12 + x^5 + 1
 *  
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 28, 2015 5:26:51 PM by jxva
 */
public class Crc16Ccitt2 {

	private static final int POLY = 0x1021;
	
	private int value;

	public Crc16Ccitt2() {
		value = 0x0000;
	}

	public void update(byte b) {
		int a = (int) b;
		for (int count = 7; count >= 0; count--) {
			a = a << 1;
			int t = (a >>> 8) & 1;
			if ((value & 0x8000) != 0) {
				value = ((value << 1) + t) ^ POLY;
			} else {
				value = (value << 1) + t;
			}
		}
		value = value & 0xffff;
	}

	public void update(byte[] data) {
		for (int i = 0; i < data.length; i++) {
			update(data[i]);
		}
	}

	public int value() {
		return value;
	}
	
	public String checksum(byte[] data){
		reset();
		update(data);
		//String v = Integer.toHexString(value);
		return String.format("%04x", value);
	}

	public void reset() {
		value = 0x0000;
	}
}
