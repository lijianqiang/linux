package cn.nubia.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.baidu.disconf.web.service.env.bo.Env;

import cn.nubia.admin.model.UserEnv;
import cn.nubia.admin.service.EnvExtraService;
import cn.nubia.admin.service.UserEnvService;

@Service("userEnvService")
public class UserEnvServiceImpl implements UserEnvService {

	@Resource(name = "onedbJdbcTemplate")
	protected JdbcTemplate jdbcTemplate;

	private static final String COLUMN_SQL = "id, user_id, env_id";
	
	@Autowired
	private EnvExtraService envExtraService;

	@Override
	public UserEnv getById(int id) {
		String sql = "select " + COLUMN_SQL + " FROM tbl_user_env WHERE id = ?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, UserEnv.class);
	}

	@Override
	public void save(int userId, List<Integer> envIds) {
		deleteByUserId(userId);
		if (envIds == null || envIds.isEmpty()) {
			return;
		}
		for (Integer envId : envIds) {
			add(userId, envId);
		}
		
	}
	
	private void add(int userId, int envId) {
		String sql = "insert into tbl_user_env(user_Id, env_id) values(?, ?)";
		jdbcTemplate.update(sql, userId, envId);
	}

	@Override
	public List<UserEnv> getByUserId(int userId) {
		String sql = "SELECT " + COLUMN_SQL + " FROM tbl_user_env WHERE user_id = ?";
		return jdbcTemplate.query(sql, new Object[] { userId }, new BeanPropertyRowMapper<UserEnv>(UserEnv.class));
	}

	@Override
	public void deleteByUserId(int userId) {
		String sql = "delete FROM tbl_user_env WHERE user_id = ?";
		jdbcTemplate.update(sql, userId);
	}

	@Override
	public List<UserEnv> buildUserEnvList(int userId) {
		List<Env> all = envExtraService.getAll();
		if (all == null || all.isEmpty()) {
			return new ArrayList<UserEnv>();
		}
		Map<Long, UserEnv> envmap = new HashMap<Long, UserEnv>();
		for (Env e : all) {
			envmap.put(e.getId(), new UserEnv(e.getId(), e.getName()));
		}
		List<UserEnv> users = getByUserId(userId);
		if (users == null || users.isEmpty()) {
			return new ArrayList<UserEnv>(envmap.values());
		}
		for(UserEnv ue : users) {
			UserEnv obj = envmap.get(ue.getEnvId());
			if (obj != null) {
				obj.setUserId(userId);
				envmap.put(ue.getEnvId(), obj);
			}
		}
		
		return new ArrayList<UserEnv>(envmap.values());
	}

	@Override
	public void deleteByEnvId(long envId) {
		String sql = "delete FROM tbl_user_env WHERE env_id = ?";
		jdbcTemplate.update(sql, envId);
	}

}
