package cn.nubia.rbac.tag;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import cn.nubia.framework.util.StringUtil;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.util.Define;


public class PrivilegeTag extends TagSupport{
	
	private static final long serialVersionUID = 1L;
	
	private String test;

	public void setTest(String test) {
		this.test = test;
	}	

	public int doStartTag() throws JspException{
		SysUser user=(SysUser)pageContext.getSession().getAttribute(Define.SESSION_IN_USER);
		if(user.getMenus()!=null) {
			if(StringUtil.isEmpty(test)) return SKIP_BODY;
			if(user.getMenus().containsKey(test)) return EVAL_BODY_INCLUDE;
			
			String[] testArray = test.split("\\|");
			for(String str :  testArray) {
				if(user.getMenus().containsKey(str)) return EVAL_BODY_INCLUDE;
			}
			
			return SKIP_BODY;
		}
		else {
			return SKIP_BODY;
		}
	}
	
	public int doEndTag() throws JspException {
		return EVAL_PAGE;
	}
	
	public void release() {
		super.release();
		test = null;
	}
}
