package cn.nubia.framework.crypto.provider;

/**
 * 
 * CRC16-CCITT (0xFFFF) 0x1021 x^16 + x^12 + x^5 + 1
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 28, 2015 5:26:51 PM by jxva
 */
public class Crc16Ccitt {

	private static final int POLY = 0x1021;

	private int value;

	public Crc16Ccitt() {
		value = 0xffff;
	}

	public void update(byte b) {
		for (int i = 0; i < 8; i++) {
			boolean bit = ((b >> (7 - i) & 1) == 1);
			boolean c15 = ((value >> 15 & 1) == 1);
			value <<= 1;
			if (c15 ^ bit) {
				value ^= POLY;
			}
		}
		value = value & 0xffff;
	}

	public void update(byte[] data) {
		for (int i = 0; i < data.length; i++) {
			update(data[i]);
		}
	}

	public int value() {
		return value;
	}

	public String checksum(byte[] data) {
		reset();
		update(data);
		// String v = Integer.toHexString(value);
		return String.format("%04x", value);
	}

	public void reset() {
		value = 0xffff;
	}
	
	/**
	 * CRC-CCITT (0xFFFF)
	 */
	/*
	public static int crc16(final byte[] buffer) {
	    int crc = 0xffff;

	    for (int j = 0; j < buffer.length ; j++) {
	        crc = ((crc  >>> 8) | (crc  << 8) )& 0xffff;
	        crc ^= (buffer[j] & 0xff);//byte to int, trunc sign
	        crc ^= ((crc & 0xff) >> 4);
	        crc ^= (crc << 12) & 0xffff;
	        crc ^= ((crc & 0xff) << 5) & 0xffff;
	    }
	    crc &= 0xffff;
	    return crc;
	} */
}
