package cn.nubia.admin;

public class ExtraConstant {
	/**
     * 扩展后服务端Controller api前缀，在jsp端调用
     */
    public static final String API_PREFIX = "/extra";
    
    /**
     * 扩展后服务端Controller web前缀，在jsp端调用
     */
    public static final String WEB_PREFIX = "/page";

}
