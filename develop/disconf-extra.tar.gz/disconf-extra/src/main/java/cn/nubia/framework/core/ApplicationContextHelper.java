package cn.nubia.framework.core;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class ApplicationContextHelper implements ApplicationContextAware {
	
    private static ApplicationContext appCtx;

    @Override
    public void setApplicationContext( ApplicationContext applicationContext ) throws BeansException {
        appCtx = applicationContext;
    }

    public static Object getBean( String beanName ) {
        return appCtx.getBean( beanName );
    }
    
    public static <T> T getBean(Class<T> clz) {
        return (T)appCtx.getBean(clz);
    }
}
