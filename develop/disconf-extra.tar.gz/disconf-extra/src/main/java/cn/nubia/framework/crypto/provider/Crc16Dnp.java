package cn.nubia.framework.crypto.provider;

/**
 * CRC16-DNP
 * 0x3D65
 * x^16 + x^13 + x^12 + x^11 + x^10 + x^8 + x^6 + x^5 + x^2 + 1 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 29, 2015 11:20:02 AM by jxva
 */
public class Crc16Dnp {

}
