package cn.nubia.framework.crypto;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Dec 17, 2014 11:03:14 AM by jxva
 */
public enum CipherMode {
	CBC, CFB, CTR, ECB, NCFB, NOFB, OFB, STREAM
	//, PCBC, GCM
}
