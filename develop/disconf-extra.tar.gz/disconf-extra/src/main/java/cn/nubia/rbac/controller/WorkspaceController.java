package cn.nubia.rbac.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import cn.nubia.admin.common.Result;
import cn.nubia.admin.util.ApplicationProperty;
import cn.nubia.framework.core.ActionContext;
import cn.nubia.framework.crypto.Hash;
import cn.nubia.framework.util.StringUtil;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.service.SysUserService;
import cn.nubia.rbac.util.Define;
@Controller
@RequestMapping("/workspace")
public class WorkspaceController extends BaseController{
	private static final String INDEX = "/";
	@Resource(name="sysUserService")
	private SysUserService sysUserService;
	
	/**
	 * @param request r
	 * @return ModelAndView
	 */
	@RequestMapping("/workspace")
	public ModelAndView execute(HttpServletRequest request){
		SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
		if(sysUser==null) {
			return new ModelAndView(INDEX);
		}
		/*List<Menu> list = menuService.findOneLevel();*/
		ModelAndView view = new ModelAndView("workspace");
		view.addObject("username", sysUser.getUsername());
		view.addObject("userId", sysUser.getId());
		
		String version = ApplicationProperty.getProperty("build.version");
		version = StringUtil.isEmpty(version) ? "unknown" : version;
		view.addObject("version", version);
		return view;
	}
	
	@RequestMapping("/editPassword")
	public ModelAndView toEditPassword(HttpServletRequest request){
		return new ModelAndView("editPassword");
	}
	
	@RequestMapping("/savePassword")
	@ResponseBody
	public String savePassword(HttpServletRequest request,Model model){
		SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
		SysUser employee = sysUserService.getSysUserByUsername(sysUser.getUsername());		
		if(employee.getPassword().equals(Hash.hmac(Hash.MD5,getParam("oldPassword",request),Define.KEY))){
			employee.setPassword(Hash.hmac(Hash.MD5,getParam("newPassword",request),Define.KEY));
			sysUserService.updatePassword(sysUser.getId(), employee.getPassword());
			request.getSession().invalidate();
			 return Result.returnSuccResult();
		}else{
			 return Result.returnFailResult("登录密码错误");
		}
	}
	
}
