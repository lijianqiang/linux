package cn.nubia.framework.cache;

import java.io.Serializable;
import java.util.Map;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public abstract class AbstractCache implements Cache,Cloneable, Serializable {

	private static final long serialVersionUID = 6033731999554511669L;

	protected static final int DEFAULT_MAX_SIZE=100;
	
	protected String name;
	protected Map<Object,Element> map;
	protected int maxSize=DEFAULT_MAX_SIZE;
	
	public final synchronized void clear() {
		map.clear();
	}

	public final synchronized Object getValue(Object key) {
		Element element=get(key);
		return element==null?null:element.getValue();
	}
	
	public final synchronized Object getQuietValue(Object key) {
		Element element=getQuiet(key);
		return element==null?null:element.getValue();
	}

	public final synchronized void put(Object key, Object value) {
		put(new Element(key,value));
	}

	public final synchronized Element remove(Object key) {
		return map.remove(key);
	}

	public final int size() {
		return map.size();
	}
	
	public final boolean containsKey(Object key){
		return map.containsKey(key);
	}

	public final synchronized void dispose() {
		map.clear();
		map=null;		
	}

	public final synchronized Element get(Object key) {
		Element element=getElement(key);
		if(element!=null){
			element.updateHitStatistics();
		}
		return element;
	}

	public final synchronized Element getQuiet(Object key) {
		return getElement(key);
	}
	
	private final Element getElement(Object key){
		return map.get(key);
	}

	public final synchronized void put(Element element) {
		if (element != null) {
			map.put(element.getKey(),element);
			doPut(element);
		}
	}

	public final synchronized Object[] getKeys() {
		return map.keySet().toArray();
	}

	public final String getName() {
		return name;
	}
	
	public final boolean isEmpty() {
		return map.isEmpty();
	}
	
    protected final boolean isFull() {
        return map.size() > maxSize;
    }
	
    protected void doPut(Element element) throws CacheException {
        //empty
    }
}
