package cn.nubia.framework.core;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class ActionContext {
	
	public static final String PAGE_CONTEXT="pageContext";
	public static final String REQUEST="request";
	public static final String RESPONSE="response";
	public static final String SESSION="session";
	public static final String APPLICATION="application";

	private static final String TAG="tag";
	
	private static ThreadLocal<ConcurrentMap<String, Object>> THREADLOCAL = new ThreadLocal<ConcurrentMap<String, Object>>() {
		@Override
		protected synchronized ConcurrentMap<String, Object> initialValue() {
			return new ConcurrentHashMap<String, Object>();
		}
	};
	
	public static void setContext(HttpServletRequest request,HttpServletResponse response) {
		ConcurrentMap<String,Object> map=THREADLOCAL.get();
		map.put(REQUEST,request);
		map.put(RESPONSE,response);
		final Map<String,Object> context=new HashMap<String,Object>();
		context.put(ActionContext.REQUEST,request);
		context.put(ActionContext.SESSION,request.getSession(true));
		map.put(TAG,context);
	}
	
	public static void removeContext(){
		THREADLOCAL.remove();
	}
	
	public static HttpServletRequest getRequest() {
		return (HttpServletRequest)THREADLOCAL.get().get(REQUEST);
	}
	
	public static HttpServletResponse getResponse() {
		return (HttpServletResponse)THREADLOCAL.get().get(RESPONSE);
	}
	
	public static HttpSession getSession(){
		return getRequest().getSession(true);
	}
	
	public static HttpCookie getCookie(){
		Map<String,Object> map=THREADLOCAL.get();
		return new HttpCookie((HttpServletRequest)map.get(REQUEST),(HttpServletResponse)map.get(RESPONSE));
	}
	
	
	@SuppressWarnings("unchecked")
	public static Map<String,Object> getTagContext(){
		return (Map<String,Object>)THREADLOCAL.get().get(TAG);
	}
}
