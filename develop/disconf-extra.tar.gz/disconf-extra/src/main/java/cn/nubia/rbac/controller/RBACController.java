package cn.nubia.rbac.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import cn.nubia.admin.common.PagerBean;
import cn.nubia.admin.common.Result;
import cn.nubia.admin.model.AdminLog;
import cn.nubia.admin.model.UserEnv;
import cn.nubia.admin.service.AppExtraService;
import cn.nubia.admin.service.UserEnvService;
import cn.nubia.framework.core.ActionContext;
import cn.nubia.framework.crypto.Hash;
import cn.nubia.rbac.model.DynamicRes;
import cn.nubia.rbac.model.DynamicResType;
import cn.nubia.rbac.model.Menu;
import cn.nubia.rbac.model.Role;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.service.AdminLogService;
import cn.nubia.rbac.service.DynamicResService;
import cn.nubia.rbac.service.MenuService;
import cn.nubia.rbac.service.RoleService;
import cn.nubia.rbac.service.SysUserService;
import cn.nubia.rbac.util.Define;

@Controller
@RequestMapping("/rbac")
public class RBACController extends BaseController {

	private static final String STR_SPLIT_COMMA = ",";
	private static final String STR_SPLIT_VERT = "\\|";
	private static final String STR_SPLIT_SEM = ";";

	private static final Log logger = LogFactory.getLog(RBACController.class);
	@Resource
	private RoleService roleService;
	@Resource
	private SysUserService sysUserService;
	@Resource
	private MenuService menuService;
	@Resource
	private DynamicResService dynamicResService;
	@Resource
	private AdminLogService adminLogService;
	
	@Autowired
    private AppExtraService appExtraService;
	
	@Autowired
    private UserEnvService userEnvService;
	
	private String getUpperStart(String str) {
		assert StringUtils.isNotBlank(str);
		return str.toUpperCase().substring(0, 1).concat(str.substring(1));
	}

	@RequestMapping("/page/{module}/list")
	public ModelAndView listRolePage(@PathVariable(value = "module") String module) {
		return new ModelAndView("rbac/list" + getUpperStart(module));
	}

	@RequestMapping("/page/{module}/save")
	public ModelAndView saveRolePage(@PathVariable(value = "module") String module) {
		ModelAndView modelAndView = new ModelAndView("rbac/add" + getUpperStart(module));
		if ("user".equals(module)) {
			SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
			List<UserEnv> envList = userEnvService.buildUserEnvList(sysUser.getId());
			modelAndView.addObject("envList", envList);
		}
		return modelAndView;
	}

	/************************************
	 * 角色模块功能 *
	 ************************************/
	@ResponseBody
	@RequestMapping("/role/list")
	public String listRole() {
		logger.info("[rbac] list role ... ");
		return Result.returnDataResult(roleService.fetchAll());
	}

	@ResponseBody
	@RequestMapping("/role/save")
	public String saveRole(Role role) {
		logger.info("[rbac] save role ... ");
		roleService.save(role);
		return Result.returnSuccResult();
	}

	@ResponseBody
	@RequestMapping("/role/delete")
	public String deleteRole(Integer id) {
		logger.info("[rbac] delete role ... ");
		if (id == null || id < 0) {
			return Result.returnFailResult("参数非法");
		}
		//与此角色有依赖关系的，则无法删除
		if(this.sysUserService.existedByRoleId(id)) {
			return Result.returnFailResult("有此角色有用户关联，无法删除！");
		}
		roleService.delete(id);
		return Result.returnSuccResult();
	}

	@RequestMapping("/page/role/update")
	public ModelAndView updateRolePage(HttpServletRequest request) {
		String idStr = request.getParameter("id");
		Integer id = 0;
		if (StringUtils.isBlank(idStr)) {
			return null;
		}

		else {
			id = Integer.valueOf(idStr);
		}

		Role role = roleService.getById(id);
		request.setAttribute("role", role);
		return new ModelAndView("rbac/addRole");
	}

	@ResponseBody
	@RequestMapping("/role/update")
	public String updateRole(Role role) {
		logger.info("[rbac] update role ... ");
		if (role == null || role.getId() == null) {
			logger.error("[rbac] update role the param role is null");
			return Result.returnFailResult("参数非法");
		}
		if (role.getId() == null || role.getId() < 0) {
			logger.error("[rbac] update role the param role id is "
					+ role.getId());
			return Result.returnFailResult("参数非法");
		} else {
			this.roleService.update(role);
		}
		return Result.returnSuccResult();
	}
	
	
	/**
	 * 功能：将资源权限设置到request由页面查阅
	 * 注意：
	 * @param request
	 * @return
	 * 2015年10月16日 下午3:56:41
	 * gsd
	 */
	@RequestMapping("/page/role/permit")
	public ModelAndView permitRolePage(HttpServletRequest request) {
		String idStr = request.getParameter("id");
		Integer id = 0;
		if (StringUtils.isBlank(idStr)) {
			return null;
		}

		else {
			id = Integer.valueOf(idStr);
		}

		Role role = roleService.getById(id);
		//菜单权限
		List<Integer> menuIds = this.menuService.fetchMenuIdsByRoleId(id);
		//数据资源权限
		List<Integer> resIds = this.dynamicResService.fetchResByRoleId(id);
		
		request.setAttribute("role", role);
		request.setAttribute("menuIds", menuIds);
		request.setAttribute("resIds", resIds);
		return new ModelAndView("rbac/addPermit");
	}
	
	@ResponseBody
	@RequestMapping("/role/checkname")
	public String checkRolename(String name, Integer roleId) {
		if(StringUtils.isBlank(name)) {
			return Result.returnFailResult("角色名称不能为空");
		}
		if(this.roleService.existedNameWithOther(name, roleId)) {
			return Result.returnFailResult("角色名称已经存在");
		}
		return Result.returnSuccResult();
	}

	/************************************
	 * 用户模块功能 *
	 ************************************/
	@ResponseBody
	@RequestMapping("/user/list")
	public String listUser() {
		logger.info("[rbac] list user ... ");
		return Result.returnDataResult(sysUserService.fetchAll());
	}

	@ResponseBody
	@RequestMapping("/user/save")
	public String saveUser(SysUser user, HttpServletRequest request) {
		logger.info("[rbac] save user ... ");
		user.setPassword(Hash.hmac(Hash.MD5, Define.DEFAULT_PASSWORD,
				Define.KEY));
		
		String envIds = request.getParameter("envIds");
		List<Integer> envList = getStringInts(envIds);
		String roleIds = request.getParameter("roleIds");
		List<Integer> roleIdInts = getStringInts(roleIds);
		sysUserService.saveRole(user, roleIdInts, envList);
		
		
		return Result.returnSuccResult();
	}

	private List<Integer> getStringInts(String str) {
		if(StringUtils.isEmpty(str)) {
			return new ArrayList<Integer>();
		}
		List<Integer> ints = new ArrayList<>();
		for (String id : str.split(STR_SPLIT_COMMA)) {
			ints.add(Integer.parseInt(id));
		}
		return ints;
	}

	@ResponseBody
	@RequestMapping("/user/delete")
	public String deleteUser(Integer id) {
		logger.info("[rbac] delete user ... ");
		if (id == null || id < 0) {
			return Result.returnFailResult("参数非法");
		}
		sysUserService.delete(id);
		return Result.returnSuccResult();
	}

	@RequestMapping("/page/user/update")
	public ModelAndView updateUserPage(HttpServletRequest request) {
		String idStr = request.getParameter("id");
		Integer id = 0;
		if (StringUtils.isBlank(idStr)) {
			return null;
		}

		else {
			id = Integer.valueOf(idStr);
		}

		SysUser user = sysUserService.getById(id);
		List<Integer> roleIds = sysUserService.fetchRoleIdsByUserId(id);
		request.setAttribute("user", user);
		request.setAttribute("roleIds", roleIds);
		
		List<UserEnv> envList = userEnvService.buildUserEnvList(id);
		request.setAttribute("envList", envList);
		
		return new ModelAndView("rbac/addUser");
	}

	@ResponseBody
	@RequestMapping("/user/update")
	public String updateUser(SysUser user, HttpServletRequest request) {
		logger.info("[rbac] update user ... ");
		if (user == null || user.getId() == null) {
			logger.error("[user] update user the param user is null");
			return Result.returnFailResult("参数非法");
		}
		if (user.getId() == null || user.getId() < 0) {
			logger.error("[rbac] update user the param user id is "
					+ user.getId());
			return Result.returnFailResult("参数非法");
		} else {
			String envIds = request.getParameter("envIds");
			List<Integer> envList = getStringInts(envIds);
			String roleIds = request.getParameter("roleIds");
			List<Integer> roleIdInts = getStringInts(roleIds);
			sysUserService.updateRole(user, roleIdInts, envList);
		}
		
		return Result.returnSuccResult();
	}
	
	@ResponseBody
	@RequestMapping("/user/checkname")
	public String checkname(String username, Integer userId) {
		if(StringUtils.isBlank(username)) {
			return Result.returnFailResult("用户名不能为空");
		}
		if(this.sysUserService.existedUsernameWithOther(username, userId)) {
			return Result.returnFailResult("用户名已经存在");
		}
		return Result.returnSuccResult();
	}

	
	/************************************
	 * 静态菜单资源模块功能 *
	 ************************************/
	@ResponseBody
	@RequestMapping("/menu/list")
	public String listMenu() {
		logger.info("[rbac] list menu ... ");
		return Result.returnDataResult(menuService.fetchAll());
	}

	@ResponseBody
	@RequestMapping("/menu/save")
	public String saveMenu(Menu menu) {
		logger.info("[rbac] save menu ... ");
		menuService.save(menu);
		return Result.returnSuccResult();
	}

	@ResponseBody
	@RequestMapping("/menu/checktitle")
	public String checkMenuTitle(String title, Integer menuId) {
		if(StringUtils.isBlank(title)) {
			return Result.returnFailResult("菜单名称不能为空");
		}
		if(this.menuService.existedTitleWithOther(title, menuId)) {
			return Result.returnFailResult("菜单名称已经存在");
		}
		return Result.returnSuccResult();
	}
	
	@ResponseBody
	@RequestMapping("/menu/checkmainhref")
	public String checkMenuMainHref(String mainHref, Integer menuId) {
		if(StringUtils.isBlank(mainHref)) {
			return Result.returnFailResult("菜单主链接不能为空");
		}
		if(this.menuService.existedMainHrefWithOther(mainHref, menuId)) {
			return Result.returnFailResult("菜单主链接已经存在");
		}
		return Result.returnSuccResult();
	}

	@ResponseBody
	@RequestMapping("/menu/delete")
	public String deleteMenu(Integer id) {
		logger.info("[rbac] delete menu ... ");
		if (id == null || id < 0) {
			return Result.returnFailResult("参数非法");
		}
		//如果menu有被使用了则无法删除
		if(this.roleService.existedByMenuId(id)) {
			return Result.returnFailResult("此菜单资源有角色已分配使用，无法删除！");
		}
		menuService.delete(id);
		return Result.returnSuccResult();
	}

	@RequestMapping("/page/menu/update")
	public ModelAndView updateMenuPage(HttpServletRequest request) {
		String idStr = request.getParameter("id");
		Integer id = 0;
		if (StringUtils.isBlank(idStr)) {
			return null;
		}

		else {
			id = Integer.valueOf(idStr);
		}

		Menu menu = menuService.getById(id);
		request.setAttribute("menu", menu);
		return new ModelAndView("rbac/addMenu");
	}

	@ResponseBody
	@RequestMapping("/menu/update")
	public String updateMenu(Menu menu, HttpServletRequest request) {
		logger.info("[rbac] update menu ... ");
		if (menu == null) {
			logger.error("[menu] update menu the param user is null");
			return Result.returnFailResult("参数非法");
		}
		if (menu.getId() == null) {
			logger.error("[menu] update user the param menu id is "
					+ menu.getId());
			return Result.returnFailResult("参数非法");
		} else {
				menuService.update(menu);
		}
		return Result.returnSuccResult();
	}
	
	/************************************
	 * 动态资源模块功能 *
	 ************************************/
	
	@RequestMapping("/page/res/save")
	public ModelAndView saveResPage(HttpServletRequest request) {
		List<DynamicResType> resTypeList = this.dynamicResService.fetchTypeAll();
		request.setAttribute("resTypeList", resTypeList);
		return new ModelAndView("rbac/addRes");
	}
	
	@ResponseBody
	@RequestMapping("/res/list")
	public String listDynamicRes(HttpServletRequest request) {
		logger.info("[rbac] list listDynamicRes ... ");
		String roleId = request.getParameter("roleId");
		if(StringUtils.isEmpty(roleId)) {
			return Result.returnDataResult(dynamicResService.fetchAll());
		}
		else {
			//角色资源id号
			return Result.returnDataResult(dynamicResService.fetchResRecordsByRoleId(Integer.parseInt(roleId)));
		}
	}

	@ResponseBody
	@RequestMapping("/res/save")
	public String saveDynamicRes(DynamicRes res) {
		logger.info("[rbac] save res ... ");
		dynamicResService.save(res);
		return Result.returnSuccResult();
	}


	@ResponseBody
	@RequestMapping("/res/delete")
	public String deleteDynamicRes(Integer id) {
		logger.info("[rbac] delete res ... ");
		if (id == null || id < 0) {
			return Result.returnFailResult("参数非法");
		}
		
		//如果操作资源使用了则无法删除
		if(this.roleService.existedByDynamicResId(id)) {
			return Result.returnFailResult("此操作资源有角色已分配使用，无法删除！");
		}
		dynamicResService.delete(id);
		return Result.returnSuccResult();
	}
	@ResponseBody
	@RequestMapping("/res/checktitle")
	public String checkResTitle(String title, Integer resId) {
		if(StringUtils.isBlank(title)) {
			return Result.returnFailResult("操作资源名称不能为空");
		}
		if(this.dynamicResService.existedTitleWithOther(title, resId)) {
			return Result.returnFailResult("操作资源名称已经存在");
		}
		return Result.returnSuccResult();
	}
	
	@ResponseBody
	@RequestMapping("/res/checkmainhref")
	public String checkResMainHref(String mainHref, Integer resId) {
		if(StringUtils.isBlank(mainHref)) {
			return Result.returnFailResult("操作资源主链接不能为空");
		}
		if(this.dynamicResService.existedMainHrefWithOther(mainHref, resId)) {
			return Result.returnFailResult("操作资源主链接已经存在");
		}
		return Result.returnSuccResult();
	}
	
	@RequestMapping("/page/res/update")
	public ModelAndView updateDynamicResPage(HttpServletRequest request) {
		String idStr = request.getParameter("id");
		Integer id = 0;
		if (StringUtils.isBlank(idStr)) {
			return null;
		}

		else {
			id = Integer.valueOf(idStr);
		}

		DynamicRes res = dynamicResService.getById(id);
		List<DynamicResType> resTypeList = this.dynamicResService.fetchTypeAll();
		request.setAttribute("res", res);
		request.setAttribute("resTypeList", resTypeList);
		return new ModelAndView("rbac/addRes");
	}

	@ResponseBody
	@RequestMapping("/res/update")
	public String updateDynamicRes(DynamicRes res, HttpServletRequest request) {
		logger.info("[rbac] update res ... ");
		if (res == null) {
			logger.error("[menu] update res the param res is null");
			return Result.returnFailResult("参数非法");
		}
		if (res.getId() == null) {
			logger.error("[menu] update res the param res id is "
					+ res.getId());
			return Result.returnFailResult("参数非法");
		} else {
			dynamicResService.update(res);
		}
		return Result.returnSuccResult();
	}

	/************************************
	 * 权限分配 *
	 ************************************/

	/**
	 * 功能：分配权限
	 * 注意：前端form提交的协议格式如下：
	 * 		=>menuIds: menuId1,menuId2,menuId2   //中间以逗号隔开
	 * 		=>resIds: resId1,resId2,resId3 		//中间以逗号隔开
	 * 		=>resRecordIds:resId1|recordId1,recordId2,recordId3;resId2|recordId1,recordId5
	 * 		=>多个操作资源用分号隔开
	 * 		=>操作资源第一位是操作资源id,后面跟着记录id号（记录id号中间以逗号隔开）
	 * 			resId1|recordId1,recordId2,recordId3
	 * 		=>数据中保存recordIds时候，也是以recordId1,recordId2,recordId3作为整个字段保存，
	 * 			虽然违反数据库设计第一范式，但是简化了很多功能。
	 * @param request
	 * @param roleId
	 * @return
	 * 2015年10月16日 下午3:57:33
	 * gsd
	 */
	@ResponseBody
	@RequestMapping("/permit/update")
	public String updatePermit(HttpServletRequest request, Integer roleId) {
		logger.info("[rbac] update permit ... ");
		
		String menuIds = request.getParameter("menuIds");
		String resIds = request.getParameter("resIds");
		String resRecordIds = request.getParameter("resRecordIds");
		
		List<Integer> menuIdInts = getStringInts(menuIds);
		List<Integer> resInts = getStringInts(resIds);
		Map<Integer, String> resRecordIdsMap = getResMap(resInts, resRecordIds);
		roleService.updatePemit(roleId, menuIdInts, resInts, resRecordIdsMap);
		return Result.returnSuccResult();
	}
	
	private Map<Integer, String> getResMap(List<Integer> resInts,
			String resRecordIds) {
		int RESRCORD_SPLIT_SIZE = 2;
		Map<Integer, String> result = new HashMap<Integer, String>();
		if(resInts != null&& StringUtils.isNotBlank(resRecordIds) ) {
			for(String resRecordId : resRecordIds.split(STR_SPLIT_SEM)) {
				if(StringUtils.isBlank(resRecordId)) continue;
				String[] tmp = resRecordId.split(STR_SPLIT_VERT);
				if(tmp == null || tmp.length < RESRCORD_SPLIT_SIZE) continue;
				Integer resId = Integer.valueOf(tmp[0]);
				if(resInts.contains(resId)) {
					result.put(resId, tmp[1]);
				}
			}
		}
		return result;
	}

	@ResponseBody
	@RequestMapping("/res/app/list")
	public String listAppList() {
		logger.info("[rbac] list All APP ... ");
		return Result.returnDataResult(appExtraService.getAll());
	}
	
	@ResponseBody
	@RequestMapping("/res/app/delete")
	public String listResPermit() {
		SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
		String allowIds  = "";
		Map<String, DynamicRes> res = sysUser.getRes();
		if(res != null && !res.isEmpty()
				&& res.get("app/delete")!=null) {
			allowIds = res.get("app/delete").getResRecordIds();
		}
		return Result.returnDataResult(allowIds);
	}
	
	@ResponseBody
	@RequestMapping("/res/app/upgrade")
	public String listResUpgradePermit() {
		SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
		String allowIds  = "";
		Map<String, DynamicRes> res = sysUser.getRes();
		if(res != null && !res.isEmpty()
				&& res.get("app/upgrade")!=null) {
			allowIds = res.get("app/upgrade").getResRecordIds();
		}
		return Result.returnDataResult(allowIds);
	}
	
	/************************************
	 * 日志文件  *
	 ************************************/
	@ResponseBody
	@RequestMapping("/log/list")
	public String listLog(AdminLog log, PagerBean<AdminLog> pager) {
			adminLogService.listByPage(log, pager);
	     return Result.returnDataResult(pager);
	}
}
