package cn.nubia.admin.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.baidu.disconf.web.service.env.bo.Env;

import cn.nubia.admin.service.EnvExtraService;

@Service("envExtraService")
public class EnvExtraServiceImpl implements EnvExtraService {

	@Resource(name = "onedbJdbcTemplate")
	protected JdbcTemplate jdbcTemplate;

	@Override
	public Env getById(Long id) {
		String sql = "select env_id as id, name from env where env_id = ?";
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, Env.class);
	}

	@Override
	public void add(Env env) {
		String sql = "insert into env(name) values(?)";
		jdbcTemplate.update(sql, env.getName());
	}

	@Override
	public void update(Env env) {
		String sql = "update env set name = ? where env_id = ?";
		jdbcTemplate.update(sql, env.getName(), env.getId());

	}

	@Override
	public void delete(Long id) {
		String sql = "delete from env where env_id = ?";
		jdbcTemplate.update(sql, id);

		String other = "delete from config where env_id = ?";
		jdbcTemplate.update(other, id);

	}

	@Override
	public List<Env> getAll() {
		String sql = "SELECT env_id as id, name from env";
        return jdbcTemplate.query(sql, new Object[]{},new BeanPropertyRowMapper<Env>(Env.class));
	}

}
