package cn.nubia.rbac.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.nubia.framework.core.HttpCookie;
import cn.nubia.framework.crypto.Hash;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.service.SysUserService;
import cn.nubia.rbac.util.Define;
import cn.nubia.rbac.util.RbacCache;
import cn.nubia.rbac.util.RbacDes;

@Controller
@RequestMapping("/login")
public class LoginController extends BaseController {

	@Resource(name = "sysUserService")
	private SysUserService sysUserService;

	@RequestMapping("/check")
	public String check(HttpServletRequest request, HttpServletResponse response, Model model) {

		SysUser sysUser = sysUserService.getSysUserByUsername(request.getParameter("username"));

		if (sysUser == null) {
			return ajax(model, "username_error");
		} else {
			if (sysUser.getPassword().equals(Hash.hmac(Hash.MD5, request.getParameter("password"), Define.KEY))) {
				sysUserService.setSysUserMenuAndResOper(sysUser);
				request.getSession().setAttribute(Define.SESSION_IN_USER, sysUser);
				if (request.getParameter("stay") != null) {
					HttpCookie cookie = new HttpCookie(request, response);
					cookie.setValue(Define.COOKIE_IN_USERID, RbacDes.encrypt(sysUser.getUsername()));
					RbacCache.put(sysUser.getUsername(), sysUser);
				}
				return ajax(model, SUCCESS);
			} else {
				return ajax(model, "password_error");
			}
		}
	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request, HttpServletResponse response, Model model) {
		SysUser sysUser = (SysUser) request.getSession().getAttribute(Define.SESSION_IN_USER);
		if (sysUser != null) {
			HttpCookie cookie = new HttpCookie(request, response);
			// cookie.clear();
			cookie.remove(Define.COOKIE_IN_USERID);
			RbacCache.remove(sysUser.getUsername());
			request.getSession().invalidate();
		}
		return ajax(model, SUCCESS);
	}
}
