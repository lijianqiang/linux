package cn.nubia.framework.crypto;

/**
 * 
 * Key sizes	128, 192 or 256 bits
 * Block sizes	128 bits
 * Structure	Feistel network
 * Rounds		16
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 31, 2015 5:20:12 PM by jxva
 */
public class Twofish {

}
