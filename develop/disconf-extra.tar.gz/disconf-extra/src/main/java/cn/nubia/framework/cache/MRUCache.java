package cn.nubia.framework.cache;

/**
 * Most Recently Used
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class MRUCache extends AbstractCache {
	
	public MRUCache(String name){
		this(name,DEFAULT_MAX_SIZE);
	}
	
	public MRUCache(String name,int maxSize) {
		this.name=name;
		this.maxSize = maxSize;
		map = new MRUMap<Object,Element>(maxSize);
	}
}
