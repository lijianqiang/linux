package cn.nubia.admin.common;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;

import cn.nubia.framework.core.ActionContext;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.util.Define;
import cn.nubia.rbac.util.RBACProperty;

import com.google.gson.Gson;

/**
 * 在service层和update语句做拦截
 * 注意：必须保证切入方法必须不能影响原来的执行步骤
 * @author gsd
 *
 */
public class AdminLogAspect {
	@Resource
	protected JdbcTemplate template;
	private final static Log logger = LogFactory.getLog(AdminLogAspect.class);
	private final static Gson GSON = new Gson();
	
	public Object logAdd(ProceedingJoinPoint joinpoint) throws Throwable {
		logger.debug("[admin log] add action start...@" + joinpoint.getSignature().getName());
		Object obj = joinpoint.proceed();
		try {
			logAction(joinpoint, StringUtils.EMPTY,StringUtils.EMPTY);
		} catch(RuntimeException e) {
			logger.error("[admin log] save action log error" , e);
		}
		return obj;	
	}
	
	public Object logDelete(ProceedingJoinPoint joinpoint) throws Throwable {
		logger.debug("[admin log] delete action start...@" + joinpoint.getSignature().getName());
		Object obj = joinpoint.proceed();
		try {
			logAction(joinpoint,StringUtils.EMPTY,StringUtils.EMPTY);
		} catch(RuntimeException e) {
			logger.error("[admin log] save action log error" , e);
		}
		return obj;
	}
	
	/**
	 * 功能：记录更新操作
	 * 注意：更新操作与add和delete不同，他是在spring jdbctemplate进行拦截，
	 * 将update的语句先转成select语句保存update执行之前的数据
	 * @param joinpoint
	 * @return
	 * @throws Throwable
	 * 2015年10月16日 下午4:20:53
	 * gsd
	 */
	public Object logUpdate(ProceedingJoinPoint joinpoint) throws Throwable {
		logger.debug("[admin log] update action start...@" + joinpoint.getSignature().getName());
		String orginData = StringUtils.EMPTY;
		String currentData = StringUtils.EMPTY;
		try {
			orginData = getOrginData(joinpoint);
		}catch(RuntimeException e) {
			logger.error("[admin log] save action log error" , e);
		}
		
		Object obj = joinpoint.proceed();
		try {
			if(StringUtils.isBlank(orginData)) {
				return obj;
			}
			currentData = getOrginData(joinpoint);
			logAction(joinpoint,orginData, currentData);
		}catch(RuntimeException e) {
			logger.error("[admin log] save action log error" , e);
		}
		return obj;
	}
	
	public void afterThrowing(RuntimeException e) {
		final String exceptionMessage = ExceptionUtils.getFullStackTrace(e);
		//发送邮件通知出错
		logger.debug("异常信息：" + exceptionMessage);
		throw e;
	}

	
	private void logAction(ProceedingJoinPoint joinpoint,String orginData, String currentData) {
		HttpServletRequest request = ActionContext.getRequest();
		if(request == null || ActionContext.getSession() == null) return; 
		SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
		this.template.update(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                String sql = "insert into tbl_admin_log(username,ip,url,params,res,action_type,orgin_data,current_data) "
                		+ " values(?,?,?,?,?,?,?,?)";
                PreparedStatement pstm = con.prepareStatement(sql, Statement.NO_GENERATED_KEYS);
                pstm.setString(1, sysUser!=null?sysUser.getUsername():StringUtils.EMPTY);
                pstm.setString(2, request.getRemoteAddr());
                String uri = request.getRequestURI();
                pstm.setString(3, uri);
                if(!uri.contains("Password")) {
                	pstm.setString(4, GSON.toJson(getParams(request)));
                }
                else {
                	pstm.setString(4, StringUtils.EMPTY);
                }
                if(uri.split("/").length > 1) {
                	pstm.setString(5, uri.split("/")[1]);
                }
                else {
                	pstm.setString(5, StringUtils.EMPTY);
                }
                pstm.setString(6, RBACProperty.getProperty(uri));
                pstm.setString(7, orginData);
                pstm.setString(8, currentData);
                return pstm;
            }
        });
	}
	
	private String getOrginData(ProceedingJoinPoint joinpoint) throws Throwable {
		Object[] args = joinpoint.getArgs();
		List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
		
		List<String> querySqls = tranQuerySql(args);
		if(querySqls != null && !querySqls.isEmpty()) {
			for(String sql : querySqls) {
				List<Map<String, Object>> tmp = this.template.queryForList(sql);
				if(tmp != null && tmp.size() > 0) {
					result.addAll(tmp);
				}
			}
			return GSON.toJson(result);
		}
		else {
			return StringUtils.EMPTY;
		}
	}
	
	private List<String> tranQuerySql(Object[] args) {
		List<String> queryList = new ArrayList<String>();
		if(args == null) return queryList;
		String querySql = StringUtils.EMPTY;
		
		for(Object obj : args) {
			//对update字眼进行修改
			if(obj instanceof String && obj != null) {
				if(!((String) obj).startsWith("update") || ((String) obj).trim().contains("is_del=1")) {
					return queryList;
				}
				querySql = replaceUpdateToQuery(queryList, querySql, obj);
			}
			//对参数进行封装
			if(obj instanceof Object[]) {
				packageSql(queryList, querySql, obj);
			}
			else if(obj instanceof List<?>) {
				for(Object[] param : (List<Object[]>) obj) {
					 packageSql(queryList, querySql, param);
				}
			}
		}
		return queryList;
	}

	private String replaceUpdateToQuery(List<String> queryList,
			String querySql, Object obj) {
		if(((String) obj).startsWith("update")) {
			querySql = ((String) obj).replaceFirst("update", "select * from");
		}
		return querySql;
	}

	private String packageSql(List<String> queryList, String querySql,
			Object obj) {
		for(Object param : (Object[])obj) {
			if(param instanceof String) {
				querySql = querySql.replaceFirst("\\?", "'"+String.valueOf(param)+"'");
			}else {
				querySql = querySql.replaceFirst("\\?", String.valueOf(param));
			}
		}
		
		if(querySql.indexOf("where") < 0) {
			querySql = querySql.substring(0, querySql.indexOf("set"));
		}
		else {
			querySql = querySql.substring(0, querySql.indexOf("set")) + querySql.substring(querySql.indexOf("where"));
		}
		queryList.add(querySql);
		return querySql;
	}

	private Map<String, String> getParams(HttpServletRequest request) {
		Enumeration paramNames = request.getParameterNames(); // 得到所有html传来的参数名字
		Map<String, String> paramHashMap = new HashMap<>();
		while (paramNames.hasMoreElements()) {
			String paramName = (String) paramNames.nextElement(); // 参数名
			String[] paramValues = request.getParameterValues(paramName); // 参数值
			paramHashMap.put(paramName, StringUtils.join(paramValues, ","));
		}
		return paramHashMap;
	}
	
}
