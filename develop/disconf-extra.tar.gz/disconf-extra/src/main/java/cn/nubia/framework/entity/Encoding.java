package cn.nubia.framework.entity;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2008-12-15 11:50:17 by jxva
 */
public class Encoding {
	
	private static List<Encoding> known = new ArrayList<Encoding>();
	
	public static final Encoding NONE = new Encoding("none", Integer.MIN_VALUE);

	public static final Encoding UTF_8 = new Encoding("UTF-8", 0);

	public static final Encoding GB2312 = new Encoding("GB2312", 1);

	public static final Encoding GBK = new Encoding("GBK", 2);

	public static final Encoding BIG5 = new Encoding("Big5", 3);

	public static final Encoding ISO_8859_1 = new Encoding("ISO-8859-1", 4);

	public static final Encoding UNICODE = new Encoding("Unicode", 5);

	public static final Encoding ASCII = new Encoding("ASCII", 6);

	private final String name;
	private final int value;

	protected Encoding(String name, int value) {
		this.name = name;
		this.value = value;
		known.add(this);
	}

	public static Encoding parse(String name) {
		try {
			for (int i = 0; i < known.size(); i++) {
				Encoding l = known.get(i);
				if (name.equalsIgnoreCase(l.name.trim())) {
					return l;
				}
			}
		} catch (Exception e) {
		}
		return Encoding.NONE;
	}

	public String name() {
		return name;
	}
	

	public final int value() {
		return value;
	}
	
	@Override
	public final String toString() {
		return name;
	}

	@Override
	public boolean equals(Object ox) {
		try {
			Encoding lx = (Encoding) ox;
			return (lx.value == this.value);
		} catch (Exception ex) {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return this.value;
	}
	
	
}
