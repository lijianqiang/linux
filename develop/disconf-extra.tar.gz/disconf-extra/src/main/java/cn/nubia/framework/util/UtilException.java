package cn.nubia.framework.util;

import cn.nubia.framework.exception.NestableRuntimeException;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class UtilException extends NestableRuntimeException {

	private static final long serialVersionUID = -5356341184035030569L;

	public UtilException() {
		super();
	}
	
	public UtilException(Throwable root) {
		super(root);
	}

	public UtilException(String string, Throwable root) {
		super(string, root);
	}

	public UtilException(String s) {
		super(s);
	}
}
