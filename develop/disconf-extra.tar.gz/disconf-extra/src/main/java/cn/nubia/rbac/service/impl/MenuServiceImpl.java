package cn.nubia.rbac.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.nubia.admin.common.ResultFailException;
import cn.nubia.rbac.model.Menu;
import cn.nubia.rbac.service.MenuService;

@Service("menuService")
public class MenuServiceImpl implements MenuService {
	@Resource
	protected JdbcTemplate template;
	private static final Log log = LogFactory.getLog(MenuServiceImpl.class);
	private static final Integer NOT_EXISTED_ID = -1;

	@Override
	public void save(Menu menu) {
		if (menu == null) {
			log.error("[rbac menu] save menu method, the param menu is null");
			throw new NullArgumentException(
					"save menu method, the param menu is null");
		}
		
		checkExistTitle(menu);
		checkExistMainHref(menu);
		
		String sql = "insert into tbl_menu(title,main_href,left_href) values(?,?,?)";
		this.template.update(
				sql,
				new Object[] { menu.getTitle(), menu.getMainHref(),
						menu.getLeftHref() });
	}

	private void checkExistMainHref(Menu menu) {
		if(this.existedMainHrefWithOther(menu.getMainHref(), menu.getId())) {
			log.error("[rbac menu] save menu method, the mainHref or is existed");
			throw new ResultFailException("菜单主链接已经存在，操作失败");
		}
	}

	private void checkExistTitle(Menu menu) {
		if(this.existedTitleWithOther(menu.getTitle(), menu.getId())) {
			log.error("[rbac menu] save menu method, the title is existed");
			throw new ResultFailException("菜单名称已经存在，操作失败");
		}
	}

	@Override
	public void delete(Integer id) {
		if (id == null) {
			log.error("[rbac menu] delete menu method, the param id is null");
			throw new NullArgumentException(
					"delete menu method, the param id is null");
		}
		String sql = "delete from tbl_menu where id=?";
		this.template.update(sql, id);
	}

	@Override
	public void update(Menu menu) {
		if (menu == null) {
			log.error("[rbac menu] update menu method, the param menu is null");
			throw new NullArgumentException(
					"update menu method, the param menu is null");
		}
		if (menu.getId() == null) {
			log.error("[rbac menu] update menu method, the param id is null");
			throw new NullArgumentException(
					"update menu method, the param id is null");
		}
		checkExistTitle(menu);
		checkExistMainHref(menu);
		
		String sql = "update tbl_menu set title=?, main_href=?, left_href=? where id=?";
		this.template.update(
				sql,
				new Object[] { menu.getTitle(), menu.getMainHref(),
						menu.getLeftHref(), menu.getId() });
	}

	@Override
	public List<Menu> fetchAll() {
		String sql = "select * from tbl_menu order by main_href";
		return this.template.query(sql, new MenuRowMapper());
	}

	@Override
	public Menu getById(Integer id) {
		if (id == null) {
			log.error("[rbac menu] getById method, the param id is null");
			return null;
		}

		String sql = "select id,left_href,main_href,title from tbl_menu where id=? ";
		try {
			Menu obj = this.template.queryForObject(sql, new Object[] { id },
					new MenuRowMapper());
			return obj;
		} catch(EmptyResultDataAccessException e) {
			return null;
		}
	}

	@Override
	public List<Integer> fetchMenuIdsByRoleId(Integer id) {
		if (id == null) {
			log.error("[rbac menu] fetchMenuIdsByRoleId method, the param id is null");
			return null;
		}

		String sql = "select menu_id from tbl_role_menu where role_id=?";
		List<Integer> result = this.template.queryForList(sql, Integer.class,
				new Object[] { id });
		if (result == null) {
			result = new ArrayList<Integer>();
		}
		return result;
	}

	@Override
	public Map<String, Menu> fetchMenusByRoleIds(List<Integer> ids) {
		Map<String, Menu> resultMap = new HashMap<String, Menu>();
		if (ids == null || ids.isEmpty()) {
			return resultMap;
		}

		String sql = "select menu_id from tbl_role_menu where role_id in ("
				+ StringUtils.join(ids.toArray(), ",") + ")";
		List<Integer> result = this.template.queryForList(sql, Integer.class);

		if (result == null || result.isEmpty()) {
			return resultMap;
		}
		String menuSql = "select id, left_href, main_href, title from tbl_menu where id in ("
				+ StringUtils.join(result.toArray(), ",") + ")";
		List<Menu> menuResult = this.template.query(menuSql,
				new MenuRowMapper());

		if (menuResult == null || menuResult.isEmpty()) {
			return resultMap;
		}
		
		for (Menu menu : menuResult) {
			resultMap.put(menu.getMainHref(), menu);
		}
		return resultMap;
	}

	/**
	 * 
	 *	
	 * @param title
	 * @param id
	 * @return
	 * @author gsd
	 */
	@Override
	public boolean existedTitleWithOther(String title, Integer id) {
		if(StringUtils.isBlank(title)) {
			log.error("[rabc menu] existedTitleWithOther, the param username is blank");
			return true;
		}
		
		String sql = "select id from tbl_menu where title=? and id <> ?";
		if(id == null) {
			id = NOT_EXISTED_ID;
		}
		List<Integer> result = this.template.queryForList(sql, Integer.class, new Object[]{title, id});
		if(result == null || result.isEmpty()) {
			return false;
		}
		
		return true;
	}

	/**
	 * 
	 *	
	 * @param mainHref
	 * @param id
	 * @return
	 * @author gsd
	 */
	@Override
	public boolean existedMainHrefWithOther(String mainHref, Integer id) {
		if(StringUtils.isBlank(mainHref)) {
			log.error("[rabc menu] existedMainHrefWithOther, the param username is blank");
			return true;
		}
		
		String sql = "select id from tbl_menu where main_href=? and id <> ?";
		if(id == null) {
			id = NOT_EXISTED_ID;
		}
		List<Integer> result = this.template.queryForList(sql, Integer.class, new Object[]{mainHref, id});
		if(result == null || result.isEmpty()) {
			return false;
		}
		
		return true;
	}


}

class MenuRowMapper implements RowMapper<Menu> {
	public Menu mapRow(ResultSet rs, int index) throws SQLException {
		Menu menu = new Menu();
		menu.setId(rs.getInt("id"));
		menu.setLeftHref(rs.getString("left_href"));
		menu.setMainHref(rs.getString("main_href"));
		menu.setTitle(rs.getString("title"));
		return menu;
	}
}
