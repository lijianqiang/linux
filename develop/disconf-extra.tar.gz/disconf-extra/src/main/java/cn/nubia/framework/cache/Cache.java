package cn.nubia.framework.cache;



/**
 * LRU(Least Recently Used) & LFU(Least Frequently Used)
 * LFU-EA(LFU with Exponential Aging)
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public interface Cache {

	public void clear();

	public boolean containsKey(Object key);
	
	public void dispose();
	
	public Object getValue(Object key);
	
	public Object getQuietValue(Object key);
	
	public Element get(Object key);
	
	/**
	 * without updating hits
	 */
	public Element getQuiet(final Object key);
		
	public Object[] getKeys();
	
	public String getName();

	public int size();

	public void put(Object key,Object value);
	
	public void put(Element element);

	public Element remove(Object key);	

	public boolean isEmpty();
}
