package cn.nubia.framework.crypto;

import cn.nubia.framework.crypto.provider.CryptoProvider;

/**
 * 
 * Key sizes	32–448 bits
 * Block sizes	64 bits
 * Structure	Feistel network
 * Rounds		16
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 31, 2015 3:44:23 PM by jxva
 */
public class Blowfish extends CryptoProvider {

	public Blowfish(int blockSize, PaddingMode padding) {
		super(blockSize,padding);
	}

	@Override
	public byte[] cbc_encrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_encrypt(CryptoMode.Blowfish,key,iv,data);
	}

	@Override
	public byte[] cbc_decrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_decrypt(CryptoMode.Blowfish,key,iv,data);
	}

}
