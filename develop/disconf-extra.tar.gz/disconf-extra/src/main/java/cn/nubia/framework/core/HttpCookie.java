package cn.nubia.framework.core;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class HttpCookie {
		
	private final HttpServletRequest request;
	private final HttpServletResponse response;

	//private String domain	="127.0.0.1";
	private int maxage		=Integer.MAX_VALUE;
	private String path		="/";
	
	public HttpCookie(HttpServletRequest request,HttpServletResponse response){
		this.request=request;
		this.response=response;
	}
	
	//public void setDomain(String domain) {
	//	this.domain = domain;
	//}


	public void setMaxage(int maxage) {
		this.maxage = maxage;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	private void setValue(String name,String value,int maxage){
	    Cookie cookie = new Cookie(name,value);
		//cookie.setDomain(domain);
		cookie.setMaxAge(maxage);
		cookie.setValue(value);
		cookie.setPath(path);
		response.addCookie(cookie);
	}
	

	public boolean hasExist(){
		return getCookies()!=null;
	}
	

	public boolean hasExist(String name){
		return getValue(name)!=null;
	}
	

	public String getValue(String name){
		Cookie[] cookies = getCookies();
		if(cookies!=null){
			for (int i = 0; i <cookies.length; i++) {       
				if(cookies[i].getName().equals(name)){
					return cookies[i].getValue();
		        }
		    }
		}
		return null;
	}
	


	public void setValue(String name,String value){
		setValue(name,value,maxage);
	}
	
	public void remove(String name){
		setValue(name,null,0);
	}
	

	public void clear(){
		Cookie[] cookies = getCookies();
		if(cookies!=null){
			for (int i = 0; i <cookies.length; i++) {    
				remove(cookies[i].getName());
		    }
		}
	}
	
	public Cookie[] getCookies(){
		return request.getCookies();
	}

}
