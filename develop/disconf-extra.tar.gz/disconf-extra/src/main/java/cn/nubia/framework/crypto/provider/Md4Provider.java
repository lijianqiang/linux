package cn.nubia.framework.crypto.provider;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import cn.nubia.framework.crypto.CryptoException;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 27, 2015 8:34:35 PM by jxva
 */
public class Md4Provider {
	
	public static byte[] encrypt(byte[] data) {
		MessageDigest messageDigest  = MD4.getInstance();
		messageDigest.update(data);
		return messageDigest.digest();
	}

	public static byte[] hmac(byte[] data, byte[] key) {
		try {
			SecretKeySpec signingKey = new SecretKeySpec(key, "HmacMD4");
			Mac mac = Mac.getInstance("HmacMD4");
			mac.init(signingKey);
			return mac.doFinal(data);
		} catch (InvalidKeyException | NoSuchAlgorithmException e) {
			throw new CryptoException(e);
		}
	}

	public static byte[] checksum(File file) {
		try (FileInputStream fis = new FileInputStream(file)) {
			MessageDigest messageDigest = MD4.getInstance();
			byte[] dataBytes = new byte[1024];
			int nread = 0;
			while ((nread = fis.read(dataBytes)) != -1) {
				messageDigest.update(dataBytes, 0, nread);
			}
			return messageDigest.digest();
		} catch (IOException e) {
			throw new CryptoException(e);
		}
	}

}
