package cn.nubia.framework.entity;

/**
 * Universally Unique Identifier
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2008-11-27 09:27:16 by Jxva
 */
public abstract class Uuid {
		
	public static String next(){
		return java.util.UUID.randomUUID().toString();
	}
	
}
