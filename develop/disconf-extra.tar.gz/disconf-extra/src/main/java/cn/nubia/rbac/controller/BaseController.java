package cn.nubia.rbac.controller;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;

import cn.nubia.admin.common.Result;
import cn.nubia.admin.common.ResultFailException;
import cn.nubia.framework.core.PageBean;
import cn.nubia.framework.core.Pager;
import cn.nubia.framework.util.StringUtil;

public abstract class BaseController {
	protected final Log log =  LogFactory.getLog(BaseController.class);
	protected static final int PAGE_NO = 20;
	protected HttpServletResponse response;
	protected HttpServletRequest request;
	
	protected static final String LIST="list";
	protected static final String ADD="add";
	protected static final String EDIT="edit";
	protected static final String VIEW="view";
	protected static final String SUCCESS="success";
	protected static final String ERROR="error";
	protected static final String EXPORT="export";
	

	@ExceptionHandler(Exception.class)
	public String handleExcetion(HttpServletRequest request, Exception ex){
		String json = null;
		if(ex instanceof ResultFailException){
			ResultFailException resultFailException = (ResultFailException) ex;
			json = Result.returnFailResult(resultFailException.getMessage());
		}else{
			log.error("",ex);
			json = Result.returnFailResult("操作异常");
		}
		request.setAttribute("ajaxInfo", json);
		return "ajax";
	}

	/**
	 * @param model m 
	 * @param info info
	 * @return string
	 */
	protected String ajax(Model model, String info) {
		model.addAttribute("ajaxInfo", info);
		return "ajax";
	}

	/**
	 * @param request r
	 */
	protected void viewParameters(HttpServletRequest request) {				
			StringBuffer sbuf = new StringBuffer();
			sbuf.append("\n==================开始：输出request中的参数========================\n");
			sbuf.append("       Request URI= " + request.getRequestURI());
			sbuf.append("\n");
			Enumeration paramNames = request.getParameterNames(); // 得到所有html传来的参数名字
			while (paramNames.hasMoreElements()) {
				String paramName = (String) paramNames.nextElement(); // 参数名
				String[] paramValues = request.getParameterValues(paramName); // 参数值
				for (int i = 0; i < paramValues.length; i++) {
					if (i == 0) {
						sbuf.append("       @" + paramName + "= ");
					}
					sbuf.append(paramValues[i] + ",");
				}
				if (sbuf.length() > 0) {
					sbuf.deleteCharAt(sbuf.length() - 1);
				}
				sbuf.append("\n");
			}
			sbuf.append("==================结束：输出request中的参数========================\n");
			System.out.println(sbuf.toString());
			log.debug(sbuf.toString());
		}
	
	
	/**
	 * 解决前台date数据到后面格式转换问题
	 * @param binder b
	 */
	@InitBinder 
	public void initBinder(WebDataBinder binder) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
		dateFormat.setLenient(true); 
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true)); 
	} 
	
	/**
	 * @param name n
	 * @param request r
	 * @return string
	 */
	protected String getParam(String name,HttpServletRequest request){
		return request.getParameter(name);
	}
	
	protected String getParam(String name,HttpServletRequest request,String defaultValue){
		String val=getParam(name,request);
		if(StringUtil.isEmpty(val)){
			return defaultValue;
		}else {
			return val;	
		}
	}
	
	/**
	 * @param request r
	 * @param name n
	 * @return int
	 */
	protected Integer getIntParam(HttpServletRequest request,String name){	
		try{
			return Integer.valueOf(request.getParameter(name));
		}
		catch(NumberFormatException e){
			return null;
		}
	}
		
	/**
	 * @param request r
	 * @param name n 
	 * @param defaultValue d
	 * @return int
	 */
	protected int getIntParam(HttpServletRequest request,String name,int defaultValue){
		String val=getParam(name,request);
		if(StringUtil.isEmpty(val)){
			return defaultValue;
		}else {
			return Integer.valueOf(val);	
		}
	}	
	/**
	 * 往结果中添加列表，默认key为“list”
	 * 
	 * @param actionUrl
	 *            点击下一页时触发的action的路径，如/xx/bb.do
	 * @param list
	 * @param pageBean
	 * @param model
	 */
	protected void addList(String actionUrl, Object list, PageBean pageBean,
			Model model) {
		addList(actionUrl, "list", list, pageBean, model);
	}
	
	/**
	 * 往结果中添加列表，列表的key可指定
	 * 
	 * @param actionUrl
	 *            点击下一页时触发的action的路径，如/xx/bb.do
	 * @param listKey
	 *            列表的key
	 * @param list
	 * @param pageBean
	 * @param model
	 */
	protected void addList(String actionUrl, String listKey, Object list,
			PageBean pageBean, Model model) {
		model.addAttribute(listKey, list);
		if (actionUrl.indexOf("?") < 0) {
			pageBean.setPageNum(actionUrl + "?pageNum=");
		} else {
			pageBean.setPageNum(actionUrl + "&pageNum=");
		}
		model.addAttribute("pageBean", pageBean);
	}
	
	public static PageBean MakePageBean(HttpServletRequest request, int defaultIndex, int defaultSize) {
		String pageindex = request.getParameter("pageindex");
		String pagesize = request.getParameter("pagesize");
		if (StringUtil.isEmpty(pageindex) || StringUtil.isEmpty(pagesize)) {
			return new Pager(defaultIndex, defaultSize);
		}
		return new Pager(Integer.parseInt(pageindex), Integer.parseInt(pagesize));
	}
	protected PageBean createPageBean(HttpServletRequest request, int pageSize) {
		// 默认从第一页开始
		int pageNum = 1;
		try {
			pageNum = Integer.parseInt(request.getParameter("pageNum"));
		} catch (NumberFormatException e) {
			log.warn("wrong pageNum, use default : " + e.toString());
		}
		PageBean pageBean = new Pager(pageNum, pageSize);
		return pageBean;
	}
}

