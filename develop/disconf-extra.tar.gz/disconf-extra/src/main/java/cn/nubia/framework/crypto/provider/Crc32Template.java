package cn.nubia.framework.crypto.provider;

/**
 * 
 * http://www.lammertbies.nl/comm/info/crc-calculation.html
 * 
   the "crc32" is the ITU I.363.5 algorithm (a.k.a. AAL5 CRC - popularised by BZIP2 but also used in ATM transmissions 
 *  the algorithm is the same as that in POSIX 1003.2-1992 in Cksum but that stuffs the size into the CRC at the end for extra measure). 
 *  
 *  The crc32b is the 32-bit Frame Check Sequence of ITU V.42 (used in Ethernet and popularised by PKZip). 
 *  The output from this CRC is popularised in Intel little endian format and would produce cbf43926 on the same file."
 *  
 *  crc32 is the one used on ethernet, while crc32b is the one used on zip, png... They differ on the table used.
 *  
   生成多项式的值（多项式因子）
   注意：CRC16是数据流的高位先计算，多项式因子不变
    而CRC32和CRC8都是数据流的低位先计算，所以多项式因子的高/低位对调
    比如CRC32由$04C11DB7变为$EDB88320，CRC8由$31变为$8C
  
  GenPoly32: DWord; // CRC-32 = X32+X26+X23+X22+X16+X12+X11+X10+X8+X7+X5+X4+X2+X1+1
                    // 00000100 11000001 00011101 10110111($04C11DB7) 低位先行($EDB88320)
                     
  GenPoly16: Word;  // CRC-CCITT16 = X16+X12+X5+1, 00010000 00100001($1021) 高位先行
                    // CRC-16      = X16+X15+X2+1, 10000000 00000101($8005) 高位先行
                     
  GenPoly8:  Byte;  // CRC-8 = X8+X5+X4+1, 00110001($31) 低位先行($8C)
  GenPoly4:  Byte;  // CRC-4 = X4+X1+1, 0011($03)
 * 
   This reverse polynomial (0xEDB88320) DOES generate the same CRC values as ZMODEM and PKZIP
   This unreverse polynomial (0x04C11DB7) is used at: AUTODIN II, Ethernet, & FDDI 
 
   Standard CRC-32 generator polynomial:
       Name               : CRC-32 Standard
       Standards          : ISO 3309, ITU-T V.42, ANSI X3.66, FIPS PUB 71
       References         : ZIP, RAR, Ethernet, AUTODIN II, FDDI
       Initializing value : FFFFFFFF
       Finalizing value   : FFFFFFFF
       Polynomial value   : 04C11DB7 (Mirror value = EDB88320)
       Polynom            : x^32 + x^26 + x^23 + x^22 + x^16 + x^12 + x^11 +
                            x^10 + x^8 + x^7 + x^5 + x^4 + x^2 + x + 1
                            
  http://introcs.cs.princeton.edu/java/51data/CRC32.java
 *  Compilation:  javac CRC32.java
 *  Execution:    java CRC32 s
 *  
 *  Reads in a string s as a command-line argument, and prints out
 *  its 32 bit Cyclic Redundancy Check (CRC32 or Ethernet / AAL5 or ITU-TSS).
 *
 *  Uses direct table lookup, calculation, and Java library.
 *
 *  % java CRC32 123456789
 *  CRC32 (via table lookup)       = cbf43926
 *  CRC32 (via direct calculation) = cbf43926
 *  CRC32 (via Java's library)     = cbf43926
 *
 *
 *
 *  Uses irreducible polynomial:
 *     1    + x    + x^2  + x^4  + x^5  + x^7  + x^8  +
 *     x^10 + x^11 + x^12 + x^16 + x^22 + x^23 + x^26 
 *
 *  0000 0100 1100 0001 0001 1101 1011 0111                 
 *   0    4    C    1    1    D    B    7
 *
 *  The reverse of this polynomial is
 *
 *   0    2    3    8    8    B    D    E
 *   
 *   
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 28, 2015 5:52:46 PM by jxva
 */
public abstract class Crc32Template {
		
	public abstract void reset();
	
	public abstract void update(byte b);
	
	public abstract int value();
	
	public final void update(byte[] data) {
		for (byte b : data) {
			update(b);
		}
	}
	
	public final String checksum(byte[] data) {
		reset();
		update(data);
		// String v = Integer.toHexString(value);
		return String.format("%08x", value());
	}
	
}
