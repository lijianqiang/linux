package cn.nubia.framework.redis;

import java.util.List;
import java.util.Map;
import java.util.Set;

import redis.clients.jedis.JedisCommands;
import redis.clients.jedis.exceptions.JedisException;

/**
 * @Program Name : com.ztemt.framework.redis.IRedisTemplate.java
 * @Written by : linjin
 * @Creation Date : 2014年12月22日 下午5:12:54
 * @version : v1.00
 * @Description : redis操作模板接口
 **/
public interface RedisTemplate {

	/**
	 * 删除多个键
	 * 
	 * @param keys
	 * @return
	 **/
	public Boolean delete(final String... keys);

	/**
	 * 删除单个键
	 * 
	 * @param keys
	 * @return
	 **/
	public Boolean del(final String key);

	/**
	 * 清除所有的DB数据
	 **/
	public void flushDB();

	/**
	 * 获取某个key的value,如果key不存在, 返回null
	 * 
	 * @param key
	 * @return
	 **/
	public String get(final String key);

	/**
	 * 获取某个key的value,返回格式为Long，如果key不存在, 返回null
	 * 
	 * @param key
	 * @return
	 **/
	public Long getAsLong(final String key);

	/**
	 * 获取某个key的value,返回格式为Int，如果key不存在, 返回null
	 * 
	 * @param key
	 * @return
	 **/
	public Integer getAsInt(final String key);

	/**
	 * 设值到redis
	 * 
	 * @param key
	 * @param value
	 **/
	public void set(final String key, final String value);

	/**
	 * 设值到redis,多少秒后失效
	 * 
	 * @param key
	 * @param value
	 * @param seconds
	 **/
	public void setex(final String key, final String value, final int seconds);

	/**
	 * 如果key不存在则进行设置，返回true，否则返回false.
	 * 
	 * @param key
	 * @param value
	 * @return
	 **/
	public Boolean setnx(final String key, final String value);

	/**
	 * 如果key不存在则进行设置多少秒失效，返回true，否则返回false
	 * 
	 * @param key
	 * @param value
	 * @param seconds
	 * @return
	 **/
	public Boolean setnxex(final String key, final String value, final int seconds);

	/**
	 * 递增并返回增后的值
	 * 
	 * @param key
	 * @return
	 **/
	public Long incr(final String key);

	/**
	 * 递减，并返回减后的值
	 * 
	 * @param key
	 * @return
	 **/
	public Long decr(final String key);

	/**
	 * 获取Hash结构数据 ，某个key的某个field值
	 * 
	 * @param key
	 * @param field
	 * @return
	 **/
	public String hget(final String key, final String field);

	/**
	 * 设置Hash结构数据 ，某个key的某个field值
	 * 
	 * @param key
	 * @param field
	 * @param value
	 **/
	public void hset(final String key, final String field, final String value);

	/**
	 * 获取Hash结构数据 ，某个key的多个field值
	 * 
	 * @param key
	 * @param fields
	 * @return
	 **/
	public List<String> hmget(final String key, final String[] fields);

	/**
	 * 设置Hash结构数据 ，某个key的多个field值
	 * 
	 * @param key
	 * @param map
	 **/
	public void hmset(final String key, final Map<String, String> map);

	/**
	 * 删除 Hash结构数据 ，某个key的多个field值
	 * 
	 * @param key
	 * @param fieldsName
	 * @return
	 **/
	public Long hdel(final String key, final String... fieldsName);

	/**
	 * 返回某个key的Hash结构数据的所有field的name集合
	 * 
	 * @param key
	 * @return
	 **/
	public Set<String> hkeys(final String key);
	
	/**
     * 返回哈希表 key 中，所有的域和值。
     * 
     * @param key
     * @return
     **/
    public Map<String, String> hgetall(final String key);

	/**
	 * 往list左边放入多个值
	 * 
	 * @param key
	 * @param values
	 **/
	public void lpush(final String key, final String... values);

	/**
	 * 从list右边弹出某个value
	 * 
	 * @param key
	 * @return
	 **/
	public String rpop(final String key);

	/**
	 * 返回List长度, key不存在时返回0，key类型不是list时抛出异常.
	 * 
	 * @param key
	 * @return
	 **/
	public Long llen(final String key);

	/**
	 * 删除List中的第一个等于value的元素，value不存在或key不存在时返回false.
	 * 
	 * @param key
	 * @param value
	 * @return
	 **/
	public Boolean lremOne(final String key, final String value);

	/**
	 * 删除List中的所有等于value的元素，value不存在或key不存在时返回false.
	 * 
	 * @param key
	 * @param value
	 * @return
	 **/
	public Boolean lremAll(final String key, final String value);

	/**
	 * 返回List指定索引段的value
	 * 
	 * @param key
	 * @param start
	 * @param end
	 * @return
	 */
	public List<String> lrange(final String key, final long start, final long end);

	/**
	 * 加入set, 如果member在Set里已存在, 返回false, 否则返回true.
	 * 
	 * @param key
	 * @param members
	 * @return
	 **/
	public Boolean sadd(final String key, final String... members);

	/**
	 * 获取set
	 * 
	 * @param key
	 * @return
	 **/
	public Set<String> smembers(final String key);

	/**
	 * 删除名称为key的set中的元素member，成功删除返回true，key或member不存在返回false。
	 * 
	 * @param key
	 * @param members
	 * @return
	 **/
	public Boolean srem(final String key, final String... members);

	/**
	 * 加入Sorted set, 如果member在Set里已存在, 只更新score并返回false,否则返回true.
	 * 
	 * @param key
	 * @param member
	 * @param score
	 * @return
	 **/
	public Boolean zadd(final String key, final String member, final double score);

	/**
	 * 删除sorted set中的元素，成功删除返回true，key或member不存在返回false。
	 * 
	 * @param key
	 * @param member
	 * @return
	 **/
	public Boolean zrem(final String key, final String member);

	/**
	 * 返回key的set中的某个值得socre,当key不存在时返回null.
	 * 
	 * @param key
	 * @param member
	 * @return
	 **/
	public Double zscore(final String key, final String member);

	/**
	 * 返回sorted set长度, key不存在时返回0.
	 * 
	 * @param key
	 * @return
	 **/
	public Long zcard(final String key);
	
	/**
	 * 设置超时
	 * @param key
	 * @param seconds
	 * @return
	 */
	public Long expire(final String key,final Integer seconds );
	
	/**
	 * 判断key是否存在
	 * @param key
	 * @return
	 */
	public Boolean exists(String key); 
	
	public String getSet(String key,String value);
	
	public interface JedisCommand<T> {
		T action(final JedisCommands jedis);
	}
	
	public <T> T execute(JedisCommand<T> jedisCommand) throws JedisException ;

}