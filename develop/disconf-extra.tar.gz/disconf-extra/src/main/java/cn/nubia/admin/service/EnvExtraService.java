package cn.nubia.admin.service;

import java.util.List;

import com.baidu.disconf.web.service.env.bo.Env;

public interface EnvExtraService {
	Env getById(Long id);
	
	void add(Env env);
	
	void update(Env env);
	
	void delete(Long id);

	List<Env> getAll();

}
