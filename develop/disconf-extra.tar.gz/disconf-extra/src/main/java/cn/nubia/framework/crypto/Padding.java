package cn.nubia.framework.crypto;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Dec 29, 2014 5:07:16 PM by jxva
 */
public class Padding {

	public static byte[] pkcs5Padding(int blockSize, byte[] data) {
		int len = data.length;
		blockSize = blockSize / 8;
		int paddingLen = blockSize - (len % blockSize);
	
		byte[] bytes = new byte[len + paddingLen];

		for (int i = 0; i < len; i++) {
			bytes[i] = data[i];
		}

		byte paddingOctet = (byte) (paddingLen & 0xff);
		for (int i = 0; i < paddingLen; i++) {
			bytes[i + len] = paddingOctet;
		}

		return bytes;
	}

	public static byte[] zeroPadding(int blockSize, byte[] data) {
		byte[] content = data;
		int plaintextLength = content.length;
		if (plaintextLength % blockSize != 0) {
			plaintextLength = plaintextLength + (blockSize - (plaintextLength % blockSize));
		}

		byte[] plaintext = new byte[plaintextLength];
		System.arraycopy(content, 0, plaintext, 0, content.length);
		return content;
	}

	public static byte[] spacePadding(int blockSize, byte[] data) {
		String d = new String(data);
		byte[] content = data;
		int i = content.length / 2;
		while (content.length % blockSize != 0) {
			content = padRight(d, ++i).getBytes();
		}
		return content;
	}

	public static String padRight(String s, int n) {
		return String.format("%1$-" + n + "s", s);
	}

	public static String padLeft(String s, int n) {
		return String.format("%1$#" + n + "s", s);
	}
}
