package cn.nubia.framework.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public abstract class FieldUtil {

	private static final Map<String, List<Field>> tblFields = new HashMap<String, List<Field>>();
	private static final Map<String, List<Field>> tblFieldsWithParent = new HashMap<String, List<Field>>();

	/**
	 * 从缓存中获取对象的所有字段,包括所有父类
	 * 
	 * @param cls
	 * @return
	 */
	public static List<Field> getFieldsWithParent(Class<?> cls) {
		List<Field> list = tblFieldsWithParent.get(cls.getName());
		if (list == null) {
			list = getFieldsWithParentForCache(cls);
			tblFieldsWithParent.put(cls.getName(), list);
		}
		return list;
	}

	/**
	 * 从缓存中获取对象的所有字段,不包括父类
	 * 
	 * @param cls
	 * @return
	 */
	public static List<Field> getFields(Class<?> cls) {
		List<Field> list = tblFields.get(cls.getName());
		if (list == null) {
			list = getFieldsForCache(cls);
			tblFields.put(cls.getName(), list);
		}
		return list;
	}

	/**
	 * 获取class的所有字段,包括所有父类
	 * 
	 * @param cls
	 * @return
	 */
	private static List<Field> getFieldsWithParentForCache(Class<?> cls) {
		final List<Field> list = new ArrayList<Field>();
		do {
			addFieldToList(list, cls);
			cls = cls.getSuperclass();
		} while (cls != Object.class);
		return list;
	}

	/**
	 * 获取class的所有字段,不包括父类
	 * 
	 * @param cls
	 * @return
	 */
	private static List<Field> getFieldsForCache(Class<?> cls) {
		final List<Field> list = new ArrayList<Field>();
		addFieldToList(list, cls);
		return list;
	}

	private static void addFieldToList(List<Field> list, Class<?> cls) {
		final Field[] fields = cls.getDeclaredFields();
		for (Field field : fields) {
			if (field.getName().equals("serialVersionUID")) {
				continue;
			}
			list.add(field);

		}
	}
}
