package cn.nubia.framework.crypto.provider;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 28, 2015 8:21:44 PM by jxva
 */
public class Crc64Ecma {

}
