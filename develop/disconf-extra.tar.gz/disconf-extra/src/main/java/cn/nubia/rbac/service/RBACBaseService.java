package cn.nubia.rbac.service;

import java.util.List;

public interface RBACBaseService<T> {

	void save(T t);
	void delete(Integer id);
	void update(T t);
	T getById(Integer id);
	List<T> fetchAll();
}
