package cn.nubia.framework.crypto;

/**
 * 
 * 码字长度为64bit的CRC编码。常用的生成多项式有：
 * 
 * 	ISO 3309规定的
	x^64 + x^4 + x^3 + x + 1

	ECMA规定的
	x^64 + x^62 + x^57 + x^55 + x^54 + x^53 + x^52 + x^47 + x^46 + x^45 + x^40 + x^39 + x^38 + x^37 + x^35 + x^33 + x^32 + x^31 + x^29 + x^27 + x^24 + x^23 + x^22 + x^21 + x^19 + x^17 + x^13 + x^12 + x^10 + x^9 + x^7 + x^4 + x + 1

 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 28, 2015 7:08:03 PM by jxva
 */
public class Crc64 {

	private static final long INITIAL_VALUE = 0xFFFFFFFFFFFFFFFFL; 
	// ECMA polynomial
	private static final long POLY =(0xC96C5795L << 32) | 0xD7870F42L;
	
	// ISO polynomial
	// POLY = (0xD8 << 56);

	private long value;
	private static final long[] table = new long[256];
	

	static {
		for (int i = 0; i < 256; i++) {
			long part; 
			int bit;
			for (part = i, bit = 0; bit < 8; bit++) {
				if ((part & 1) == 1) {
					part = ((part >> 1) & ~(0x8 << 60)) ^ POLY;
				} else {
					part = (part >> 1) & ~(0x8 << 60);
				}
			}
			table[i] = part;
		}
	}
	public Crc64() {
		value = INITIAL_VALUE;
	}

	public void update(byte b) {
		 value = table [(((int) value) ^ b ) & 0xff] ^ ( ( value >> 8 ) & ~( 0xff << 56 ) );		
		//value = table[(((int) value) ^ b) & 0xff] ^ (value >> 8);  
	}

	public void update(byte[] data) {
		/*
		 String in = new String(data);
		 byte[] result = new byte[data.length * 2];// 一个字符占两个字节  
        int output = 0;  
        for (char ch : in.toCharArray()) {  
            result[output++] = (byte) (ch & 0xFF);// 取低8位  
            result[output++] = (byte) (ch >> 8);// 取高8位  
        }  */
		
		for (int i = 0; i < data.length; i++) {
			update(data[i]);
		}
	}

	public long value() {
		return value;
	}

	public String checksum(byte[] data) {
		reset();
		update(data);
		//return Long.toHexString(value);
		return String.format("%016x", value());
	}

	public void reset() {
		value = INITIAL_VALUE;
	}
}
