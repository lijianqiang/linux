package cn.nubia.rbac.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class RBACProperty {

	private static final Properties props = new Properties();

	static {
		try (InputStream fileName = RBACProperty.class.getClassLoader().getResourceAsStream("rbac.properties")){
			props.load(fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getProperty(String key) {
		return props.getProperty(key);
	}
}
