package cn.nubia.rbac.service;

import java.util.List;

import cn.nubia.rbac.model.SysUser;

/**
 * 系统用户业务逻辑
 */
public interface SysUserService extends RBACBaseService<SysUser>{

	public SysUser getSysUserByUsername(String username);
	
	public void updatePassword(Integer userId, String password);
	
	/**
	 * 功能：保存用户和用户角色
	 * 注意：一个用户可以有多种角色，用户和用户角色是同一个事务保存
	 * @param user
	 * @param roleIds 
	 * 2015年10月16日 上午9:48:39
	 * gsd
	 * @param envList 
	 */
	void saveRole(SysUser user, List<Integer> roleIds, List<Integer> envList);
	
	/**
	 * 功能：更新用户角色
	 * @param user
	 * @param newRoleIds
	 * 2015年10月16日 上午9:49:04
	 * gsd
	 * @param envList 
	 */
	void updateRole(SysUser user, List<Integer> newRoleIds, List<Integer> envList);

	List<Integer> fetchRoleIdsByUserId(Integer id);
	
	/**
	 * 功能：对用户进行资源权限分配
	 * 注意：包括菜单资源和操作资源
	 * @param user
	 * 2015年10月16日 上午9:52:56
	 * gsd
	 */
	void setSysUserMenuAndResOper(SysUser user);
	
	/**
	 * 功能：判断是否存在某角色的用户
	 * 注意：
	 * @param id 角色id
	 * @return true表示存在，false表示不存在
	 * 2015年10月16日 上午9:54:08
	 * gsd
	 */
	boolean existedByRoleId(Integer id);
	
	/**
	 * 功能：判断id的用户的名字是否与其他名字相同
	 * 注意：如果id为空跟所有人比较；如果id不为空，跟其他人比较
	 * @param username
	 * @param id 可为空
	 * @return
	 * 2015年10月16日 上午10:34:57
	 * gsd
	 */
	boolean existedUsernameWithOther(String username, Integer id);
}
