package cn.nubia.admin.common;

import com.google.gson.Gson;

public class Result<E> {
	public final static int SUCCESS = 0;
	public final static int FAIL = 999;
	private final static Gson GSON = new Gson();
	
	public static String returnSuccResult(){
		return GSON.toJson(new Result<String>(SUCCESS, "", ""));
	}
	public static String returnFailResult(String message){
		return GSON.toJson(new Result<String>(FAIL, message, ""));
	}
	public static <T> String returnDataResult(T data){
		return GSON.toJson(new Result<T>(SUCCESS, "", data));
	}

	private int code;
	private String message;
	private E data;
	public Result(){}
	public Result(int code,String message, E data){
		this.code = code;
		this.message = message;
		this.data = data;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public E getData() {
		return data;
	}
	public void setData(E data) {
		this.data = data;
	}
}
