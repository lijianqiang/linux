package cn.nubia.framework.crypto;

import cn.nubia.framework.crypto.provider.CryptoProvider;

/**
 * ARCFOUR/ECB/NoPadding
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 28, 2015 8:30:31 AM by jxva
 */
public class Rc4 extends CryptoProvider {

	public Rc4(int blockSize, PaddingMode padding) {
		super(blockSize,padding);
	}

	@Override
	public byte[] cbc_encrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_encrypt(CryptoMode.ARCFOUR,key,iv,data);
	}

	@Override
	public byte[] cbc_decrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_decrypt(CryptoMode.ARCFOUR,key,iv,data);
	}
	

}
