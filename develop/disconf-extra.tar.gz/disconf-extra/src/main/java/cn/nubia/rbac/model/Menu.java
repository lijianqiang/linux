package cn.nubia.rbac.model;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Menu  implements Serializable {

	private static final long serialVersionUID = 8193973912110968596L;
	protected Integer id;
	protected String title = StringUtils.EMPTY;
	protected String mainHref = StringUtils.EMPTY;
	protected String leftHref = StringUtils.EMPTY;


	public Menu () {
		super();
	}
	
	public Menu (
		 Integer in_menuId
		,String in_title
		,String in_mainHref
		,String in_leftHref
        ) {
		this.setId(in_menuId);
		this.setTitle(in_title);
		this.setMainHref(in_mainHref);
		this.setLeftHref(in_leftHref);
    }

    


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return this.title;
	}
	
	public void setTitle(String aValue) {
		this.title = aValue;
	}	

	public String getMainHref() {
		return this.mainHref;
	}
	
	public void setMainHref(String aValue) {
		this.mainHref = aValue;
	}	

	public String getLeftHref() {
		return this.leftHref;
	}
	
	public void setLeftHref(String aValue) {
		this.leftHref = aValue;
	}	



	public String toString() {
		return new ToStringBuilder(this)
				.append("menuId", this.id) 
				.append("title", this.title) 
				.append("mainHref", this.mainHref) 
				.append("leftHref", this.leftHref) 
				.toString();
	}


	public String getFirstKeyColumnName() {
		return "id";
	}
	
}