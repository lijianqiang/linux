package cn.nubia.framework.cache;

import java.util.LinkedHashMap;

/**
 * Last In First Out
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class LIFOCache extends AbstractCache {
	
	public LIFOCache(String name){
		this(name,DEFAULT_MAX_SIZE);
	}
	
	public LIFOCache(String name,int maxSize){
		this.name=name;
		this.maxSize=maxSize;
		this.map=new LinkedHashMap<Object,Element>();
	}
	
	protected final void doPut(Element element) throws CacheException {
        if (isFull()) {
            removeLastElement();
        }
    }

    Element getLastElement() {
        if (map.size() == 0) {
            return null;
        }
        Object[] keys = map.keySet().toArray();
        return map.get(keys[keys.length-1]);
    }
    
    private void removeLastElement() throws CacheException {
        remove(getLastElement().getKey());
    }
}
