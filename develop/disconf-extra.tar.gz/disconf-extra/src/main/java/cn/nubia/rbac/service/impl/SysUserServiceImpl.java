package cn.nubia.rbac.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Service;

import cn.nubia.admin.common.ResultFailException;
import cn.nubia.admin.service.UserEnvService;
import cn.nubia.rbac.model.DynamicRes;
import cn.nubia.rbac.model.Menu;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.service.DynamicResService;
import cn.nubia.rbac.service.MenuService;
import cn.nubia.rbac.service.SysUserService;

@Service(value="sysUserService")
public class SysUserServiceImpl  implements SysUserService{
	/**  
	 * NOT_EXISTED_ID:TODO 
	 */
	private static final int NOT_EXISTED_ID = -1;
	private static final Log log = LogFactory.getLog(SysUserServiceImpl.class);
	@Resource
	protected JdbcTemplate template;
	
	@Resource
	private MenuService menuService;
	
	@Resource
	private DynamicResService dynamicResService;
	
	@Autowired
    private UserEnvService userEnvService;
	
	public SysUser getSysUserByUsername(String username) {
		if(StringUtils.isBlank(username)) {
			log.error("[rbac user] get user by username , the username is blank");
			return null;
		} else {
			String sql = "select user_id,username,realname,password,email, add_time from tbl_user where username=? ";
			try {
				return (SysUser)this.template.queryForObject(sql, new Object[]{username}, new UserRowMapper());
			} catch(EmptyResultDataAccessException e) {
				return null;
			}
		}
	}

	@Override
	public void updatePassword(Integer userId, String password) {
		if(userId == null) {
			log.error("[rbac user] update password , the param userId is null.");
			throw new NullArgumentException("userId参数为空");
		}
		
		if(StringUtils.isBlank(password)) {
			log.error("[rbac user] update password , the param new password is null.");
			return;
		}
		template.update("update tbl_user set password=? where user_id=? ",new Object[]{password, userId});  
	}

	@Override
	public void save(SysUser user) {
		if(user == null) {
			log.error("[rbac user] save user method, the param user is null");
			throw new NullArgumentException("save user method, the param user is null");
		}
		if(this.existedUsernameWithOther(user.getUsername(), user.getId())) {
			log.error("[rbac user] save user method, the username is existed");
			throw new IllegalStateException("新的用户名已经在数据库存在，无法进行保存操作");
		}
		String sql = "insert into tbl_user(username,password, realname, email) values(?,?,?,?)";
        this.template.update(sql,new Object[]{user.getUsername(),user.getPassword(),user.getRealname(),user.getEmail()
        });
		
	}

	@Override
	public void delete(Integer id) {
		if(id == null) {
			log.error("[rbac user] delete user method, the param id is null");
			throw new NullArgumentException("delete user method, the param id is null");
		}
		String sql = "delete from tbl_user where user_id=?";
		this.template.update(sql, id);
		
		String delRoleUser = "delete from tbl_user_role where user_id=?";
		this.template.update(delRoleUser,id);
		
		userEnvService.deleteByUserId(id);
	}

	@Override
	public void update(SysUser user) {
		if(user == null) {
			log.error("[rbac user] update user method, the param user is null");
			throw new NullArgumentException("update role method, the param role is null");
		}
		if(user.getId() == null) {
			log.error("[rbac user] update role method, the param id is null");
			throw new NullArgumentException("update user method, the param id is null");
		}
		
		if(this.existedUsernameWithOther(user.getUsername(), user.getId())) {
			log.error("[rbac user] update user method, the username is existed");
			throw new IllegalStateException("新的用户名已经在数据库存在，无法进行保存操作");
		}
		String sql = "update tbl_user set username=?, realname=?, email=?  where user_id=?";
		this.template.update(sql, new Object[]{user.getUsername(),user.getRealname(),user.getEmail(),user.getId()});
	}

	@Override
	public SysUser getById(Integer id) {
		if(id == null) {
			log.error("[rbac user] getById method, the param id is null");
			return null;
		}
		String sql = "select user_id,username, realname,password, email,add_time from tbl_user where user_id=? ";
		try {
			SysUser obj = this.template.queryForObject(sql, new Object[]{id}, new UserRowMapper());
			return obj;
		} catch(EmptyResultDataAccessException e) {
			return null;
		}
	}

	@Override
	public List<SysUser> fetchAll() {
		String sql = "select * from tbl_user";
		return this.template.query(sql, new UserRowMapper());
	}

	@Override
	public void saveRole(SysUser user, List<Integer> roleId, List<Integer> envList) {
		if(user == null) {
			log.error("[rbac user] save user method, the param user is null");
			throw new NullArgumentException("save user method, the param user is null");
		}
		if(this.existedUsernameWithOther(user.getUsername(), user.getId())) {
			log.error("[rbac user] saveRole method, the username is existed");
			throw new ResultFailException("新的用户名已经存在，无法进行保存操作");
		}
        KeyHolder keyHolder = new GeneratedKeyHolder();  
        this.template.update(new PreparedStatementCreator() {
            @Override
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
            	String sql = "insert into tbl_user(username,password, realname, email) values(?,?,?,?)";
                PreparedStatement pstm = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                pstm.setString(1, user.getUsername());
                pstm.setString(2, user.getPassword());
                pstm.setString(3, user.getRealname());
                pstm.setString(4, user.getEmail());
                return pstm;
            }
        },keyHolder);
        
        userEnvService.save(keyHolder.getKey().intValue(), envList);;
        
        if(roleId == null || roleId.isEmpty()) {
			return ;
		}
        
        batchAddRoleId(roleId, keyHolder.getKey().intValue());
	}

	private void batchAddRoleId(List<Integer> roleId, Integer userId) {
		String roleSql = "insert into tbl_user_role(user_id, role_id) values(?,?)";
        List<Object[]> params = new ArrayList<Object[]>();
		
		for(Integer ele : roleId) {
			params.add(new Object[]{userId, ele});
		}
        this.template.batchUpdate(roleSql,params);
	}

	@Override
	public void updateRole(SysUser user, List<Integer> newRoleId, List<Integer> envList) {
		if(user == null) {
			log.error("[rbac user] updateRole method, the param user is null");
			throw new NullArgumentException("updateRole method, the param user is null");
		}
	
		String deleteRoleSql = "delete from tbl_user_role where user_id=?";
		this.template.update(deleteRoleSql, user.getId());
		update(user);
		
		userEnvService.save(user.getId(), envList);
		
		if(newRoleId == null || newRoleId.isEmpty()) {
			return ;
		}
		
		batchAddRoleId(newRoleId, user.getId());
	}

	@Override
	public List<Integer> fetchRoleIdsByUserId(Integer id) {
		if(id == null) {
			log.error("[rbac user] fetchRoleIdsByUserId method, the param id is null");
			throw new NullArgumentException("fetchRoleIdsByUserId method, the param id is null");
		}
		String sql = "select role_id from tbl_user_role where user_id=?";
		List<Integer> result = this.template.queryForList(sql, Integer.class, id);
		if(result == null) {
			result = new ArrayList<Integer>();
		}
		return result;
	}

	@Override
	public void setSysUserMenuAndResOper(SysUser user) {
		if(user == null || user.getId() == null) {
			log.error("[rbac user] setSysUserMenuAndResOper method, the param user or user id is null");
			throw new NullArgumentException("setSysUserMenuAndResOper method, the param user or user id is null");
		}
		
		//通过用户id查询角色
		List<Integer> roleIds = this.fetchRoleIdsByUserId(user.getId());
		if(roleIds == null || roleIds.isEmpty()) {
			log.warn("[rbac user] fetchRoleIdsByUserId method, the user role is empty");
			return;
		}
		
		//根据roles来查询菜单权限
		Map<String, Menu> menus =  this.menuService.fetchMenusByRoleIds(roleIds);
		//根据roles来查询动态资源权限
		Map<String, DynamicRes> res = this.dynamicResService.fetchResRecordsMapByRoleIds(roleIds);
		
		user.setMenus(menus);
		user.setRes(res);
	}

	@Override
	public boolean existedByRoleId(Integer id) {
		if(id == null) {
			log.error("[rbac user] fetchRoleIdsByUserId method, the param id is null");
			throw new NullArgumentException("fetchRoleIdsByUserId method, the param id is null");
		}
		String sql =  "select user_id from tbl_user_role where role_id=?";
		List<Integer> result = this.template.queryForList(sql, Integer.class,id);
		if(result == null || result.isEmpty()) {
			return false;
		}
		return true;
	}

	/**
	 * 
	 *	
	 * @param username
	 * @param id
	 * @return
	 * @author gsd
	 */
	@Override
	public boolean existedUsernameWithOther(String username, Integer id) {
		if(StringUtils.isBlank(username)) {
			log.error("[rabc user] existedUsernameWithOther, the param username is blank");
			return true;
		}
		
		String sql = "select user_id from tbl_user where username=? and user_id <> ?";
		if(id == null) {
			id = NOT_EXISTED_ID;
		}
		List<Integer> result = this.template.queryForList(sql, Integer.class, new Object[]{username, id});
		if(result == null || result.isEmpty()) {
			return false;
		}
		
		return true;
	}
}
class UserRowMapper implements RowMapper<SysUser> {
	public SysUser mapRow(ResultSet rs, int index) throws SQLException {
		SysUser user = new SysUser();
		user.setId(rs.getInt("user_id"));
		user.setUsername(rs.getString("username"));
		user.setRealname(rs.getString("realname"));
		user.setPassword(rs.getString("password")==null?StringUtils.EMPTY:rs.getString("password"));
		user.setEmail(rs.getString("email"));
		user.setAddTime(new Timestamp(rs.getLong("add_time")));
		return user;
	}
}
