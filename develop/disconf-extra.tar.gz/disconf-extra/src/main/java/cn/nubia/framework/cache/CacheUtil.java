package cn.nubia.framework.cache;


/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public final class CacheUtil{
	
	private static final Cache cache=new LRUCache("default");
	
	private CacheUtil(){
		
	}
	
	public static Cache getCache(){
		return cache;
	}

	public static void destroy(){
		cache.clear();
	}
}
