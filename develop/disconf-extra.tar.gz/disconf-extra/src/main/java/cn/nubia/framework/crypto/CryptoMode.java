package cn.nubia.framework.crypto;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Dec 29, 2014 9:58:42 AM by jxva
 */
public enum CryptoMode {
	AES, DES, DESede, RC2, ARCFOUR, Blowfish, RSA
}
