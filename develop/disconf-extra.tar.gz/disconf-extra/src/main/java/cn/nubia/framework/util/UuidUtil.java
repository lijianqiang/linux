package cn.nubia.framework.util;

import java.util.UUID;

/**
 * @author lijianqiang
 *
 */
public class UuidUtil {

	public static String getUuid() {
		UUID uuid = UUID.randomUUID();
		return uuid.toString().replaceAll("-", "");
	}
}
