package cn.nubia.admin.service;

import java.util.List;

import com.baidu.disconf.web.service.app.bo.App;

import cn.nubia.admin.common.PagerBean;

/**
 * 新后台的app查询service，根据新的权限
 * 
 * @author lijianqiang
 *
 */
public interface AppExtraService {
	List<App> getAll();

    PagerBean<App> getListByPage(int adminId, PagerBean<App> pager);

    App getById(Long id);

    List<App> getByAdminId(int adminId);
    
    void delete(Long id);
	
	void updateNameById(Long id, String name);
}
