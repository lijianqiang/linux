package cn.nubia.rbac.util;

import cn.nubia.framework.cache.Cache;
import cn.nubia.framework.cache.Element;
import cn.nubia.framework.cache.FastCache;
import cn.nubia.rbac.model.SysUser;

/*** 
 *  @Program Name  : nubia_browser_admin.cn.nubia.rbac.util.RbacCache.java
 *  @Written by    : linjin
 *  @Creation Date : 2015年4月22日 下午8:31:41 
 *  @version       : v1.00
 *  @Description   : RbacCache封装类 
 *  
 *  
 *  
 *  @ModificationHistory  
 *  Who          When                What 
 *  --------     ----------          ------------------------------------------------ 
 *  username   2015年4月22日下午8:31:41      TODO
 *  
 *  
***/
public class RbacCache {
	private static final Cache cache=new FastCache("sysUser", 300*10000);
	
	public static SysUser get(String workId){
		Element element=cache.get(workId);
		if(element!=null){
			return (SysUser)element.getValue();
		}else{
			return null;
		}
	}
	
	/**
	 * @param workId w
	 * @param employee e
	 */
	public static void put(String workId,SysUser employee){
		Element element=new Element(workId, employee);
		cache.put(workId, element);
	}
	
	/**
	 * @param workId w
	 */
	public static void remove(String workId){
		cache.remove(workId);
	}
}
