package cn.nubia.framework.util;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public abstract class CharUtil {
	
    public static final char[] UPPER_CHAR_TABLE ={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	
    public static final char[] LOWWER_CHAR_TABLE ={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    
    public static final char[] CHAR_TABLE ={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    
	
	/**
	 * Get hex string from byte array
	 */
	public static String toHexString(byte[] bytes) {
		StringBuffer sb = new StringBuffer(bytes.length << 1);
		for (int i = 0; i < bytes.length; i++) {
			String digit = Integer.toHexString(0xFF & bytes[i]);
			if (digit.length() == 1) {
				digit = '0' + digit;
			}
			sb.append(digit);
		}
		return sb.toString().toUpperCase();
	}

	/**
	 * Get byte array from hex string
	 */
	public static byte[] toByteArray(String hexString) {
		int arrLength = hexString.length() >> 1;
		byte buff[] = new byte[arrLength];
		for (int i = 0; i < arrLength; i++) {
			int index = i << 1;
			String digit = hexString.substring(index, index + 2);
			buff[i] = (byte) Integer.parseInt(digit, 16);
		}
		return buff;
	}

	
    public static byte charToByte(char ch) {
		switch (ch) {
		case 48: // '0'
			return 0;
		case 49: // '1'
			return 1;
		case 50: // '2'
			return 2;
		case 51: // '3'
			return 3;
		case 52: // '4'
			return 4;
		case 53: // '5'
			return 5;
		case 54: // '6'
			return 6;
		case 55: // '7'
			return 7;
		case 56: // '8'
			return 8;
		case 57: // '9'
			return 9;
		case 97: // 'a'
			return 10;
		case 98: // 'b'
			return 11;
		case 99: // 'c'
			return 12;
		case 100: // 'd'
			return 13;
		case 101: // 'e'
			return 14;
		case 102: // 'f'
			return 15;
		case 58: // ':'
		case 59: // ';'
		case 60: // '<'
		case 61: // '='
		case 62: // '>'
		case 63: // '?'
		case 64: // '@'
		case 65: // 'A'
		case 66: // 'B'
		case 67: // 'C'
		case 68: // 'D'
		case 69: // 'E'
		case 70: // 'F'
		case 71: // 'G'
		case 72: // 'H'
		case 73: // 'I'
		case 74: // 'J'
		case 75: // 'K'
		case 76: // 'L'
		case 77: // 'M'
		case 78: // 'N'
		case 79: // 'O'
		case 80: // 'P'
		case 81: // 'Q'
		case 82: // 'R'
		case 83: // 'S'
		case 84: // 'T'
		case 85: // 'U'
		case 86: // 'V'
		case 87: // 'W'
		case 88: // 'X'
		case 89: // 'Y'
		case 90: // 'Z'
		case 91: // '['
		case 92: // '\\'
		case 93: // ']'
		case 94: // '^'
		case 95: // '_'
		case 96: // '`'
		default:
			return 0;
		}
	}

	public static void main(String[] args)throws Exception {

	}


}
