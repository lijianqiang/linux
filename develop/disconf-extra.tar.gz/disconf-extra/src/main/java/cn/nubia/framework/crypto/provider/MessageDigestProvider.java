package cn.nubia.framework.crypto.provider;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import cn.nubia.framework.crypto.CryptoException;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version 2014-12-17 08:31:38 by jxva
 */
public class MessageDigestProvider {


	public static byte[] encrypt(String hash,byte[] data) {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance(hash);
			messageDigest.update(data);
			return messageDigest.digest();
		} catch (NoSuchAlgorithmException e) {
			throw new CryptoException(e);
		}
	}

	public static byte[] hmac(String hmac, byte[] data, byte[] key) {
		try {
			SecretKeySpec signingKey = new SecretKeySpec(key, hmac);
			Mac mac = Mac.getInstance(hmac);
			mac.init(signingKey);
			return mac.doFinal(data);
		} catch (InvalidKeyException | NoSuchAlgorithmException e) {
			throw new CryptoException(e);
		}
	}

	public static byte[] checksum(String hash,File file) {
		try (FileInputStream fis = new FileInputStream(file)) {
			MessageDigest messageDigest = MessageDigest.getInstance(hash);
			byte[] dataBytes = new byte[1024];
			int nread = 0;
			while ((nread = fis.read(dataBytes)) != -1) {
				messageDigest.update(dataBytes, 0, nread);
			}
			return messageDigest.digest();
		} catch (IOException | NoSuchAlgorithmException e) {
			throw new CryptoException(e);
		}
	}
}
