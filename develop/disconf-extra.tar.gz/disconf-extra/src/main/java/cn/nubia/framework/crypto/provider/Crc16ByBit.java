package cn.nubia.framework.crypto.provider;

/**
 * 
 * The CRC-16 class calculates a 16 bit cyclic redundancy check of a set of
 * bytes. This error detecting code is used to determine if bit rot has occurred
 * in a byte stream.
 * 
 * CRC16 0x8005 x^16 + x^15 + x^2 + 1
 * 
 * crc16("123456789") = 0xbb3d
 * crc16("The quick brown fox jumps over the lazy dog") = 0xfcdf
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 29, 2015 11:13:15 AM by jxva
 */
public class Crc16ByBit {
	private static final int POLY = 0x8005;

	private int value;

	public Crc16ByBit() {
		value = 0x0000;
	}

	public void update(byte b) {
		int temp = (value ^ b) & 0xff;

		for (int count = 0; count < 8; count++) {
			if ((temp & 0x8000) !=0) {
				temp = (temp << 1) ^ POLY;
			} else {
				temp = (temp << 1);
			}
			if ((b & count) != 0) {
				temp ^= POLY;
			}
		}
		
		value = (value >>> 8) ^ temp;
		
		//value = (value >>> 8) ^ table[(value ^ b) & 0xff];
	}

	public void update(byte[] data) {
		for (int i = 0; i < data.length; i++) {
			update(data[i]);
		}
	}

	public int value() {
		return value;
	}

	public String checksum(byte[] data) {
		reset();
		update(data);
		// String v = Integer.toHexString(value);
		return String.format("%04x", value);
	}

	public void reset() {
		value = 0x0000;
	}
}
