package cn.nubia.framework.exception;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class NestableException extends Exception implements Nestable {

	private static final long serialVersionUID = 1994545347639397172L;

	protected NestableDelegate delegate = new NestableDelegate( this );

	private Throwable cause = null;

	public NestableException() {
		super();
	}

	public NestableException(String msg) {
		super( msg );
	}

	public NestableException(Throwable cause) {
		super();
		this.cause = cause;
	}

	public NestableException(String msg, Throwable cause) {
		super( msg );
		this.cause = cause;
	}

	@Override
	public Throwable getCause() {
		return cause;
	}

	@Override
	public String getMessage() {
		if ( super.getMessage() != null ) {
			return super.getMessage();
		}
		else if ( cause != null ) {
			return cause.toString();
		}
		else {
			return null;
		}
	}

	@Override
	public String getMessage(int index) {
		if ( index == 0 ) {
			return super.getMessage();
		}
		else {
			return delegate.getMessage( index );
		}
	}

	@Override
	public String[] getMessages() {
		return delegate.getMessages();
	}

	@Override
	public Throwable getThrowable(int index) {
		return delegate.getThrowable( index );
	}

	@Override
	public int getThrowableCount() {
		return delegate.getThrowableCount();
	}

	@Override
	public Throwable[] getThrowables() {
		return delegate.getThrowables();
	}

	@Override
	public int indexOfThrowable(Class<?> type) {
		return delegate.indexOfThrowable( type, 0 );
	}

	@Override
	public int indexOfThrowable(Class<?> type, int fromIndex) {
		return delegate.indexOfThrowable( type, fromIndex );
	}

	@Override
	public void printStackTrace() {
		delegate.printStackTrace();
	}

	@Override
	public void printStackTrace(PrintStream out) {
		delegate.printStackTrace( out );
	}

	@Override
	public void printStackTrace(PrintWriter out) {
		delegate.printStackTrace( out );
	}

	@Override
	public final void printPartialStackTrace(PrintWriter out) {
		super.printStackTrace( out );
	}

}
