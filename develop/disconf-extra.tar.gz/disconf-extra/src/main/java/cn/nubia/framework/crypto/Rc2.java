package cn.nubia.framework.crypto;

import cn.nubia.framework.crypto.provider.CryptoProvider;

/**
 *
 * Key sizes	8–1024 bits, in steps of 8 bits; default 64 bits
 * Block sizes	64 bits
 * Structure	Source-heavy unbalanced Feistel network
 * Rounds		16 of type MIXING, 2 of type MASHING
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 27, 2015 8:41:47 PM by jxva
 */
public class Rc2 extends CryptoProvider {

	public Rc2(int blockSize, PaddingMode padding) {
		super(blockSize, padding);
	}

	@Override
	public byte[] cbc_encrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_encrypt(CryptoMode.RC2, key, iv, data);
	}

	@Override
	public byte[] cbc_decrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_decrypt(CryptoMode.RC2, key, iv, data);
	}
	

}