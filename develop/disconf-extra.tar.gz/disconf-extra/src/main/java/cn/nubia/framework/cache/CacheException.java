package cn.nubia.framework.cache;

import cn.nubia.framework.exception.NestableRuntimeException;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class CacheException extends NestableRuntimeException {

	public CacheException(){
		super();
	}
	
	public CacheException(Throwable root) {
		super(root);
	}

	public CacheException(String string, Throwable root) {
		super(string, root);
	}

	public CacheException(String s) {
		super(s);
	}

}
