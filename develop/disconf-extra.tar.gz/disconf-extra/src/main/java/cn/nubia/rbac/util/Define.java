package cn.nubia.rbac.util;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @author xjxue
 * 定义常量类
 */
public abstract class Define {
	
	private static final int CONSTANT_2 = 2;
	private static final int CONSTANT_3 = 3;
	private static final int CONSTANT_4 = 4;
	private static final int CONSTANT_9 = 9;
	private static final int CONSTANT_10 = 10;
	private static final int CONSTANT_12 = 12;
	private static final int CONSTANT_1000 = 1000;
	private static final int CONSTANT_2011 = 2011;
	private static final int CONSTANT_2012 = 2012;
	private static final int CONSTANT_2013 = 2013;
	private static final int CONSTANT_8999 = 8999;
	public static final int DAY_SECONDS = 86400;
	public static final String DEFAULT_PASSWORD="123456";
	public static final String KEY="key_in_nubia";
	public static final String SESSION_IN_USER="session_in_user";
	public static final String COOKIE_IN_USERID="cookie_in_userid";
	public static final String COOKIE_IN_REALNAME="cookie_in_realname";
	
	public static  int[] YEARS={CONSTANT_2012,CONSTANT_2013};
	public static final int[] MONTHS={1,2,3,4,5,6,7,8,9,10,11,12};
	public static final int[] WEEKS={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,
		17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,
		40,41,42,43,44,45,46,47,48,49,50,51,52,53};
	
	private static final DecimalFormat DECIMAL_FORMAT=new DecimalFormat("#####0.00");
	public static final Calendar CALENDAR = Calendar.getInstance();
	private static final long	ONE_DAY=24*60*60;
	
	// avatar begin
	public static final String AVATAR_PATH = "upload/avatars/"; // 上传头像的目录
	public static final String[] ALLOWED_AVATAR_TYPES = {".jpg", ".png", ".gif"}; // 上传头像允许的文件类型
	public static final int MAX_AVATAR_SIZE = 1024*300;	// 上传头像文件大小最大为300KB
	
	public static final int ERR_FILE_TOOBIG = -2;
	public static final int ERR_NOSUPPORTED_TYPE = -1;
	// avatar end
	
	public static final int RESULT_CODE_ERR = 0;
	public static final int RESULT_CODE_SUCCESS = 1;
	
	public static final int ERR_PHONE_ILLEGAL = -10000;
	
	static {
		int year = CALENDAR.get(Calendar.YEAR);
		int size = year - CONSTANT_2011;
		if (size > 0) {
			int[] myyear = new int[size];
			for (int i = 0; i < size; i++) {
				myyear[i] = CONSTANT_2012 + i;
			}
			YEARS = myyear;
		}
	}
	
	/**
	 * @param d D
	 * @return R
	 */
	public static final BigDecimal formatNumber(Double d){
		return BigDecimal.valueOf(Double.valueOf(DECIMAL_FORMAT.format(d)));
	}
	
	/**
	 * @param date d
	 * @return r
	 */
	public static int getDayOfWeek(Date date){
		CALENDAR.setTime(date);  
		return CALENDAR.get(Calendar.DAY_OF_WEEK)-1;
	}
	
	/**
	 * @param year y
	 * @param month m
	 * @return r
	 */
	public static final int getDays(int year,int month){
		CALENDAR.set(year,month-1,1);
		return CALENDAR.getActualMaximum(Calendar.DAY_OF_MONTH);
	}
	
	/**
	 * @param year1 y 
	 * @param month1 m
	 * @param year2 y
	 * @param month2 m
	 * @return r
	 */
	public static String[] getMonthArea(int year1, int month1, int year2,
			int month2) {
		int months = Define.getMonthArea(
				java.sql.Date.valueOf(year1 + "-"
						+ (month1 < CONSTANT_10 ? "0" + month1 : month1)
						+ "-01"),
				java.sql.Date.valueOf(year2 + "-"
						+ (month2 < CONSTANT_10 ? "0" + month2 : month2) + "-"
						+ Define.getDays(year2, month2)));
		String[] monthArea = new String[months];
		for (int i = month1 - 1; i < months + month1 - 1; i++) {
			int tmp = i % CONSTANT_12 + 1;
			monthArea[i - month1 + 1] = (year1 + i / CONSTANT_12) + "年"
					+ (tmp > CONSTANT_9 ? tmp : "0" + tmp) + "月";
		}
		return monthArea;
	}

	/**
     * @param begindate b
     * @param enddate e
     * @return r
     */
    public static int getMonthArea(Date begindate,Date enddate) {
        Calendar startCalendar = Calendar.getInstance();
        startCalendar.setTime(begindate);
        Calendar endCalendar = Calendar.getInstance();
        endCalendar.setTime(enddate);
        Calendar temp = Calendar.getInstance();
        temp.setTime(enddate);
        temp.add(Calendar.DATE, 1);

        int returnInt = 0;
        int year = endCalendar.get(Calendar.YEAR)
                - startCalendar.get(Calendar.YEAR);
        int month = endCalendar.get(Calendar.MONTH)
                - startCalendar.get(Calendar.MONTH);

        if ((startCalendar.get(Calendar.DATE) == 1)
                && (temp.get(Calendar.DATE) == 1)) {
        	returnInt = ( year * CONSTANT_12 + month + 1);
        } else if ((startCalendar.get(Calendar.DATE) != 1)
                && (temp.get(Calendar.DATE) == 1)) {
        	returnInt = ( year * CONSTANT_12 + month);
        } else if ((startCalendar.get(Calendar.DATE) == 1)
                && (temp.get(Calendar.DATE) != 1)) {
        	returnInt = ( year * CONSTANT_12 + month);
        } else {
        	returnInt = ((year * CONSTANT_12 + month - 1) < 0 ? 0 : (year * CONSTANT_12 + month));
        }
        return returnInt;
    }
    
	/**
	 * @return r
	 */
	public static List<String> allowDates(){
		CALENDAR.setTime(new Date());  
		int dayOfWeek=CALENDAR.get(Calendar.DAY_OF_WEEK)-1;
		int allowDay;
		switch(dayOfWeek){
			case 0:
				allowDay=CONSTANT_3;
				break; 
			case 1:
				allowDay=CONSTANT_4;
				break;
			default:
				allowDay=CONSTANT_2;
		}
		List<String> list=new ArrayList<String>(allowDay);
		for(int i=0;i<allowDay;i++){
			Date tmp=new Date();
			tmp.setTime(CONSTANT_1000*((tmp.getTime()/CONSTANT_1000)-ONE_DAY*i));
			list.add(new Timestamp(tmp.getTime()).toString().substring(0,CONSTANT_10));
		}
		return list;
	}
	
	/**
	 * @param begin b 
	 * @param end e
	 * @return r
	 */
	public static List<Date> getDateList(Date begin,Date end){
		int differ=getDifferDays(begin,end);
		List<Date> temp=new ArrayList<Date>(differ);
		for(int i=0;i<=differ;i++){
			CALENDAR.setTime(begin);
			CALENDAR.add(Calendar.DATE,i);
			temp.add(CALENDAR.getTime());
		}
		return temp;
	}
	
	/**
	 * @param begin b 
	 * @param end e
	 * @return r
	 */
	public static int getDifferDays(Date begin,Date end){
		Long d=((end.getTime()-begin.getTime())/CONSTANT_1000/ONE_DAY);
		return d.intValue();
	}
	
	/**
	 * @param date d
	 * @param offset o
	 * @return r
	 */
	public static List<Date> listOffsetDate(Date date,int offset){
		List<Date> temp=new ArrayList<Date>(offset<0?-offset:offset);
		if(offset>0){
			for(int i=0;i<=offset;i++){
				CALENDAR.setTime(date);
				CALENDAR.add(Calendar.DATE,i);
				temp.add(CALENDAR.getTime());
			}
		}else{
			for(int i=offset;i<=0;i++){
				CALENDAR.setTime(date);
				CALENDAR.add(Calendar.DATE,i);
				temp.add(CALENDAR.getTime());
			}
		}
		return temp;
	}
	

	
	/**
	 * @param args a
	 */
	public static void main(String[] args){
//		List<Date> list=listOffsetDate(java.sql.Date.valueOf("2012-04-10"),-6);
//		for(Date d:list){
//			System.out.println(d);
//		}
	}
}
