package cn.nubia.rbac.service;

import java.util.List;
import java.util.Map;

import cn.nubia.rbac.model.DynamicRes;
import cn.nubia.rbac.model.DynamicResType;

public interface DynamicResService extends RBACBaseService<DynamicRes> {

	List<DynamicResType> fetchTypeAll();

	List<Integer> fetchResByRoleId(Integer roleId);

	/**
	 * 功能： 获取所有APK数据资源信息
	 * 注意：1、为了对业务逻辑没有侵入性，rbac编写模块并不能对apkInfo业务层进行代码侵入
	 *        所以，在这里写了获取数据资源的逻辑。（如果apkInfo业务逻辑层具有这个功能，则直接调用即可）
	 * @return
	 * 2015年10月16日 下午2:52:12
	 * gsd
	 */
//	List<App> fetchAllApk();

	/**
	 * 功能：根据角色id获取数据资源操作权限，此数据资源操作包含该角色分配的数据资源id号，以逗号隔开。
	 * 注意：比如DynamiceRes 是“查看应用操作”,ResRecords的是该角色具有的应用资源ID，中间逗号隔开
	 * @param roleId
	 * @return
	 * 2015年10月16日 下午2:54:19
	 * gsd
	 */
	List<DynamicRes> fetchResRecordsByRoleId(Integer roleId);
	
	/**
	 * 功能：通过角色ids获取操作资源信息
	 * 注意：Map<dynamicRes.mainHref, dynamicRes>
	 * @param roleIds
	 * @return
	 * 2015年10月16日 下午2:58:38
	 * gsd
	 */
	Map<String, DynamicRes> fetchResRecordsMapByRoleIds(List<Integer> roleIds);
	
	boolean existedTitleWithOther(String title, Integer id);
	
	boolean existedMainHrefWithOther(String mainHref, Integer id);
}
