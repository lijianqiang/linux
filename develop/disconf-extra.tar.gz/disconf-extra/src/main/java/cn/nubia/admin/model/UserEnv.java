package cn.nubia.admin.model;

import java.io.Serializable;

public class UserEnv implements Serializable {

	private static final long serialVersionUID = -3432030459931974505L;

	private Integer id;
	
	private int userId;
	
	private long envId;
	
	private String envName;
	
	public UserEnv() {
		this(0, "");
	}
	
	public UserEnv(long envId, String envName) {
		this.id = 0;
		this.userId = 0;
		this.envId = envId;
		this.envName = envName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public long getEnvId() {
		return envId;
	}

	public void setEnvId(long envId) {
		this.envId = envId;
	}

	public String getEnvName() {
		return envName;
	}

	public void setEnvName(String envName) {
		this.envName = envName;
	}
	
}
