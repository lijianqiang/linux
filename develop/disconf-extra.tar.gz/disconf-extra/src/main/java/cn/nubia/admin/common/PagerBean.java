package cn.nubia.admin.common;

import java.util.ArrayList;
import java.util.List;

public class PagerBean<E> {

    private List<E> rows;
    private int total = 0;
    private int offset = 0;
    private int limit = 20;
    public PagerBean(){}

    public static <T> PagerBean<T> emptyPager(){
        PagerBean<T> pager = new PagerBean<>();
        pager.setRows(new ArrayList<>());
        pager.setTotal(0);
        return pager;
    }
    public <T> PagerBean<T> convert(List<T> list){
        PagerBean<T> pagerBean = new PagerBean<>();
        pagerBean.setOffset(this.getOffset());
        pagerBean.setLimit(this.getLimit());
        pagerBean.setTotal(this.getTotal());
        pagerBean.setRows(list);
        return pagerBean;
    }
    public List<E> getRows() {
        return rows;
    }
    public void setRows(List<E> rows) {
        this.rows = rows;
    }
    public int getTotal() {
        return total;
    }
    public void setTotal(int total) {
        this.total = total;
    }
    public int getOffset() {
        return offset;
    }
    public void setOffset(int offset) {
        this.offset = offset;
    }
    public int getLimit() {
        return limit;
    }
    public void setLimit(int limit) {
        this.limit = limit;
    }
}
