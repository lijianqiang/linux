package cn.nubia.framework.crypto;

import cn.nubia.framework.crypto.provider.Crc32ByReversedTable;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 28, 2015 6:03:46 PM by jxva
 */
public class Crc32 extends Crc32ByReversedTable {

}
