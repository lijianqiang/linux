package cn.nubia.framework.entity;

public class Base64 {

	private static final char[] ALPHABET = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/', '=' };
	private static final byte[] CODES = new byte[256];
	static {
		for (int i = 0; i < 256; i++)
			CODES[i] = -1;
		for (int i = 'A'; i <= 'Z'; i++)
			CODES[i] = (byte) (i - 'A');
		for (int i = 'a'; i <= 'z'; i++)
			CODES[i] = (byte) (26 + i - 'a');
		for (int i = '0'; i <= '9'; i++)
			CODES[i] = (byte) (52 + i - '0');
		CODES['+'] = 62;
		CODES['/'] = 63;
	}

	public static String encode(byte[] data) {
		return new String(encoder(data));
	}

	public static byte[] decode(String data) {
		return decoder(data.toCharArray());
	}

	public static char[] encoder(byte[] data) {
		char[] out = new char[((data.length + 2) / 3) * 4];
		for (int i = 0, index = 0; i < data.length; i += 3, index += 4) {
			boolean quad = false;
			boolean trip = false;
			int val = (0xFF & (int) data[i]);
			val <<= 8;
			if ((i + 1) < data.length) {
				val |= (0xFF & (int) data[i + 1]);
				trip = true;
			}
			val <<= 8;
			if ((i + 2) < data.length) {
				val |= (0xFF & (int) data[i + 2]);
				quad = true;
			}
			out[index + 3] = ALPHABET[(quad ? (val & 0x3F) : 64)];
			val >>= 6;
			out[index + 2] = ALPHABET[(trip ? (val & 0x3F) : 64)];
			val >>= 6;
			out[index + 1] = ALPHABET[val & 0x3F];
			val >>= 6;
			out[index + 0] = ALPHABET[val & 0x3F];
		}
		return out;
	}

	public static byte[] decoder(char[] data) {
		int len = ((data.length + 3) / 4) * 3;
		if (data.length > 0 && data[data.length - 1] == '=') {
			--len;
		}
		if (data.length > 1 && data[data.length - 2] == '=') {
			--len;
		}
		byte[] out = new byte[len];
		int shift = 0;
		int accum = 0;
		int index = 0;
		for (int ix = 0; ix < data.length; ix++) {
			int value = CODES[data[ix] & 0xFF];
			if (value >= 0) {
				accum <<= 6;
				shift += 6;
				accum |= value;
				if (shift >= 8) {
					shift -= 8;
					out[index++] = (byte) ((accum >> shift) & 0xff);
				}
			}
		}
		if (index != out.length) {
			throw new RuntimeException("Invalid length of data to decode.");
		}
		return out;
	}
}