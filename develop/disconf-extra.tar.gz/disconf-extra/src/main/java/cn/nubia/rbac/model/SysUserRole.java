package cn.nubia.rbac.model;

import java.io.Serializable;

public class SysUserRole  implements Serializable {
	
	private static final long serialVersionUID = -5532297495960078394L;

	private Integer id;
	
	private SysUser sysUser;
	private Role role;
	
	
	public SysUser getSysUser() {
		return sysUser;
	}


	public void setSysUser(SysUser sysUser) {
		this.sysUser = sysUser;
	}


	public Role getRole() {
		return role;
	}


	public void setRole(Role role) {
		this.role = role;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}
	
}
