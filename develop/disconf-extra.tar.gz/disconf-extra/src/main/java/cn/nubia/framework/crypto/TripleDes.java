package cn.nubia.framework.crypto;

import cn.nubia.framework.crypto.provider.CryptoProvider;


/**
 * 3DES（或称为Triple DES）是三重数据加密算法（TDEA，Triple Data Encryption
 * Algorithm）块密码的通称。它相当于是对每个数据块应用三次DES加密算法。
 * 由于计算机运算能力的增强，原版DES密码的密钥长度变得容易被暴力破解；
 * 3DES即是设计用来提供一种相对简单的方法，即通过增加DES的密钥长度来避免类似的攻击，而不是设计一种全新的块密码算法。
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Dec 17, 2014 10:29:36 AM by jxva
 */
public class TripleDes extends CryptoProvider {

	public TripleDes(int blockSize, PaddingMode padding) {
		super(blockSize, padding);
	}

	@Override
	public byte[] cbc_encrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_encrypt(CryptoMode.DESede, key, iv, data);
	}

	@Override
	public byte[] cbc_decrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_decrypt(CryptoMode.DESede, key, iv, data);
	}
	
}
