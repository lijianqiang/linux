package cn.nubia.framework.crypto;

import cn.nubia.framework.crypto.provider.CryptoProvider;


/**
 * 
 * Advanced Encryption Standard (AES)
 * 
 * <pre>
 * 算法/模式/填充 			16字节加密后数据长度 		不满16字节加密后长度
 * AES/CBC/NoPadding 		16 						不支持
 * AES/CBC/PKCS5Padding 	32 						16 
 * AES/CBC/ISO10126Padding 	32 						16
 * AES/CFB/NoPadding 		16 						原始数据长度
 * AES/CFB/PKCS5Padding 	32 						16
 * AES/CFB/ISO10126Padding 	32 						16
 * AES/ECB/NoPadding 		16 						不支持
 * AES/ECB/PKCS5Padding 	32 						16 
 * AES/ECB/ISO10126Padding  32 						16
 * AES/OFB/NoPadding 		16 						原始数据长度
 * AES/OFB/PKCS5Padding 	32 						16
 * AES/OFB/ISO10126Padding 	32 						16
 * AES/PCBC/NoPadding 		16 						不支持
 * AES/PCBC/PKCS5Padding 	32 						16
 * AES/PCBC/ISO10126Padding 32 						16
 * </pre>
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Dec 17, 2014 10:29:36 AM by jxva
 */
public class Aes extends CryptoProvider{


	public Aes(PaddingMode padding) {
		super(128,padding);
	}
	
	@Override
	public byte[] cbc_encrypt(byte[] key, byte[] iv, byte[] data) {
		return cbc_encrypt(CryptoMode.AES,key,iv,data);
	}

	@Override
	public byte[] cbc_decrypt(byte[] key, byte[] iv, byte data[]) {
		return cbc_decrypt(CryptoMode.AES,key,iv,data);
	}
	
	
}
