package cn.nubia.framework.tag;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 21, 2015 3:43:14 PM by jxva
 */
public class Tag {

}
