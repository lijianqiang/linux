package cn.nubia.admin.controller.backend;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baidu.disconf.web.service.zookeeper.form.ZkDeployForm;
import com.baidu.disconf.web.service.zookeeper.service.ZkDeployMgr;
import com.baidu.disconf.web.web.config.dto.ConfigFullModel;
import com.baidu.disconf.web.web.zookeeper.validator.ZkDeployValidator;
import com.baidu.dsp.common.controller.BaseController;
import com.baidu.dsp.common.vo.JsonObjectBase;

import cn.nubia.admin.ExtraConstant;

/**
 * Zoo API
 *
 * @author lijianqiang
 * @version 2016-10-18
 */
@Controller
@RequestMapping(ExtraConstant.API_PREFIX + "/zoo")
public class ZooExtraController extends BaseController {

    protected static final Logger LOG = LoggerFactory.getLogger(ZooExtraController.class);

    @Autowired
    private ZkDeployValidator zkDeployValidator;

    @Autowired
    private ZkDeployMgr zkDeployMgr;


    /**
     * 获取ZK 部署情况
     *
     * @param zkDeployForm
     *
     * @return
     */
    @RequestMapping(value = "/zkdeploy", method = RequestMethod.GET)
    @ResponseBody
    public JsonObjectBase getZkDeployInfo(@Valid ZkDeployForm zkDeployForm) {

        LOG.info(zkDeployForm.toString());

        ConfigFullModel configFullModel = zkDeployValidator.verify(zkDeployForm);

        String data = zkDeployMgr.getDeployInfo(configFullModel.getApp().getName(), configFullModel.getEnv().getName(),
                zkDeployForm.getVersion());

        return buildSuccess("hostInfo", data);
    }
}