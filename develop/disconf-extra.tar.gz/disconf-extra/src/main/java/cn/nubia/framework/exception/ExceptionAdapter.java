package cn.nubia.framework.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class ExceptionAdapter extends RuntimeException {
	
	private static final long serialVersionUID = -8843433367629441377L;
	
	private final String stackTrace;
	public Exception originalException;

	public ExceptionAdapter(Exception e) {
		super(e.toString());
		originalException = e;
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		stackTrace = sw.toString();
	}

	@Override
	public void printStackTrace() {
		printStackTrace(System.err);
	}

	@Override
	public void printStackTrace(java.io.PrintStream s) {
		synchronized (s) {
			s.print(getClass().getName() + ": ");
			s.print(stackTrace);
		}
	}

	@Override
	public void printStackTrace(java.io.PrintWriter s) {
		synchronized (s) {
			s.print(getClass().getName() + ": ");
			s.print(stackTrace);
		}
	}

	public void rethrow() {
		try {
			throw originalException;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
