package cn.nubia.framework.crypto;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Dec 17, 2014 10:49:47 AM by jxva
 */
public enum PaddingMode {
	NoPadding,  SpacePadding, PKCS5Padding, ISO10126Padding
	//ZeroPadding,  PKCS1Padding, PKCS7Padding, SSL3Padding, OAEPPadding
}
