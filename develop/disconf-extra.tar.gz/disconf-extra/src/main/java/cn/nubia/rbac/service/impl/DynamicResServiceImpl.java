package cn.nubia.rbac.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.NullArgumentException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import cn.nubia.admin.common.ResultFailException;
import cn.nubia.rbac.model.DynamicRes;
import cn.nubia.rbac.model.DynamicResType;
import cn.nubia.rbac.model.RoleDynamicRes;
import cn.nubia.rbac.service.DynamicResService;
import cn.nubia.rbac.util.ResTypeCache;

@Service("dynamicResService")
public class DynamicResServiceImpl implements DynamicResService {
	@Resource
	protected JdbcTemplate template;
	private static final Log log = LogFactory.getLog(MenuServiceImpl.class);
	private static final Integer NOT_EXISTED_ID = -1;
	private static final String SELECT_ALL = "0";
	@Override
	public void save(DynamicRes dynamicRes) {
		if(dynamicRes == null) {
			log.error("[rbac dynamicRes] save dynamicRes method, the param dynamicRes is null");
			throw new NullArgumentException("save dynamicRes method, the param dynamicRes is null");
		}
		this.checkExistMainHref(dynamicRes);
		this.checkExistTitle(dynamicRes);
		String sql = "insert into tbl_dynamic_res(title,main_href,dynamic_res_type_id) values(?,?,?)";
        this.template.update(sql,new Object[]{dynamicRes.getTitle(),dynamicRes.getMainHref(),dynamicRes.getResTypeId()});
	}
	@Override
	public void delete(Integer id) {
		if(id == null) {
			log.error("[rbac dynamicRes] delete dynamicRes method, the param id is null");
			throw new NullArgumentException("delete dynamicRes method, the param id is null");
		}
		String sql = "delete from tbl_dynamic_res where id=?";
		this.template.update(sql, id);
	}

	@Override
	public void update(DynamicRes dynamicRes) {
		if(dynamicRes == null) {
			log.error("[rbac dynamicRes] update dynamicRes method, the param dynamicRes is null");
			throw new NullArgumentException("update dynamicRes method, the param dynamicRes is null");
		}
		if(dynamicRes.getId() == null) {
			log.error("[rbac dynamicRes] update dynamicRes method, the param id is null");
			throw new NullArgumentException("update dynamicRes method, the param id is null");
		}
		
		this.checkExistMainHref(dynamicRes);
		this.checkExistTitle(dynamicRes);
		
		String sql = "update tbl_dynamic_res set title=?, main_href=?, dynamic_res_type_id=? where id=?";
		this.template.update(sql, new Object[]{dynamicRes.getTitle(), dynamicRes.getMainHref(), dynamicRes.getResTypeId(),dynamicRes.getId()});
	}

	@Override
	public List<DynamicRes> fetchAll() {
		String sql = "select a.id,a.title, main_href, res_id,dynamic_res_type_id, t.name AS dynamic_res_type_name from  tbl_dynamic_res a  left join tbl_dynamic_res_type t on t.id=dynamic_res_type_id";
		return this.template.query(sql, new DynamicResRowMapper());
	}
	@Override
	public DynamicRes getById(Integer id) {
		if(id == null) {
			log.error("[rbac dynamicRes] getById method, the param id is null");
			return null;
		}
		String sql = "select a.id,a.title, main_href, res_id,dynamic_res_type_id, t.name AS dynamic_res_type_name from tbl_dynamic_res a left join tbl_dynamic_res_type t on t.id=dynamic_res_type_id where a.id=? ";
		try {
			DynamicRes obj = this.template.queryForObject(sql, new Object[]{id}, new DynamicResRowMapper());
			return obj;
		} catch(EmptyResultDataAccessException ex) {
			return null;
		}
	}
	@Override
	public  List<DynamicResType> fetchTypeAll() {
		if(ResTypeCache.RES_TYPE_LIST.isEmpty()) {
			String sql = "select * from tbl_dynamic_res_type";
			List<DynamicResType> result =  this.template.query(sql, new DynamicResTypeRowMapper());
			if(result == null) {
				result = new ArrayList<DynamicResType>();
			}else {
				synchronized (ResTypeCache.RES_TYPE_LIST) {
					ResTypeCache.RES_TYPE_LIST.clear();
					ResTypeCache.RES_TYPE_LIST.addAll(result);
				}
			
				for(DynamicResType type :  result) {
					ResTypeCache.RES_TYPE_MAP.put(type.getId(), type.getName());
				}
			}
			return result;
		}
		else {
			return ResTypeCache.RES_TYPE_LIST;
		}
	}
	@Override
	public List<Integer> fetchResByRoleId(Integer id) {
		if(id == null) {
			log.error("[rbac menu] fetchResByRoleId method, the param id is null");
			return null;
		}
		
		String sql = "select dynamic_res_id from tbl_role_dynamic_res where role_id=?";
		List<Integer> result = this.template.queryForList(sql, Integer.class, new Object[]{id});
		if(result == null) {
			result = new ArrayList<Integer>();
		}
		return result;
	}
//	@Override
//	public List<ApkInfo> fetchAllApk() {
//		String sql = "select id, app_name, package_name,lastest_publish_version from tbl_apk_info where is_del=0";
//		return this.template.query(sql, new ApkInfoRowMapper());
//	}
	private Map<Integer, String> fetchResRecordIdsByRoleId(Integer id) {
		String sql = "select dynamic_res_id, res_record_ids from tbl_role_dynamic_res where role_id=?";
		List<RoleDynamicRes> result = this.template.query(sql,new Object[]{id}, new RoleDynamicResMapper());
		Map<Integer, String> resultMap = new HashMap<Integer, String>();
		if(result != null  && !result.isEmpty()) {
			for(RoleDynamicRes ele : result) {
				if(StringUtils.isNotBlank(ele.getResRecordIds())) {
					resultMap.put(ele.getDynamicResId(), ele.getResRecordIds());
				}
			}
		}
		return resultMap;
	}
	@Override
	public List<DynamicRes> fetchResRecordsByRoleId(Integer roleId) {
		String sql = "select a.id,a.title, main_href, res_id,dynamic_res_type_id, t.name AS dynamic_res_type_name from  tbl_dynamic_res a  left join tbl_dynamic_res_type t on t.id=dynamic_res_type_id";
		Map<Integer, String> resIds = fetchResRecordIdsByRoleId(roleId);
		
		List<DynamicRes>  res = this.template.query(sql, new DynamicResRowMapper());
		if(!resIds.isEmpty()) {
			for(DynamicRes ele : res) {
				ele.setResRecordIds(resIds.get(ele.getId()));
			}
		}
		return res;
	}
	@Override
	public Map<String, DynamicRes> fetchResRecordsMapByRoleIds(
			List<Integer> roleIds) {
		
		Map<String, DynamicRes> resultMap = new HashMap<String, DynamicRes>();
		if(roleIds == null || roleIds.isEmpty()) {
			return resultMap;
		}
		
		String sql = "select dynamic_res_id, res_record_ids from tbl_role_dynamic_res where role_id in ("+StringUtils.join(roleIds.toArray(),",")+")";
		List<RoleDynamicRes> result = this.template.query(sql, new RoleDynamicResMapper() );
		
		Map<Integer, String> rdrMap = new HashMap<Integer, String>();
		for(RoleDynamicRes rdr : result) {
			if(StringUtils.isBlank(rdr.getResRecordIds())) {
				continue;
			}
			if(rdrMap.get(rdr.getDynamicResId()) == null 
					||rdr.getResRecordIds().equals(SELECT_ALL)) {
				rdrMap.put(rdr.getDynamicResId(), rdr.getResRecordIds());
				continue;
			}
			else {
				
				if(rdrMap.get(rdr.getDynamicResId()).equals(SELECT_ALL)) {
					continue;
				}
				else {
					rdrMap.put(rdr.getDynamicResId(), rdrMap.get(rdr.getDynamicResId())+ "," + rdr.getResRecordIds());
				}
			}
		}
		
		if(rdrMap == null || rdrMap.isEmpty()) return resultMap;
		String resSql = "select id, main_href, title, dynamic_res_type_id from tbl_dynamic_res where id in ("+ StringUtils.join(rdrMap.keySet().toArray(),",")+")";
		List<DynamicRes> resResult = this.template.query(resSql, new BeanPropertyRowMapper(DynamicRes.class));
		
		if(resResult == null || resResult.isEmpty()) {
			return resultMap;
		}
		
		for(DynamicRes res : resResult) {
			resultMap.put(res.getMainHref(), res);
			res.setResRecordIds(rdrMap.get(res.getId()));
		}
		
		return resultMap;
	}
	
	private void checkExistMainHref(DynamicRes obj) {
		if(this.existedMainHrefWithOther(obj.getMainHref(), obj.getId())) {
			log.error("[rbac DynamicRes] save checkExistMainHref method, the mainHref or is existed");
			throw new ResultFailException("操作资源主链接已经存在，操作失败");
		}
	}

	private void checkExistTitle(DynamicRes obj) {
		if(this.existedTitleWithOther(obj.getTitle(), obj.getId())) {
			log.error("[rbac DynamicRes] save checkExistTitle method, the title is existed");
			throw new ResultFailException("操作资源名称已经存在，操作失败");
		}
	}
	/**
	 * 
	 *	
	 * @param title
	 * @param id
	 * @return
	 * @author gsd
	 */
	@Override
	public boolean existedTitleWithOther(String title, Integer id) {
		if(StringUtils.isBlank(title)) {
			log.error("[rabc dynamice] existedTitleWithOther, the param title is blank");
			return true;
		}
		
		String sql = "select id from tbl_dynamic_res where title=? and id <> ?";
		if(id == null) {
			id = NOT_EXISTED_ID;
		}
		List<Integer> result = this.template.queryForList(sql, Integer.class, new Object[]{title, id});
		if(result == null || result.isEmpty()) {
			return false;
		}
		
		return true;
	}

	/**
	 * 
	 *	
	 * @param mainHref
	 * @param id
	 * @return
	 * @author gsd
	 */
	@Override
	public boolean existedMainHrefWithOther(String mainHref, Integer id) {
		if(StringUtils.isBlank(mainHref)) {
			log.error("[rabc dynamicRes] existedMainHrefWithOther, the param mainHref is blank");
			return true;
		}
		
		String sql = "select id from tbl_dynamic_res where main_href=? and id <> ?";
		if(id == null) {
			id = NOT_EXISTED_ID;
		}
		List<Integer> result = this.template.queryForList(sql, Integer.class, new Object[]{mainHref, id});
		if(result == null || result.isEmpty()) {
			return false;
		}
		
		return true;
	}
}

class DynamicResRowMapper implements RowMapper<DynamicRes> {
	public DynamicRes mapRow(ResultSet rs, int index) throws SQLException {
		DynamicRes dynamicRes = new DynamicRes();
		dynamicRes.setId(rs.getInt("id"));
		dynamicRes.setMainHref(rs.getString("main_href"));
		dynamicRes.setTitle(rs.getString("title"));
		dynamicRes.setResTypeId(rs.getInt("dynamic_res_type_id"));
		dynamicRes.setResType(rs.getString("dynamic_res_type_name"));
		return dynamicRes;
	}
}

class DynamicResTypeRowMapper implements RowMapper<DynamicResType> {
	public DynamicResType mapRow(ResultSet rs, int index) throws SQLException {
		DynamicResType type = new DynamicResType();
		type.setId(rs.getInt("id"));
		type.setName(rs.getString("name"));
		return type;
	}
}

/*class ApkInfoRowMapper implements RowMapper<ApkInfo> {
	public ApkInfo mapRow(ResultSet rs, int index) throws SQLException {
		ApkInfo type = new ApkInfo();
		type.setId(rs.getInt("id"));
		type.setAppName(rs.getString("app_name"));
		type.setPackageName(rs.getString("package_name"));
		type.setLastestPublishVersion(rs.getString("lastest_publish_version"));
		return type;
	}
}*/
class RoleDynamicResMapper implements RowMapper<RoleDynamicRes> {
	
	public RoleDynamicRes mapRow(ResultSet rs, int index) throws SQLException {
		RoleDynamicRes type = new RoleDynamicRes();
		type.setDynamicResId(rs.getInt("dynamic_res_id"));
		type.setResRecordIds(rs.getString("res_record_ids"));
		return type;
	}
}
