package cn.nubia.rbac.service;

import java.util.List;
import java.util.Map;

import cn.nubia.rbac.model.Menu;

public interface MenuService extends RBACBaseService<Menu> {

	List<Integer> fetchMenuIdsByRoleId(Integer id);
	
	/**
	 * 功能：根据角色id来获取所有菜单权限
	 * 注意：
	 * @param ids 权限ids
	 * @return Map<menu.mainHref, menu对象>
	 * 2015年10月16日 下午2:11:18
	 * gsd
	 */
	Map<String, Menu> fetchMenusByRoleIds(List<Integer> ids);
	
	boolean existedTitleWithOther(String title, Integer id);
	
	boolean existedMainHrefWithOther(String mainHref, Integer id);
}
