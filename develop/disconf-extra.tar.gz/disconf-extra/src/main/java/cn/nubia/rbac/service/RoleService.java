package cn.nubia.rbac.service;

import java.util.List;
import java.util.Map;

import cn.nubia.rbac.model.Role;

public interface RoleService extends RBACBaseService<Role> {

	/**
	 * 功能：分配权限
	 * 注意：
	 * @param roleId 角色id
	 * @param menuIdInts 分配的菜单id号
	 * @param resIds 分配的数据资源操作id号
	 * @param resRecordIds 数据资源id号 Map<数据资源操作id, 数据资源Id号>
	 * 	比如:<删除应用操作Id,对应的应用id号1,2,3,4> 数据资源Id号是字符串中间以逗号隔开
	 * 2015年10月16日 下午3:35:57
	 * gsd
	 */
	void updatePemit(Integer roleId, List<Integer> menuIdInts, List<Integer> resIds,
			Map<Integer, String> resRecordIds);

	boolean existedByMenuId(Integer menuId);
	
	boolean existedByDynamicResId(Integer dynamicResId);
	
	boolean existedNameWithOther(String name, Integer id);
}
