package cn.nubia.rbac.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class SysUser implements Serializable {

	private static final long serialVersionUID = 2937115855287518567L;
	private Integer id;
	private String username;
	private String password;
	private String realname;
	private String email;
	private Date addTime;
	private Map<String, Menu> menus;
	private Map<String, DynamicRes> res;
	private List<Role> roles = new ArrayList<>();
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRealname() {
		return realname;
	}
	public void setRealname(String realname) {
		this.realname = realname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Date getAddTime() {
		return addTime;
	}
	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}
	public List<Role> getRoles() {
		return roles;
	}
	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}
	public Map<String, Menu> getMenus() {
		return menus;
	}
	public void setMenus(Map<String, Menu> menus) {
		this.menus = menus;
	}
	public Map<String, DynamicRes> getRes() {
		return res;
	}
	public void setRes(Map<String, DynamicRes> res) {
		this.res = res;
	}
	
	
}
