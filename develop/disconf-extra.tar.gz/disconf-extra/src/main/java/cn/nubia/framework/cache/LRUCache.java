package cn.nubia.framework.cache;

import java.util.LinkedHashMap;
import java.util.Map;


/**
 * Least Recently Used (Not Recently Used)
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class LRUCache extends AbstractCache {
	
	public LRUCache(String name){
		this(name,DEFAULT_MAX_SIZE);
	}
	
	public LRUCache(String name,int maxSize) {
		this.name=name;
		this.maxSize = maxSize;
		
		this.map = new LinkedHashMap<Object,Element>(maxSize,0.75f,true) {
			private static final long serialVersionUID = 1L;
			protected boolean removeEldestEntry(Map.Entry<Object,Element> eldest) {
				return isFull();
			}
		};
	}
}