package cn.nubia.framework.exception;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class ArgumentException extends IllegalArgumentException {

	private static final long serialVersionUID = -4071753026484002401L;

	public ArgumentException(String message) {
    	 super(message);
    }

}
