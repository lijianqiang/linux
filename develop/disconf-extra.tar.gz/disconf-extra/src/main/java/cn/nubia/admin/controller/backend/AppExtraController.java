package cn.nubia.admin.controller.backend;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baidu.disconf.web.service.app.bo.App;
import com.baidu.disconf.web.service.app.form.AppNewForm;
import com.baidu.disconf.web.service.app.service.AppMgr;
import com.baidu.disconf.web.service.app.vo.AppListVo;
import com.baidu.disconf.web.web.app.validator.AppValidator;
import com.baidu.dsp.common.controller.BaseController;
import com.baidu.dsp.common.vo.JsonObjectBase;

import cn.nubia.admin.ExtraConstant;
import cn.nubia.admin.common.PagerBean;
import cn.nubia.admin.common.Result;
import cn.nubia.admin.service.AppExtraService;
import cn.nubia.framework.core.ActionContext;
import cn.nubia.framework.util.StringUtil;
import cn.nubia.rbac.model.SysUser;
import cn.nubia.rbac.util.Define;

/**
 * @author lijianqiang
 * @version 2016-10-18
 */
@Controller
@RequestMapping(ExtraConstant.API_PREFIX + "/app")
public class AppExtraController extends BaseController {

    protected static final Logger LOG = LoggerFactory.getLogger(AppExtraController.class);

    @Autowired
    private AppMgr appMgr;

    @Autowired
    private AppValidator appValidator;
    
    @Autowired
    private AppExtraService appExtraService;

    /**
     * list，旧改
     *
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ResponseBody
    public JsonObjectBase list() {

        //List<AppListVo> appListVos = appMgr.getAuthAppVoList();
    	SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
    	List<AppListVo> appListVos = buildList(sysUser.getId());

        return buildListSuccess(appListVos, appListVos.size());
    }
    
    private List<AppListVo> buildList(int adminId) {
    	List<App> apps = appExtraService.getByAdminId(adminId);
    	List<AppListVo> appListVos = new ArrayList<AppListVo>();
    	if (apps == null || apps.isEmpty()) {
    		return appListVos;
    	}
    	for (App app : apps) {
            AppListVo appListVo = new AppListVo();
            appListVo.setId(app.getId());
            appListVo.setName(app.getName());
            appListVos.add(appListVo);
        }
    	return appListVos;
    }

    /**
     * create，旧改
     *
     * @return
     */
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonObjectBase create(@Valid AppNewForm appNewForm) {

        LOG.info(appNewForm.toString());

        appValidator.validateCreate(appNewForm);

        appMgr.create(appNewForm);

        return buildSuccess("创建成功");
    }
    
    /**
     * 返回分頁的应用列表信息, 新增
     */
    @ResponseBody
    @RequestMapping("/listpage")
    public String listByPage(PagerBean<App> pager){
    	SysUser sysUser=(SysUser)ActionContext.getSession().getAttribute(Define.SESSION_IN_USER);
    	if (sysUser == null) {
    		return Result.returnFailResult("admin is time out");
    	}
    	appExtraService.getListByPage(sysUser.getId(), pager);
        return Result.returnDataResult(pager);
    }
    
    /**
	 * 修改, 新增
	 */
	@ResponseBody
	@RequestMapping("/update")
	public String updateAppName(HttpServletRequest request) {
		long id = 0L;
		try {
			String idStr = request.getParameter("id");
			id = Long.valueOf(idStr);
		} catch (NumberFormatException ne) {
			return Result.returnFailResult("参数有误");
		}
		String name = request.getParameter("name");
		if (StringUtil.isEmpty(name)) {
			return Result.returnFailResult("名称不能为空");
		}
		
		App oldGroup = appExtraService.getById(id);
		if (oldGroup == null) {
			return Result.returnFailResult("信息已不存在");
		} 
		appExtraService.updateNameById(id, name);
		
		return Result.returnSuccResult();
	}

	/**
	 * 删除, 新增
	 */
	@ResponseBody
	@RequestMapping("/delete")
	public String delete(Long id) {
		appExtraService.delete(id);
		return Result.returnSuccResult();
	}
	
	/**
     * list，新增，页面分配资源权限时调用
     *
     * @return
     */
    @RequestMapping(value = "/listall", method = RequestMethod.GET)
    @ResponseBody
    public String listAll() {

    	List<App> appList = appExtraService.getAll();

        //return buildListSuccess(appListVos, appListVos.size());
    	return Result.returnDataResult(appList);
    }

}
