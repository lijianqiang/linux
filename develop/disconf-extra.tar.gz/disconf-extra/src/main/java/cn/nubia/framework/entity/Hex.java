package cn.nubia.framework.entity;


/**
 * 
 *
 * @author  The Jxva Framework Foundation
 * @since   1.0
 * @version 2009-04-01 10:43:11 by jxva
 */
public abstract class Hex {
	
	private static final char[] HEX_CHAR_TABLE = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

	
	public static byte[] hex2bin(String data) {
		if (data == null) {
			return null;
		}
		byte high, low;
		int len = data.length() / 2;
		byte[] b = new byte[len];
		for (int i = 0, k = 0; i < len; i++, k += 2) {
			high = (byte) (Character.digit(data.charAt(k), 16) & 0x0F);
			low = (byte) (Character.digit(data.charAt(k + 1), 16) & 0x0F);
			b[i] = (byte) ((high << 4) | low);
		}

		return b;
	}
	
	public static String bin2hex(byte[] bytes) {
		if (bytes == null) {
			return null;
		}
		final StringBuilder hex = new StringBuilder(bytes.length * 2);
		for (final byte by : bytes) {
			hex.append(HEX_CHAR_TABLE[(by & 0xF0) >> 4]);
			hex.append(HEX_CHAR_TABLE[(by & 0x0F)]);
		}
		return hex.toString();
	}

	/*
	public static byte[] decode(String data) throws IOException {
		if (data == null) {
			return null;
		}
		char chars[] = data.toCharArray();
		byte bytes[] = new byte[chars.length / 2];
		int byteCount = 0;
		for (int i = 0; i < chars.length; i += 2) {
			byte newByte = 0;
			newByte |= CharUtil.charToByte(chars[i]);
			newByte <<= 4;
			newByte |= CharUtil.charToByte(chars[i + 1]);
			bytes[byteCount] = newByte;
			byteCount++;
		}
		return bytes;
	}

	public static String encode(byte[] bytes) {
		if (bytes == null) {
			return null;
		}
		StringBuilder buf = new StringBuilder(bytes.length * 2);
		for (int i = 0; i < bytes.length; i++) {
			if ((bytes[i] & 0xff) < 16){
				buf.append('0');
			}
			buf.append(Integer.toHexString(0xFF & bytes[i]));
			//Long.toString(bytes[i] & 0xff, 16));
		}
		return buf.toString();
	}
	*/
}
