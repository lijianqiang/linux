package cn.nubia.framework.core;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class CommonProperty {

	private static final Properties props = new Properties();

	static {
		try (InputStream fileName = CommonProperty.class.getClassLoader().getResourceAsStream("common.properties")){
			props.load(fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getProperty(String key) {
		return props.getProperty(key);
	}
}
