package cn.nubia.framework.core;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class Pager extends PageBean{
	
	private String pageNum;
	
	public Pager(int pageno) {
		super(pageno);
	}
	
	public Pager(int pageno,int pagesize) {
		super(pageno,pagesize);
	}
	
	
	@Override
	public void setPageNum(String url){
		StringBuilder sb=new StringBuilder();
		
		int p=0,i=0;
		
		if((pageno-1)%10==0){
			p=(pageno-1)/10;
		}else{
			p=(((pageno-1)-(pageno-1)%10)/10);
		}

		if (totalPage>1){
			sb.append("<div class=\"pager\">");
			sb.append("<a href=\""+url+"1\">&#171;</a>");
			
			if (p*10 > 0){
				sb.append("<a href=\""+url+(p*10)+"\">&#139;</a>");
			}else{
				sb.append("<a href=\""+url+((pageno-1)==0?1:(pageno-1))+"\">&#139;</a>");
			}
			for (i=p*10+1;i<p*10+11;i++){
				if (i==pageno){
					sb.append("<a href=\""+url+i+"\" class=\"active\">"+i+"</a>");
				}else{
					sb.append("<a href=\""+url+i+"\">"+i+"</a>");
				}
				if (i==totalPage) break;
			}

			if (i<totalPage){
				sb.append("<a href=\""+url+i+"\">&#155;</a>");
			}else{
				sb.append("<a href=\""+url+((pageno+1)>totalPage?totalPage:(pageno+1))+"\">&#155;</a>");
			}
			
			sb.append("<a href=\""+url+totalPage+"\">&#187;</a>");
			sb.append("</div>");
		}
		this.pageNum=sb.toString();
	}


	@Override
	public String getPageNum() {
		return this.pageNum;
	}
}
