package cn.nubia.framework.crypto;

import cn.nubia.framework.crypto.provider.Crc16ByReversedTable;

/**
 * 
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 29, 2015 2:34:15 PM by jxva
 */
public class Crc16 extends Crc16ByReversedTable{

}
