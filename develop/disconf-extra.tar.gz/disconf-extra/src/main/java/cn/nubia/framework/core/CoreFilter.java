package cn.nubia.framework.core;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 * @author  the nubia foundation framework
 * @since   1.0
 * @version 2014-12-10 20:05:38 by Jxva
 */
public class CoreFilter implements Filter {
	
	private String encoding;

	@Override
	public void destroy() {
		this.encoding = null;
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		encoding = filterConfig.getInitParameter("encoding");
		if (encoding == null)
			encoding = "UTF-8";
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		req.setCharacterEncoding(encoding);
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		// PageContext pageContext =
		// JspFactory.getDefaultFactory().getPageContext(this,req,resp, null,
		// true,JspWriter.DEFAULT_BUFFER, true);
		try {
			ActionContext.setContext(request, response);
			chain.doFilter(req, resp);
		} finally {
			ActionContext.removeContext();
		}

	}

}