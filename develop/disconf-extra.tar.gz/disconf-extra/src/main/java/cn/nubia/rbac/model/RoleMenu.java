package cn.nubia.rbac.model;

import java.io.Serializable;

public class RoleMenu  implements Serializable {
	
	private static final long serialVersionUID = 1862104100064145205L;

	private Integer id;
	
	private Menu menu;
	private Role role;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Menu getMenu() {
		return menu;
	}
	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	
	
}
