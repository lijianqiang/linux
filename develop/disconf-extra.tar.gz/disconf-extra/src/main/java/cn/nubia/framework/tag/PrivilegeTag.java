package cn.nubia.framework.tag;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * Privilege Control Tag for Dashboard
 * @author the nubia foundation framework
 * @since 1.0
 * @version Jan 21, 2015 3:43:14 PM by jxva
 */
public class PrivilegeTag extends TagSupport {

	private static final long serialVersionUID = 1L;

	private String test;

	public void setTest(String test) {
		this.test = test;
	}

	public int doStartTag() throws JspException {
		/*
		 * TODO 
		 * SysUser employee = (SysUser)
		 * pageContext.getSession().getAttribute( Define.SESSION_IN_USER);
		 * return employee.getOperations().containsKey(test) ||
		 * employee.getMenus().containsKey(test) ? EVAL_BODY_INCLUDE :
		 * SKIP_BODY;
		 */
		return EVAL_BODY_INCLUDE;
	}

	public int doEndTag() throws JspException {
		return EVAL_PAGE;
	}

	public void release() {
		super.release();
		test = null;
	}
}
