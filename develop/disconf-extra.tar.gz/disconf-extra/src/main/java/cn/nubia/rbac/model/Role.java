package cn.nubia.rbac.model;

import java.io.Serializable;
import java.util.Map;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Role  implements Serializable {

	private static final long serialVersionUID = 4034551781537890595L;
	protected Integer id;
	protected String name;
	protected String description;
	private Map<String, Menu> menus;
	private Map<String, DynamicRes> res;

	public Role () {
		super();
	}
	
	public Role (
		 Integer in_roleId
		,String in_name
		,String in_description
        ) {
		this.setId(in_roleId);
		this.setName(in_name);
		this.setDescription(in_description);
    }

	public String getName() {
		return this.name;
	}
	
	public void setName(String aValue) {
		this.name = aValue;
	}	

	public String getDescription() {
		return this.description;
	}
	
	public void setDescription(String aValue) {
		this.description = aValue;
	}	


	public Map<String, Menu> getMenus() {
		return menus;
	}

	public void setMenus(Map<String, Menu> menus) {
		this.menus = menus;
	}

	public Map<String, DynamicRes> getRes() {
		return res;
	}

	public void setRes(Map<String, DynamicRes> res) {
		this.res = res;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String toString() {
		return new ToStringBuilder(this)
				.append("roleId", this.id) 
				.append("name", this.name) 
				.append("description", this.description) 
				.toString();
	}


	public String getFirstKeyColumnName() {
		return "roleId";
	}
	
}