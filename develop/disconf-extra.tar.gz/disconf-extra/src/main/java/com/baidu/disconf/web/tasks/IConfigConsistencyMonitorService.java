package com.baidu.disconf.web.tasks;

/**
 * @author knightliao
 */
public interface IConfigConsistencyMonitorService {

    void myTest();

    void check();
}
