package com.baidu.disconf.web.service.roleres.dao.impl;

import org.springframework.stereotype.Repository;

import com.baidu.disconf.web.service.roleres.bo.RoleResource;
import com.baidu.disconf.web.service.roleres.dao.RoleResourceDao;
import com.baidu.dsp.common.dao.AbstractDao;

/**
 * @author weiwei
 * @date 2013-12-20 涓嬪崍6:35:04
 */
@Repository
public class RoleResourceDaoImpl extends AbstractDao<Integer, RoleResource> implements RoleResourceDao {

}