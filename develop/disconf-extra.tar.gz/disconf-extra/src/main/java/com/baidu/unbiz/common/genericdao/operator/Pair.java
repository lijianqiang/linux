/**
 * adx-common#com.baidu.ub.common.generic.dao.operator.Pair.java
 * 下午4:56:23 created by Darwin(Tianxin)
 */
package com.baidu.unbiz.common.genericdao.operator;

/**
 * @author Darwin(Tianxin)
 */
public interface Pair {

    String getColumn();

    Object getValue();
}
