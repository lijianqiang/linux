package com.baidu.disconf.web.service.roleres.dao;

import com.baidu.disconf.web.service.roleres.bo.RoleResource;
import com.baidu.unbiz.common.genericdao.dao.BaseDao;

/**
 * @author weiwei
 * @date 2013-12-20 涓嬪崍6:16:31
 */
public interface RoleResourceDao extends BaseDao<Integer, RoleResource> {

}
