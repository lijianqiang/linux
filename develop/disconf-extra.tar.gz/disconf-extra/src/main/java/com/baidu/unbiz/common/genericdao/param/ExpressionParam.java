package com.baidu.unbiz.common.genericdao.param;

/**
 * 封装表达式的参数
 *
 * @author Darwin(Tianxin)
 */
public final class ExpressionParam {
    public ExpressionParam() {
    }
}