package com.baidu.disconf.web.service.sign.dao;

import com.baidu.disconf.web.service.user.bo.User;
import com.baidu.unbiz.common.genericdao.dao.BaseDao;

/**
 * @author liaoqiqi
 * @version 2013-11-28
 */
public interface SignDao extends BaseDao<Long, User> {

}
