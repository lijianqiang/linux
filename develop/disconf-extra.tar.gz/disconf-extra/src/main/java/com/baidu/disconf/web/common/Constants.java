package com.baidu.disconf.web.common;

/**
 * Created by knightliao on 15/12/25.
 */
public class Constants {

    public final static Integer STATUS_NORMAL = 1;
    public final static Integer STATUS_DELETE = 0;
}
