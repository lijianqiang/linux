package com.baidu.dsp.common.dao;

/**
 * @author liaoqiqi
 * @version 2014-1-14
 */
public class DB {

    public final static String DB_NAME = "";
}
