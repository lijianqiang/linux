package com.baidu.disconf.web.service.role.dao;

import com.baidu.disconf.web.service.role.bo.Role;
import com.baidu.unbiz.common.genericdao.dao.BaseDao;

public interface RoleDao extends BaseDao<Integer, Role> {

}
