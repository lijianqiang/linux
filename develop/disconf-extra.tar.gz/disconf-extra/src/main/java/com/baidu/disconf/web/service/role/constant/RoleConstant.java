package com.baidu.disconf.web.service.role.constant;

/**
 * @author liaoqiqi
 * @version 2014-1-13
 */
public class RoleConstant {

}
