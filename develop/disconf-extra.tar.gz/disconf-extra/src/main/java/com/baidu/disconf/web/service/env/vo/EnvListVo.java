package com.baidu.disconf.web.service.env.vo;

/**
 * @author liaoqiqi
 * @version 2014-6-22
 */
public class EnvListVo {

    private long id;
    private String name;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
