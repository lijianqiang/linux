package com.baidu.disconf.web.service.user.facade;

/**
 * @author liaoqiqi
 * @version 2014-1-13
 */
public interface UserFacade {

}
