为了方便大家开发，统一了所有SQL，请先后执行：

- 0-disconf-extra-init.sql        create db,tables
