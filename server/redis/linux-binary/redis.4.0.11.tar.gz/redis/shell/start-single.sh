#!/bin/sh
EXEC=/data/program/redis/bin/redis-server
CONF=/data/program/redis/conf/single/redis.conf

$EXEC $CONF
